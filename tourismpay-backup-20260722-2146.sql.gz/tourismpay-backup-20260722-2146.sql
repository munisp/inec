--
-- PostgreSQL database dump
--

\restrict K2nNTkCrRWPvVRMV68qNevLoWaBHCefaQ10kLm1g9lGaC0dUga0ltfhc4LogiSf

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: tourismpay
--

CREATE SCHEMA drizzle;


ALTER SCHEMA drizzle OWNER TO tourismpay;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: bis_export_schedule_frequency; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.bis_export_schedule_frequency AS ENUM (
    'weekly',
    'biweekly',
    'monthly'
);


ALTER TYPE public.bis_export_schedule_frequency OWNER TO tourismpay;

--
-- Name: bis_risk_level; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.bis_risk_level AS ENUM (
    'low',
    'medium',
    'high',
    'critical'
);


ALTER TYPE public.bis_risk_level OWNER TO tourismpay;

--
-- Name: bis_status; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.bis_status AS ENUM (
    'pending',
    'processing',
    'completed',
    'flagged',
    'failed'
);


ALTER TYPE public.bis_status OWNER TO tourismpay;

--
-- Name: bis_tier; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.bis_tier AS ENUM (
    'basic',
    'standard',
    'comprehensive'
);


ALTER TYPE public.bis_tier OWNER TO tourismpay;

--
-- Name: booking_status; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.booking_status AS ENUM (
    'pending',
    'confirmed',
    'cancelled',
    'completed',
    'no_show'
);


ALTER TYPE public.booking_status OWNER TO tourismpay;

--
-- Name: delivery_option; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.delivery_option AS ENUM (
    'bank_transfer',
    'mobile_money',
    'agent_cash',
    'bill_payment',
    'wallet'
);


ALTER TYPE public.delivery_option OWNER TO tourismpay;

--
-- Name: establishment_type; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.establishment_type AS ENUM (
    'hotel',
    'restaurant',
    'concert_venue',
    'safari_lodge',
    'tour_operator',
    'airline',
    'car_rental',
    'spa_wellness',
    'museum',
    'theme_park',
    'beach_resort',
    'conference_center',
    'nightclub',
    'sports_venue',
    'travel_agency'
);


ALTER TYPE public.establishment_type OWNER TO tourismpay;

--
-- Name: finance_request_status; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.finance_request_status AS ENUM (
    'pending',
    'under_review',
    'approved',
    'rejected',
    'active',
    'completed',
    'quoted'
);


ALTER TYPE public.finance_request_status OWNER TO tourismpay;

--
-- Name: finance_request_type; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.finance_request_type AS ENUM (
    'payout',
    'loan',
    'insurance'
);


ALTER TYPE public.finance_request_type OWNER TO tourismpay;

--
-- Name: fraud_alert_severity; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.fraud_alert_severity AS ENUM (
    'info',
    'low',
    'medium',
    'high',
    'critical'
);


ALTER TYPE public.fraud_alert_severity OWNER TO tourismpay;

--
-- Name: fraud_alert_status; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.fraud_alert_status AS ENUM (
    'open',
    'investigating',
    'resolved',
    'false_positive'
);


ALTER TYPE public.fraud_alert_status OWNER TO tourismpay;

--
-- Name: itinerary_collaborator_role; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.itinerary_collaborator_role AS ENUM (
    'owner',
    'editor',
    'viewer'
);


ALTER TYPE public.itinerary_collaborator_role OWNER TO tourismpay;

--
-- Name: kyb_document_status; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.kyb_document_status AS ENUM (
    'pending',
    'verified',
    'rejected',
    'expired'
);


ALTER TYPE public.kyb_document_status OWNER TO tourismpay;

--
-- Name: kyb_document_type; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.kyb_document_type AS ENUM (
    'certificate_of_incorporation',
    'business_license',
    'tax_certificate',
    'director_id',
    'proof_of_address',
    'bank_statement',
    'audited_accounts',
    'ownership_structure',
    'regulatory_approval',
    'other'
);


ALTER TYPE public.kyb_document_type OWNER TO tourismpay;

--
-- Name: kyb_status; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.kyb_status AS ENUM (
    'draft',
    'submitted',
    'under_review',
    'approved',
    'rejected',
    'suspended'
);


ALTER TYPE public.kyb_status OWNER TO tourismpay;

--
-- Name: loyalty_tier; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.loyalty_tier AS ENUM (
    'BRONZE',
    'SILVER',
    'GOLD',
    'PLATINUM'
);


ALTER TYPE public.loyalty_tier OWNER TO tourismpay;

--
-- Name: noc_event_type; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.noc_event_type AS ENUM (
    'kill_switch_activated',
    'kill_switch_deactivated',
    'participant_suspended',
    'participant_restored',
    'rate_limit_breach',
    'fraud_alert',
    'system_alert',
    'settlement_failed',
    'settlement_completed'
);


ALTER TYPE public.noc_event_type OWNER TO tourismpay;

--
-- Name: notification_category; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.notification_category AS ENUM (
    'kyb',
    'bis',
    'fraud',
    'soc',
    'system',
    'report',
    'wallet'
);


ALTER TYPE public.notification_category OWNER TO tourismpay;

--
-- Name: offramp_status; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.offramp_status AS ENUM (
    'quote',
    'pending_approval',
    'burning',
    'processing_payout',
    'completed',
    'failed',
    'expired',
    'refunded'
);


ALTER TYPE public.offramp_status OWNER TO tourismpay;

--
-- Name: onramp_status; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.onramp_status AS ENUM (
    'quote',
    'pending_payment',
    'payment_received',
    'minting',
    'completed',
    'failed',
    'expired',
    'refunded'
);


ALTER TYPE public.onramp_status OWNER TO tourismpay;

--
-- Name: participant_status; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.participant_status AS ENUM (
    'active',
    'suspended',
    'pending',
    'inactive'
);


ALTER TYPE public.participant_status OWNER TO tourismpay;

--
-- Name: participant_type; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.participant_type AS ENUM (
    'bank',
    'fintech',
    'mobile_money',
    'agent_network',
    'psp'
);


ALTER TYPE public.participant_type OWNER TO tourismpay;

--
-- Name: payment_rail; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.payment_rail AS ENUM (
    'stripe_card',
    'bank_transfer',
    'mpesa',
    'mtn_momo',
    'orange_money',
    'airtel_money',
    'vodacom_mpesa',
    'opay',
    'flutterwave',
    'chipper_cash',
    'mojaloop',
    'cbdc_bridge'
);


ALTER TYPE public.payment_rail OWNER TO tourismpay;

--
-- Name: payout_frequency; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.payout_frequency AS ENUM (
    'daily',
    'weekly',
    'monthly'
);


ALTER TYPE public.payout_frequency OWNER TO tourismpay;

--
-- Name: ps_webhook_delivery_status; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.ps_webhook_delivery_status AS ENUM (
    'pending',
    'success',
    'failed',
    'retrying',
    'exhausted'
);


ALTER TYPE public.ps_webhook_delivery_status OWNER TO tourismpay;

--
-- Name: rate_alert_status; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.rate_alert_status AS ENUM (
    'active',
    'triggered',
    'expired',
    'cancelled'
);


ALTER TYPE public.rate_alert_status OWNER TO tourismpay;

--
-- Name: rate_condition; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.rate_condition AS ENUM (
    'above',
    'below',
    'exact'
);


ALTER TYPE public.rate_condition OWNER TO tourismpay;

--
-- Name: recurring_payment_frequency; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.recurring_payment_frequency AS ENUM (
    'daily',
    'weekly',
    'monthly'
);


ALTER TYPE public.recurring_payment_frequency OWNER TO tourismpay;

--
-- Name: remittance_currency; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.remittance_currency AS ENUM (
    'BTC',
    'ETH',
    'USDC',
    'USDT',
    'NGN',
    'KES',
    'GHS',
    'TZS',
    'UGX',
    'ZAR',
    'USD'
);


ALTER TYPE public.remittance_currency OWNER TO tourismpay;

--
-- Name: remittance_status; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.remittance_status AS ENUM (
    'pending',
    'processing',
    'completed',
    'failed',
    'reversed',
    'refunded'
);


ALTER TYPE public.remittance_status OWNER TO tourismpay;

--
-- Name: scheduled_payment_recurrence; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.scheduled_payment_recurrence AS ENUM (
    'once',
    'daily',
    'weekly',
    'monthly'
);


ALTER TYPE public.scheduled_payment_recurrence OWNER TO tourismpay;

--
-- Name: scheduled_payment_status; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.scheduled_payment_status AS ENUM (
    'active',
    'paused',
    'cancelled',
    'completed',
    'failed'
);


ALTER TYPE public.scheduled_payment_status OWNER TO tourismpay;

--
-- Name: settlement_status; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.settlement_status AS ENUM (
    'pending',
    'processing',
    'completed',
    'failed',
    'disputed'
);


ALTER TYPE public.settlement_status OWNER TO tourismpay;

--
-- Name: soc_alert_type; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.soc_alert_type AS ENUM (
    'intrusion',
    'anomaly',
    'policy_violation',
    'threat_intel',
    'compliance',
    'data_exfiltration'
);


ALTER TYPE public.soc_alert_type OWNER TO tourismpay;

--
-- Name: staff_invite_status; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.staff_invite_status AS ENUM (
    'pending',
    'accepted',
    'revoked',
    'expired'
);


ALTER TYPE public.staff_invite_status OWNER TO tourismpay;

--
-- Name: staff_role; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.staff_role AS ENUM (
    'cashier',
    'manager',
    'supervisor'
);


ALTER TYPE public.staff_role OWNER TO tourismpay;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: tourismpay
--

CREATE TYPE public.user_role AS ENUM (
    'user',
    'admin',
    'tourist',
    'merchant',
    'compliance_officer',
    'noc_operator',
    'settlement_officer',
    'bis_analyst'
);


ALTER TYPE public.user_role OWNER TO tourismpay;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: tourismpay
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


ALTER TABLE drizzle.__drizzle_migrations OWNER TO tourismpay;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: tourismpay
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNER TO tourismpay;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: tourismpay
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    actor_id integer,
    actor_name character varying(255),
    actor_email character varying(255),
    action character varying(100) NOT NULL,
    entity_type character varying(100) NOT NULL,
    entity_id character varying(100) NOT NULL,
    before jsonb,
    after jsonb,
    description text,
    ip_address character varying(45),
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO tourismpay;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO tourismpay;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: biometric_enrollments; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.biometric_enrollments (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    credential_id character varying(500) NOT NULL,
    public_key text NOT NULL,
    device_name character varying(200),
    aaguid character varying(100),
    sign_count integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_used_at integer,
    created_at integer NOT NULL,
    expires_at integer
);


ALTER TABLE public.biometric_enrollments OWNER TO tourismpay;

--
-- Name: bis_auto_flag_config; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.bis_auto_flag_config (
    id integer NOT NULL,
    currency character varying(20) NOT NULL,
    threshold_usd numeric(18,4) DEFAULT '5000'::numeric NOT NULL,
    velocity_count integer DEFAULT 10 NOT NULL,
    bis_tier character varying(20) DEFAULT 'standard'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    updated_by character varying(64),
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE public.bis_auto_flag_config OWNER TO tourismpay;

--
-- Name: bis_auto_flag_config_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.bis_auto_flag_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bis_auto_flag_config_id_seq OWNER TO tourismpay;

--
-- Name: bis_auto_flag_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.bis_auto_flag_config_id_seq OWNED BY public.bis_auto_flag_config.id;


--
-- Name: bis_auto_flags; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.bis_auto_flags (
    id integer NOT NULL,
    wallet_tx_id character varying(64) NOT NULL,
    user_id character varying(64) NOT NULL,
    currency character varying(20) NOT NULL,
    amount_usd numeric(18,4) NOT NULL,
    trigger_reason character varying(64) NOT NULL,
    threshold_usd numeric(18,4),
    bis_investigation_id integer,
    bis_reference_id character varying(20),
    status character varying(32) DEFAULT 'created'::character varying NOT NULL,
    error_message text,
    created_at bigint NOT NULL
);


ALTER TABLE public.bis_auto_flags OWNER TO tourismpay;

--
-- Name: bis_auto_flags_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.bis_auto_flags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bis_auto_flags_id_seq OWNER TO tourismpay;

--
-- Name: bis_auto_flags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.bis_auto_flags_id_seq OWNED BY public.bis_auto_flags.id;


--
-- Name: bis_directors; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.bis_directors (
    id integer NOT NULL,
    entity_investigation_id integer NOT NULL,
    full_name character varying(255) NOT NULL,
    role character varying(100) DEFAULT 'Director'::character varying NOT NULL,
    nationality character varying(100),
    nin character varying(50),
    email character varying(320),
    phone character varying(30),
    ownership_percent integer,
    linked_investigation_id integer,
    bundle_discount_percent integer DEFAULT 20 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.bis_directors OWNER TO tourismpay;

--
-- Name: bis_directors_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.bis_directors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bis_directors_id_seq OWNER TO tourismpay;

--
-- Name: bis_directors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.bis_directors_id_seq OWNED BY public.bis_directors.id;


--
-- Name: bis_export_schedules; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.bis_export_schedules (
    id integer NOT NULL,
    user_id integer NOT NULL,
    frequency public.bis_export_schedule_frequency DEFAULT 'weekly'::public.bis_export_schedule_frequency NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    include_internal boolean DEFAULT false NOT NULL,
    filters jsonb DEFAULT '{}'::jsonb,
    next_run_at bigint NOT NULL,
    last_run_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    last_export_note_count integer
);


ALTER TABLE public.bis_export_schedules OWNER TO tourismpay;

--
-- Name: bis_export_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.bis_export_schedules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bis_export_schedules_id_seq OWNER TO tourismpay;

--
-- Name: bis_export_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.bis_export_schedules_id_seq OWNED BY public.bis_export_schedules.id;


--
-- Name: bis_investigation_notes; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.bis_investigation_notes (
    id character varying(36) NOT NULL,
    investigation_id character varying(36) NOT NULL,
    author_id character varying(36) NOT NULL,
    author_name character varying(200) NOT NULL,
    content text NOT NULL,
    is_internal boolean DEFAULT false NOT NULL,
    created_at bigint NOT NULL
);


ALTER TABLE public.bis_investigation_notes OWNER TO tourismpay;

--
-- Name: bis_investigations; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.bis_investigations (
    id integer NOT NULL,
    reference_id character varying(20) NOT NULL,
    establishment_id integer,
    requested_by integer,
    subject_full_name character varying(255) NOT NULL,
    subject_dob character varying(20),
    subject_nationality character varying(100),
    subject_nin character varying(50),
    subject_phone character varying(30),
    subject_email character varying(320),
    subject_role character varying(100),
    subject_country character varying(2),
    tier public.bis_tier DEFAULT 'standard'::public.bis_tier NOT NULL,
    status public.bis_status DEFAULT 'pending'::public.bis_status NOT NULL,
    risk_level public.bis_risk_level,
    risk_score integer,
    module_results jsonb,
    recommendations jsonb DEFAULT '[]'::jsonb,
    report_url text,
    consent_obtained boolean DEFAULT false NOT NULL,
    price_paid numeric(10,2),
    currency character varying(3) DEFAULT 'USD'::character varying,
    external_bis_ref character varying(100),
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    assigned_to_id integer,
    assigned_to_name character varying(255),
    assigned_at timestamp without time zone,
    due_at bigint,
    sla_hours integer,
    linked_transaction_id character varying(100),
    subject_type character varying(20) DEFAULT 'individual'::character varying NOT NULL,
    entity_registration_number character varying(100),
    entity_type character varying(50),
    entity_website character varying(255),
    entity_year_founded integer,
    linked_entity_investigation_id integer
);


ALTER TABLE public.bis_investigations OWNER TO tourismpay;

--
-- Name: bis_investigations_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.bis_investigations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bis_investigations_id_seq OWNER TO tourismpay;

--
-- Name: bis_investigations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.bis_investigations_id_seq OWNED BY public.bis_investigations.id;


--
-- Name: bis_kill_switch_activations; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.bis_kill_switch_activations (
    id integer NOT NULL,
    bis_investigation_id integer NOT NULL,
    bis_reference_id character varying(20) NOT NULL,
    subject_full_name character varying(255) NOT NULL,
    risk_level character varying(16) NOT NULL,
    risk_score integer,
    corridor character varying(32) NOT NULL,
    reason text NOT NULL,
    activated_by character varying(64) DEFAULT 'BIS_AUTO'::character varying NOT NULL,
    created_at bigint NOT NULL
);


ALTER TABLE public.bis_kill_switch_activations OWNER TO tourismpay;

--
-- Name: bis_kill_switch_activations_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.bis_kill_switch_activations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bis_kill_switch_activations_id_seq OWNER TO tourismpay;

--
-- Name: bis_kill_switch_activations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.bis_kill_switch_activations_id_seq OWNED BY public.bis_kill_switch_activations.id;


--
-- Name: bis_report_exports; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.bis_report_exports (
    id integer NOT NULL,
    investigation_id integer NOT NULL,
    generated_by integer,
    file_key character varying(500) NOT NULL,
    file_url text NOT NULL,
    file_size_bytes integer,
    llm_summary text,
    export_format character varying(10) DEFAULT 'pdf'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.bis_report_exports OWNER TO tourismpay;

--
-- Name: bis_report_exports_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.bis_report_exports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bis_report_exports_id_seq OWNER TO tourismpay;

--
-- Name: bis_report_exports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.bis_report_exports_id_seq OWNED BY public.bis_report_exports.id;


--
-- Name: bis_timeline; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.bis_timeline (
    id character varying(36) NOT NULL,
    investigation_id integer NOT NULL,
    actor_id character varying(36),
    actor_name character varying(255),
    event_type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    metadata jsonb,
    severity character varying(20) DEFAULT 'info'::character varying NOT NULL,
    created_at bigint NOT NULL
);


ALTER TABLE public.bis_timeline OWNER TO tourismpay;

--
-- Name: carbon_offsets; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.carbon_offsets (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    amount numeric(10,3) NOT NULL,
    project_name character varying(200) NOT NULL,
    project_country character varying(10),
    cost_usd numeric(10,2) NOT NULL,
    certificate_url character varying(500),
    vintage_year integer,
    created_at integer NOT NULL
);


ALTER TABLE public.carbon_offsets OWNER TO tourismpay;

--
-- Name: channel_connections; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.channel_connections (
    id integer NOT NULL,
    establishment_id integer NOT NULL,
    channel_name character varying(50) NOT NULL,
    display_name character varying(100) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    config jsonb DEFAULT '{}'::jsonb,
    last_sync_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.channel_connections OWNER TO tourismpay;

--
-- Name: channel_connections_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.channel_connections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.channel_connections_id_seq OWNER TO tourismpay;

--
-- Name: channel_connections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.channel_connections_id_seq OWNED BY public.channel_connections.id;


--
-- Name: did_documents; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.did_documents (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    did character varying(500) NOT NULL,
    did_document text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at integer NOT NULL,
    updated_at integer NOT NULL
);


ALTER TABLE public.did_documents OWNER TO tourismpay;

--
-- Name: establishment_score_snapshots; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.establishment_score_snapshots (
    id integer NOT NULL,
    establishment_id integer NOT NULL,
    composite_score integer DEFAULT 0 NOT NULL,
    booking_count integer DEFAULT 0 NOT NULL,
    avg_rating numeric(3,1) DEFAULT '0'::numeric NOT NULL,
    response_rate integer DEFAULT 0 NOT NULL,
    snapshot_date character varying(10) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.establishment_score_snapshots OWNER TO tourismpay;

--
-- Name: establishment_score_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.establishment_score_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.establishment_score_snapshots_id_seq OWNER TO tourismpay;

--
-- Name: establishment_score_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.establishment_score_snapshots_id_seq OWNED BY public.establishment_score_snapshots.id;


--
-- Name: establishments; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.establishments (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    type public.establishment_type NOT NULL,
    country character varying(2) NOT NULL,
    city character varying(100),
    address text,
    registration_number character varying(100),
    tax_id character varying(100),
    contact_email character varying(320),
    contact_phone character varying(30),
    website character varying(500),
    kyb_status public.kyb_status DEFAULT 'draft'::public.kyb_status NOT NULL,
    kyb_score integer,
    kyb_notes text,
    owner_id integer,
    employee_count integer,
    annual_revenue numeric(15,2),
    currency character varying(3) DEFAULT 'USD'::character varying,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    latitude numeric(10,7),
    longitude numeric(10,7),
    stripe_account_id character varying(128),
    stripe_connect_status character varying(32) DEFAULT 'not_started'::character varying,
    stripe_payouts_enabled boolean DEFAULT false,
    stripe_details_submitted boolean DEFAULT false
);


ALTER TABLE public.establishments OWNER TO tourismpay;

--
-- Name: establishments_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.establishments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.establishments_id_seq OWNER TO tourismpay;

--
-- Name: establishments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.establishments_id_seq OWNED BY public.establishments.id;


--
-- Name: exchange_rate_overrides; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.exchange_rate_overrides (
    id integer NOT NULL,
    base_currency character varying(10) DEFAULT 'USD'::character varying NOT NULL,
    target_currency character varying(10) NOT NULL,
    rate numeric(18,8) NOT NULL,
    reason text,
    is_active boolean DEFAULT true NOT NULL,
    expires_at bigint,
    created_by_user_id integer,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE public.exchange_rate_overrides OWNER TO tourismpay;

--
-- Name: exchange_rate_overrides_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.exchange_rate_overrides_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.exchange_rate_overrides_id_seq OWNER TO tourismpay;

--
-- Name: exchange_rate_overrides_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.exchange_rate_overrides_id_seq OWNED BY public.exchange_rate_overrides.id;


--
-- Name: finance_requests; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.finance_requests (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    type public.finance_request_type NOT NULL,
    amount numeric(20,6),
    currency character varying(20),
    status public.finance_request_status DEFAULT 'pending'::public.finance_request_status NOT NULL,
    description text,
    metadata text,
    admin_notes text,
    reviewed_by character varying(36),
    reviewed_at integer,
    created_at integer NOT NULL,
    updated_at integer NOT NULL
);


ALTER TABLE public.finance_requests OWNER TO tourismpay;

--
-- Name: fraud_alerts; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.fraud_alerts (
    id integer NOT NULL,
    alert_id character varying(30) NOT NULL,
    transaction_id character varying(100),
    establishment_id integer,
    country character varying(2),
    severity public.fraud_alert_severity NOT NULL,
    status public.fraud_alert_status DEFAULT 'open'::public.fraud_alert_status NOT NULL,
    rule_triggered character varying(100),
    description text,
    amount numeric(15,2),
    currency character varying(3),
    gnn_score numeric(5,2),
    metadata jsonb,
    resolved_by integer,
    resolved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.fraud_alerts OWNER TO tourismpay;

--
-- Name: fraud_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.fraud_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fraud_alerts_id_seq OWNER TO tourismpay;

--
-- Name: fraud_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.fraud_alerts_id_seq OWNED BY public.fraud_alerts.id;


--
-- Name: itinerary_changelog; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.itinerary_changelog (
    id integer NOT NULL,
    itinerary_id integer NOT NULL,
    user_id integer,
    action character varying(64) NOT NULL,
    item_id integer,
    diff jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.itinerary_changelog OWNER TO tourismpay;

--
-- Name: itinerary_changelog_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.itinerary_changelog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.itinerary_changelog_id_seq OWNER TO tourismpay;

--
-- Name: itinerary_changelog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.itinerary_changelog_id_seq OWNED BY public.itinerary_changelog.id;


--
-- Name: itinerary_collaborators; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.itinerary_collaborators (
    id integer NOT NULL,
    itinerary_id integer NOT NULL,
    user_id integer,
    role public.itinerary_collaborator_role DEFAULT 'editor'::public.itinerary_collaborator_role NOT NULL,
    invite_token character varying(64),
    invite_email character varying(320),
    accepted_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.itinerary_collaborators OWNER TO tourismpay;

--
-- Name: itinerary_collaborators_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.itinerary_collaborators_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.itinerary_collaborators_id_seq OWNER TO tourismpay;

--
-- Name: itinerary_collaborators_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.itinerary_collaborators_id_seq OWNED BY public.itinerary_collaborators.id;


--
-- Name: kyb_applications; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.kyb_applications (
    id integer NOT NULL,
    establishment_id integer NOT NULL,
    submitted_by integer,
    status public.kyb_status DEFAULT 'draft'::public.kyb_status NOT NULL,
    current_step integer DEFAULT 1 NOT NULL,
    total_steps integer DEFAULT 5 NOT NULL,
    documents_uploaded jsonb DEFAULT '[]'::jsonb,
    review_notes text,
    reviewed_by integer,
    reviewed_at timestamp without time zone,
    compliance_score integer,
    risk_flags jsonb DEFAULT '[]'::jsonb,
    external_kyb_ref character varying(100),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.kyb_applications OWNER TO tourismpay;

--
-- Name: kyb_applications_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.kyb_applications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.kyb_applications_id_seq OWNER TO tourismpay;

--
-- Name: kyb_applications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.kyb_applications_id_seq OWNED BY public.kyb_applications.id;


--
-- Name: kyb_documents; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.kyb_documents (
    id integer NOT NULL,
    application_id integer NOT NULL,
    establishment_id integer NOT NULL,
    uploaded_by integer,
    document_type public.kyb_document_type NOT NULL,
    status public.kyb_document_status DEFAULT 'pending'::public.kyb_document_status NOT NULL,
    file_name character varying(255) NOT NULL,
    file_key character varying(500) NOT NULL,
    file_url text NOT NULL,
    mime_type character varying(100),
    file_size_bytes integer,
    review_notes text,
    reviewed_by integer,
    reviewed_at timestamp without time zone,
    expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.kyb_documents OWNER TO tourismpay;

--
-- Name: kyb_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.kyb_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.kyb_documents_id_seq OWNER TO tourismpay;

--
-- Name: kyb_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.kyb_documents_id_seq OWNED BY public.kyb_documents.id;


--
-- Name: kyc_verification_records; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.kyc_verification_records (
    id integer NOT NULL,
    user_id character varying(128) NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    document_type character varying(32),
    document_country character varying(3),
    document_number_hash character varying(128),
    full_name_encrypted text,
    date_of_birth character varying(16),
    nationality character varying(3),
    liveness_score real,
    document_match_score real,
    risk_score real,
    sanctions_clear boolean,
    pep_clear boolean,
    reviewer_id character varying(128),
    rejection_reason text,
    expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.kyc_verification_records OWNER TO tourismpay;

--
-- Name: kyc_verification_records_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.kyc_verification_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.kyc_verification_records_id_seq OWNER TO tourismpay;

--
-- Name: kyc_verification_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.kyc_verification_records_id_seq OWNED BY public.kyc_verification_records.id;


--
-- Name: ledger_accounts; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.ledger_accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id integer,
    establishment_id integer,
    ledger_code integer NOT NULL,
    currency_code integer NOT NULL,
    debits_pending bigint DEFAULT 0 NOT NULL,
    debits_posted bigint DEFAULT 0 NOT NULL,
    credits_pending bigint DEFAULT 0 NOT NULL,
    credits_posted bigint DEFAULT 0 NOT NULL,
    flags integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ledger_accounts OWNER TO tourismpay;

--
-- Name: ledger_transfers; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.ledger_transfers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    debit_account_id uuid NOT NULL,
    credit_account_id uuid NOT NULL,
    amount bigint NOT NULL,
    ledger_code integer NOT NULL,
    transfer_code integer NOT NULL,
    pending_id uuid,
    flags integer DEFAULT 0 NOT NULL,
    status character varying(10) DEFAULT 'posted'::character varying NOT NULL,
    idempotency_key character varying(64),
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ledger_transfers_amount_check CHECK ((amount > 0)),
    CONSTRAINT ledger_transfers_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'posted'::character varying, 'voided'::character varying])::text[])))
);


ALTER TABLE public.ledger_transfers OWNER TO tourismpay;

--
-- Name: login_history; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.login_history (
    id integer NOT NULL,
    user_id character varying(64) NOT NULL,
    ip_address character varying(45),
    user_agent text,
    device_fingerprint character varying(255),
    country character varying(100),
    city character varying(100),
    login_method character varying(64),
    success boolean DEFAULT true NOT NULL,
    is_suspicious boolean DEFAULT false NOT NULL,
    is_trusted_device boolean DEFAULT false NOT NULL,
    session_id character varying(128),
    session_active boolean DEFAULT true NOT NULL,
    created_at bigint NOT NULL
);


ALTER TABLE public.login_history OWNER TO tourismpay;

--
-- Name: login_history_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.login_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.login_history_id_seq OWNER TO tourismpay;

--
-- Name: login_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.login_history_id_seq OWNED BY public.login_history.id;


--
-- Name: loyalty_accounts; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.loyalty_accounts (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    points_balance integer DEFAULT 0 NOT NULL,
    tier public.loyalty_tier DEFAULT 'BRONZE'::public.loyalty_tier NOT NULL,
    lifetime_points integer DEFAULT 0 NOT NULL,
    created_at integer NOT NULL,
    updated_at integer NOT NULL,
    tier_protected_until bigint,
    leaderboard_opt_out boolean DEFAULT false NOT NULL,
    hide_transaction_history boolean DEFAULT false NOT NULL
);


ALTER TABLE public.loyalty_accounts OWNER TO tourismpay;

--
-- Name: loyalty_partners; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.loyalty_partners (
    id character varying(36) NOT NULL,
    name character varying(200) NOT NULL,
    logo_url text,
    description text,
    bonus_multiplier numeric(5,2) DEFAULT 1.00 NOT NULL,
    category character varying(50) DEFAULT 'general'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE public.loyalty_partners OWNER TO tourismpay;

--
-- Name: loyalty_referrals; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.loyalty_referrals (
    id character varying(36) NOT NULL,
    referrer_id character varying(36) NOT NULL,
    referee_id character varying(36),
    code character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    referrer_points_awarded integer DEFAULT 0 NOT NULL,
    referee_points_awarded integer DEFAULT 0 NOT NULL,
    used_at bigint,
    created_at bigint NOT NULL
);


ALTER TABLE public.loyalty_referrals OWNER TO tourismpay;

--
-- Name: loyalty_rewards; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.loyalty_rewards (
    id character varying(36) NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    points_cost integer NOT NULL,
    category character varying(50),
    image_url character varying(500),
    is_active boolean DEFAULT true NOT NULL,
    stock integer,
    created_at integer NOT NULL,
    expires_at bigint
);


ALTER TABLE public.loyalty_rewards OWNER TO tourismpay;

--
-- Name: loyalty_transactions; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.loyalty_transactions (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    type character varying(20) NOT NULL,
    points integer NOT NULL,
    description text,
    partner character varying(100),
    reference_id character varying(100),
    created_at integer NOT NULL,
    expires_at integer,
    is_expired boolean DEFAULT false NOT NULL
);


ALTER TABLE public.loyalty_transactions OWNER TO tourismpay;

--
-- Name: lp_applications; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.lp_applications (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    entity_type character varying(20) NOT NULL,
    entity_name character varying(128) NOT NULL,
    registration_country character varying(2) NOT NULL,
    tax_id character varying(64),
    wallet_address character varying(128) NOT NULL,
    intended_pools text NOT NULL,
    intended_deposit_usd numeric(20,2) NOT NULL,
    tier character varying(20) NOT NULL,
    status character varying(30) DEFAULT 'pending_review'::character varying NOT NULL,
    notes text,
    reviewed_by character varying(36),
    reviewed_at bigint,
    created_at bigint NOT NULL
);


ALTER TABLE public.lp_applications OWNER TO tourismpay;

--
-- Name: lp_pool_snapshots; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.lp_pool_snapshots (
    id character varying(36) NOT NULL,
    pool_id character varying(30) NOT NULL,
    total_liquidity numeric(20,6) NOT NULL,
    lp_count integer DEFAULT 0 NOT NULL,
    snapshot_at bigint NOT NULL
);


ALTER TABLE public.lp_pool_snapshots OWNER TO tourismpay;

--
-- Name: lp_positions; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.lp_positions (
    id character varying(36) NOT NULL,
    lp_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    pool_id character varying(30) NOT NULL,
    stablecoin character varying(10) NOT NULL,
    amount numeric(20,6) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    deposit_tx_hash character varying(128),
    locked_until bigint,
    created_at bigint NOT NULL,
    updated_at bigint
);


ALTER TABLE public.lp_positions OWNER TO tourismpay;

--
-- Name: lp_providers; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.lp_providers (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    entity_type character varying(20) NOT NULL,
    entity_name character varying(128) NOT NULL,
    tier character varying(20) DEFAULT 'bronze'::character varying NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    wallet_address character varying(128) NOT NULL,
    total_deposited numeric(20,6) DEFAULT 0 NOT NULL,
    total_earned numeric(20,6) DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE public.lp_providers OWNER TO tourismpay;

--
-- Name: lp_rebalance_events; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.lp_rebalance_events (
    id character varying(36) NOT NULL,
    from_pool character varying(30) NOT NULL,
    to_pool character varying(30) NOT NULL,
    amount numeric(20,6) NOT NULL,
    initiated_by character varying(36) NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    created_at bigint NOT NULL
);


ALTER TABLE public.lp_rebalance_events OWNER TO tourismpay;

--
-- Name: lp_rewards; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.lp_rewards (
    id character varying(36) NOT NULL,
    lp_id character varying(36) NOT NULL,
    pool_id character varying(30) NOT NULL,
    amount numeric(20,6) NOT NULL,
    period_start bigint NOT NULL,
    period_end bigint NOT NULL,
    created_at bigint NOT NULL
);


ALTER TABLE public.lp_rewards OWNER TO tourismpay;

--
-- Name: lp_withdrawals; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.lp_withdrawals (
    id character varying(36) NOT NULL,
    lp_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    position_id character varying(36) NOT NULL,
    pool_id character varying(30) NOT NULL,
    amount numeric(20,6) NOT NULL,
    destination_address character varying(128) NOT NULL,
    requires_multisig boolean DEFAULT false,
    status character varying(30) DEFAULT 'processing'::character varying NOT NULL,
    created_at bigint NOT NULL
);


ALTER TABLE public.lp_withdrawals OWNER TO tourismpay;

--
-- Name: merchant_payout_schedules; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.merchant_payout_schedules (
    id integer NOT NULL,
    merchant_id integer NOT NULL,
    frequency public.payout_frequency DEFAULT 'weekly'::public.payout_frequency NOT NULL,
    preferred_day integer DEFAULT 1 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    next_run_at timestamp without time zone,
    last_run_at timestamp without time zone,
    last_batch_id character varying(128),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.merchant_payout_schedules OWNER TO tourismpay;

--
-- Name: merchant_payout_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.merchant_payout_schedules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.merchant_payout_schedules_id_seq OWNER TO tourismpay;

--
-- Name: merchant_payout_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.merchant_payout_schedules_id_seq OWNED BY public.merchant_payout_schedules.id;


--
-- Name: merchant_products; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.merchant_products (
    id integer NOT NULL,
    establishment_id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    category character varying(100) DEFAULT 'general'::character varying NOT NULL,
    price numeric(12,2) NOT NULL,
    currency character varying(3) DEFAULT 'USD'::character varying NOT NULL,
    image_url text,
    sku character varying(100),
    available boolean DEFAULT true NOT NULL,
    featured boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.merchant_products OWNER TO tourismpay;

--
-- Name: merchant_products_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.merchant_products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.merchant_products_id_seq OWNER TO tourismpay;

--
-- Name: merchant_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.merchant_products_id_seq OWNED BY public.merchant_products.id;


--
-- Name: mesh_transactions; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.mesh_transactions (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    corridor_id character varying(50) NOT NULL,
    from_currency character varying(10) NOT NULL,
    to_currency character varying(10) NOT NULL,
    amount numeric(18,6) NOT NULL,
    converted_amount numeric(18,6) NOT NULL,
    fee_amount numeric(18,6) NOT NULL,
    exchange_rate numeric(18,8) NOT NULL,
    recipient_address character varying(500) NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    tx_hash character varying(200),
    created_at integer NOT NULL,
    completed_at integer
);


ALTER TABLE public.mesh_transactions OWNER TO tourismpay;

--
-- Name: noc_alert_thresholds; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.noc_alert_thresholds (
    id integer NOT NULL,
    metric character varying(64) NOT NULL,
    warn_min numeric(10,2),
    warn_max numeric(10,2),
    crit_min numeric(10,2),
    crit_max numeric(10,2),
    unit character varying(16) DEFAULT ''::character varying NOT NULL,
    label character varying(64) NOT NULL,
    updated_by character varying(64),
    updated_at bigint NOT NULL
);


ALTER TABLE public.noc_alert_thresholds OWNER TO tourismpay;

--
-- Name: noc_alert_thresholds_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.noc_alert_thresholds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.noc_alert_thresholds_id_seq OWNER TO tourismpay;

--
-- Name: noc_alert_thresholds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.noc_alert_thresholds_id_seq OWNED BY public.noc_alert_thresholds.id;


--
-- Name: noc_events; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.noc_events (
    id integer NOT NULL,
    type public.noc_event_type NOT NULL,
    severity character varying(16) DEFAULT 'info'::character varying NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    actor_id integer,
    actor_name character varying(255),
    target_id character varying(128),
    target_type character varying(64),
    metadata jsonb DEFAULT '{}'::jsonb,
    resolved_at bigint,
    created_at bigint NOT NULL
);


ALTER TABLE public.noc_events OWNER TO tourismpay;

--
-- Name: noc_events_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.noc_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.noc_events_id_seq OWNER TO tourismpay;

--
-- Name: noc_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.noc_events_id_seq OWNED BY public.noc_events.id;


--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.notification_preferences (
    id integer NOT NULL,
    user_id integer NOT NULL,
    bis_enabled boolean DEFAULT true NOT NULL,
    kyb_enabled boolean DEFAULT true NOT NULL,
    fraud_enabled boolean DEFAULT true NOT NULL,
    soc_enabled boolean DEFAULT true NOT NULL,
    system_enabled boolean DEFAULT true NOT NULL,
    report_enabled boolean DEFAULT true NOT NULL,
    in_app_enabled boolean DEFAULT true NOT NULL,
    email_enabled boolean DEFAULT false NOT NULL,
    quiet_hours_start character varying(5),
    quiet_hours_end character varying(5),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    wishlist_expiry_alerts boolean DEFAULT true NOT NULL,
    sentiment_alert_threshold integer
);


ALTER TABLE public.notification_preferences OWNER TO tourismpay;

--
-- Name: notification_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.notification_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_preferences_id_seq OWNER TO tourismpay;

--
-- Name: notification_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.notification_preferences_id_seq OWNED BY public.notification_preferences.id;


--
-- Name: pin_lockout_history; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.pin_lockout_history (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    tier integer DEFAULT 0 NOT NULL,
    locked_at integer NOT NULL,
    unlocks_at integer NOT NULL,
    failed_attempts integer DEFAULT 5 NOT NULL,
    resolved boolean DEFAULT false NOT NULL
);


ALTER TABLE public.pin_lockout_history OWNER TO tourismpay;

--
-- Name: ps_account_recovery; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.ps_account_recovery (
    id character varying(64) NOT NULL,
    user_id character varying(64) NOT NULL,
    method character varying(32) NOT NULL,
    token character varying(255) NOT NULL,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    expires_at bigint NOT NULL,
    completed_at bigint,
    created_at bigint NOT NULL
);


ALTER TABLE public.ps_account_recovery OWNER TO tourismpay;

--
-- Name: ps_api_keys; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.ps_api_keys (
    id character varying(64) NOT NULL,
    user_id character varying(64) NOT NULL,
    name character varying(255) NOT NULL,
    key_hash character varying(255) NOT NULL,
    key_prefix character varying(16) NOT NULL,
    environment character varying(16) DEFAULT 'sandbox'::character varying NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb,
    is_active boolean DEFAULT true NOT NULL,
    last_used_at bigint,
    expires_at bigint,
    rate_limit integer DEFAULT 1000,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE public.ps_api_keys OWNER TO tourismpay;

--
-- Name: ps_corridor_rate_limit_usage; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.ps_corridor_rate_limit_usage (
    id integer NOT NULL,
    corridor character varying(16) NOT NULL,
    window_start bigint NOT NULL,
    day_window_start bigint NOT NULL,
    tx_count integer DEFAULT 0 NOT NULL,
    volume_sum bigint DEFAULT 0 NOT NULL,
    currency character varying(8) DEFAULT 'USD'::character varying NOT NULL,
    last_updated_at bigint NOT NULL
);


ALTER TABLE public.ps_corridor_rate_limit_usage OWNER TO tourismpay;

--
-- Name: ps_corridor_rate_limit_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.ps_corridor_rate_limit_usage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ps_corridor_rate_limit_usage_id_seq OWNER TO tourismpay;

--
-- Name: ps_corridor_rate_limit_usage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.ps_corridor_rate_limit_usage_id_seq OWNED BY public.ps_corridor_rate_limit_usage.id;


--
-- Name: ps_corridor_rate_limits; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.ps_corridor_rate_limits (
    id integer NOT NULL,
    corridor character varying(16) NOT NULL,
    max_tx_per_minute integer DEFAULT 0 NOT NULL,
    max_volume_per_day bigint DEFAULT 0 NOT NULL,
    currency character varying(8) DEFAULT 'USD'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    notes text,
    created_by character varying(128),
    updated_by character varying(128),
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE public.ps_corridor_rate_limits OWNER TO tourismpay;

--
-- Name: ps_corridor_rate_limits_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.ps_corridor_rate_limits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ps_corridor_rate_limits_id_seq OWNER TO tourismpay;

--
-- Name: ps_corridor_rate_limits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.ps_corridor_rate_limits_id_seq OWNED BY public.ps_corridor_rate_limits.id;


--
-- Name: ps_fraud_rules; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.ps_fraud_rules (
    id integer NOT NULL,
    rule_id character varying(64) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    rule_type character varying(50) DEFAULT 'threshold'::character varying NOT NULL,
    conditions jsonb DEFAULT '{}'::jsonb,
    action character varying(50) DEFAULT 'flag'::character varying NOT NULL,
    severity public.fraud_alert_severity DEFAULT 'medium'::public.fraud_alert_severity NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    hit_count integer DEFAULT 0 NOT NULL,
    created_by integer,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE public.ps_fraud_rules OWNER TO tourismpay;

--
-- Name: ps_fraud_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.ps_fraud_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ps_fraud_rules_id_seq OWNER TO tourismpay;

--
-- Name: ps_fraud_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.ps_fraud_rules_id_seq OWNED BY public.ps_fraud_rules.id;


--
-- Name: ps_kill_switch_history; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.ps_kill_switch_history (
    id integer NOT NULL,
    corridor character varying(32) NOT NULL,
    action character varying(16) NOT NULL,
    actor_id integer,
    actor_name character varying(255),
    reason text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at bigint NOT NULL
);


ALTER TABLE public.ps_kill_switch_history OWNER TO tourismpay;

--
-- Name: ps_kill_switch_history_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.ps_kill_switch_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ps_kill_switch_history_id_seq OWNER TO tourismpay;

--
-- Name: ps_kill_switch_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.ps_kill_switch_history_id_seq OWNED BY public.ps_kill_switch_history.id;


--
-- Name: ps_kill_switch_state; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.ps_kill_switch_state (
    id integer NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    activated_by integer,
    activated_by_name character varying(255),
    reason text,
    activated_at bigint,
    deactivated_at bigint,
    updated_at bigint NOT NULL
);


ALTER TABLE public.ps_kill_switch_state OWNER TO tourismpay;

--
-- Name: ps_kill_switch_state_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.ps_kill_switch_state_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ps_kill_switch_state_id_seq OWNER TO tourismpay;

--
-- Name: ps_kill_switch_state_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.ps_kill_switch_state_id_seq OWNED BY public.ps_kill_switch_state.id;


--
-- Name: ps_kill_switches; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.ps_kill_switches (
    id integer NOT NULL,
    corridor character varying(32) NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    activated_by integer,
    activated_by_name character varying(255),
    reason text,
    activated_at bigint,
    deactivated_at bigint,
    deactivated_by integer,
    deactivated_by_name character varying(255),
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE public.ps_kill_switches OWNER TO tourismpay;

--
-- Name: ps_kill_switches_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.ps_kill_switches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ps_kill_switches_id_seq OWNER TO tourismpay;

--
-- Name: ps_kill_switches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.ps_kill_switches_id_seq OWNED BY public.ps_kill_switches.id;


--
-- Name: ps_ledger_entries; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.ps_ledger_entries (
    id character varying(64) NOT NULL,
    account_id character varying(64) NOT NULL,
    participant_id character varying(64) NOT NULL,
    ledger integer DEFAULT 1 NOT NULL,
    code integer DEFAULT 1 NOT NULL,
    debit_amount numeric(20,2) DEFAULT '0'::numeric NOT NULL,
    credit_amount numeric(20,2) DEFAULT '0'::numeric NOT NULL,
    currency character varying(8) NOT NULL,
    transfer_id character varying(64),
    remittance_id character varying(64),
    settlement_id character varying(64),
    tb_transfer_id character varying(128),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at bigint NOT NULL
);


ALTER TABLE public.ps_ledger_entries OWNER TO tourismpay;

--
-- Name: ps_notification_channels; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.ps_notification_channels (
    id character varying(64) NOT NULL,
    user_id character varying(64) NOT NULL,
    type character varying(32) NOT NULL,
    name character varying(255) NOT NULL,
    config jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true NOT NULL,
    last_tested_at bigint,
    created_at bigint NOT NULL
);


ALTER TABLE public.ps_notification_channels OWNER TO tourismpay;

--
-- Name: ps_participants; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.ps_participants (
    id character varying(64) NOT NULL,
    name character varying(255) NOT NULL,
    type public.participant_type NOT NULL,
    status public.participant_status DEFAULT 'active'::public.participant_status NOT NULL,
    country character varying(2) DEFAULT 'NG'::character varying NOT NULL,
    currency character varying(8) DEFAULT 'NGN'::character varying NOT NULL,
    tb_account_id character varying(128),
    mojaloop_fsp_id character varying(64),
    health_score integer DEFAULT 100 NOT NULL,
    last_health_check bigint,
    api_endpoint character varying(512),
    api_key_hash character varying(128),
    daily_limit numeric(20,2),
    monthly_limit numeric(20,2),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE public.ps_participants OWNER TO tourismpay;

--
-- Name: ps_reminder_emails; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.ps_reminder_emails (
    id character varying(64) NOT NULL,
    user_id character varying(64) NOT NULL,
    type character varying(64) NOT NULL,
    subject character varying(512) NOT NULL,
    body text NOT NULL,
    scheduled_at bigint NOT NULL,
    sent_at bigint,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    created_at bigint NOT NULL
);


ALTER TABLE public.ps_reminder_emails OWNER TO tourismpay;

--
-- Name: ps_settlements; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.ps_settlements (
    id character varying(64) NOT NULL,
    batch_id character varying(64) NOT NULL,
    participant_id character varying(64) NOT NULL,
    currency character varying(8) NOT NULL,
    total_amount numeric(20,2) NOT NULL,
    transaction_count integer DEFAULT 0 NOT NULL,
    status public.settlement_status DEFAULT 'pending'::public.settlement_status NOT NULL,
    tb_batch_id character varying(128),
    mojaloop_window_id character varying(64),
    settled_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE public.ps_settlements OWNER TO tourismpay;

--
-- Name: ps_two_factor_settings; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.ps_two_factor_settings (
    id integer NOT NULL,
    user_id character varying(64) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    method character varying(16),
    secret character varying(255),
    backup_codes jsonb DEFAULT '[]'::jsonb,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE public.ps_two_factor_settings OWNER TO tourismpay;

--
-- Name: ps_two_factor_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.ps_two_factor_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ps_two_factor_settings_id_seq OWNER TO tourismpay;

--
-- Name: ps_two_factor_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.ps_two_factor_settings_id_seq OWNED BY public.ps_two_factor_settings.id;


--
-- Name: ps_webhook_deliveries; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.ps_webhook_deliveries (
    id integer NOT NULL,
    delivery_id character varying(64) NOT NULL,
    webhook_id character varying(64) NOT NULL,
    event character varying(64) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    status public.ps_webhook_delivery_status DEFAULT 'pending'::public.ps_webhook_delivery_status NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 5 NOT NULL,
    next_retry_at bigint,
    last_attempt_at bigint,
    response_code integer,
    response_body text,
    response_time_ms integer,
    error_message text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE public.ps_webhook_deliveries OWNER TO tourismpay;

--
-- Name: ps_webhook_deliveries_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.ps_webhook_deliveries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ps_webhook_deliveries_id_seq OWNER TO tourismpay;

--
-- Name: ps_webhook_deliveries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.ps_webhook_deliveries_id_seq OWNED BY public.ps_webhook_deliveries.id;


--
-- Name: ps_webhooks; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.ps_webhooks (
    id integer NOT NULL,
    webhook_id character varying(64) NOT NULL,
    name character varying(255) NOT NULL,
    endpoint character varying(2048) NOT NULL,
    events text DEFAULT 'remittance.completed'::text NOT NULL,
    secret character varying(128) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    participant_id character varying(64),
    created_by integer,
    created_by_name character varying(255),
    last_delivery_at bigint,
    last_delivery_status character varying(16),
    total_deliveries integer DEFAULT 0 NOT NULL,
    failure_count integer DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE public.ps_webhooks OWNER TO tourismpay;

--
-- Name: ps_webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.ps_webhooks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ps_webhooks_id_seq OWNER TO tourismpay;

--
-- Name: ps_webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.ps_webhooks_id_seq OWNED BY public.ps_webhooks.id;


--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.push_subscriptions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth text NOT NULL,
    user_agent character varying(512),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.push_subscriptions OWNER TO tourismpay;

--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.push_subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.push_subscriptions_id_seq OWNER TO tourismpay;

--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.push_subscriptions_id_seq OWNED BY public.push_subscriptions.id;


--
-- Name: qr_payment_receipts; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.qr_payment_receipts (
    id integer NOT NULL,
    token character varying(128) NOT NULL,
    tourist_user_id integer,
    establishment_id integer,
    merchant_name character varying(255),
    amount_usd numeric(12,2) NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying NOT NULL,
    line_items jsonb,
    status character varying(50) DEFAULT 'completed'::character varying NOT NULL,
    pdf_url text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.qr_payment_receipts OWNER TO tourismpay;

--
-- Name: qr_payment_receipts_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.qr_payment_receipts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.qr_payment_receipts_id_seq OWNER TO tourismpay;

--
-- Name: qr_payment_receipts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.qr_payment_receipts_id_seq OWNED BY public.qr_payment_receipts.id;


--
-- Name: qr_payment_tokens; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.qr_payment_tokens (
    id integer NOT NULL,
    token character varying(128) NOT NULL,
    establishment_id integer NOT NULL,
    amount_usd numeric(18,6),
    currency character varying(10),
    description text,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    paid_at timestamp without time zone,
    paid_by_user_id integer,
    wallet_tx_id character varying(128),
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.qr_payment_tokens OWNER TO tourismpay;

--
-- Name: qr_payment_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.qr_payment_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.qr_payment_tokens_id_seq OWNER TO tourismpay;

--
-- Name: qr_payment_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.qr_payment_tokens_id_seq OWNED BY public.qr_payment_tokens.id;


--
-- Name: rate_alerts; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.rate_alerts (
    id integer NOT NULL,
    user_id character varying(64) NOT NULL,
    base_currency character varying(10) NOT NULL,
    target_currency character varying(10) NOT NULL,
    target_rate numeric(18,8) NOT NULL,
    condition public.rate_condition DEFAULT 'above'::public.rate_condition NOT NULL,
    status public.rate_alert_status DEFAULT 'active'::public.rate_alert_status NOT NULL,
    notify_email boolean DEFAULT true NOT NULL,
    notify_sms boolean DEFAULT false NOT NULL,
    triggered_at bigint,
    expires_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE public.rate_alerts OWNER TO tourismpay;

--
-- Name: rate_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.rate_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rate_alerts_id_seq OWNER TO tourismpay;

--
-- Name: rate_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.rate_alerts_id_seq OWNED BY public.rate_alerts.id;


--
-- Name: remittances; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.remittances (
    id character varying(64) NOT NULL,
    user_id integer NOT NULL,
    sender_currency public.remittance_currency NOT NULL,
    sender_amount numeric(20,8) NOT NULL,
    recipient_currency public.remittance_currency DEFAULT 'NGN'::public.remittance_currency NOT NULL,
    recipient_amount numeric(20,8),
    exchange_rate numeric(20,8),
    fee numeric(20,8) DEFAULT '0'::numeric NOT NULL,
    status public.remittance_status DEFAULT 'pending'::public.remittance_status NOT NULL,
    delivery_option public.delivery_option DEFAULT 'bank_transfer'::public.delivery_option NOT NULL,
    recipient_phone character varying(32),
    recipient_name character varying(255),
    recipient_bank character varying(64),
    recipient_account character varying(64),
    tb_transfer_id character varying(128),
    mojaloop_ref character varying(128),
    external_ref character varying(255),
    error_code character varying(64),
    error_message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    completed_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE public.remittances OWNER TO tourismpay;

--
-- Name: review_sentiment_cache; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.review_sentiment_cache (
    id integer NOT NULL,
    establishment_id integer NOT NULL,
    positive_percent integer NOT NULL,
    themes jsonb DEFAULT '[]'::jsonb NOT NULL,
    summary text NOT NULL,
    review_count integer DEFAULT 0 NOT NULL,
    generated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.review_sentiment_cache OWNER TO tourismpay;

--
-- Name: review_sentiment_cache_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.review_sentiment_cache_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.review_sentiment_cache_id_seq OWNER TO tourismpay;

--
-- Name: review_sentiment_cache_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.review_sentiment_cache_id_seq OWNED BY public.review_sentiment_cache.id;


--
-- Name: review_sentiment_history; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.review_sentiment_history (
    id integer NOT NULL,
    establishment_id integer NOT NULL,
    positive_percent integer NOT NULL,
    review_count integer DEFAULT 0 NOT NULL,
    snapshot_date date NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.review_sentiment_history OWNER TO tourismpay;

--
-- Name: review_sentiment_history_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.review_sentiment_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.review_sentiment_history_id_seq OWNER TO tourismpay;

--
-- Name: review_sentiment_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.review_sentiment_history_id_seq OWNED BY public.review_sentiment_history.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.role_permissions (
    id integer NOT NULL,
    role public.user_role NOT NULL,
    resource character varying(128) NOT NULL,
    action character varying(64) NOT NULL,
    granted boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO tourismpay;

--
-- Name: role_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.role_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.role_permissions_id_seq OWNER TO tourismpay;

--
-- Name: role_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.role_permissions_id_seq OWNED BY public.role_permissions.id;


--
-- Name: scheduled_payments; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.scheduled_payments (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    to_address character varying(255) NOT NULL,
    counterparty_name character varying(255),
    amount numeric(20,8) NOT NULL,
    currency character varying(20) NOT NULL,
    recurrence public.scheduled_payment_recurrence DEFAULT 'once'::public.scheduled_payment_recurrence NOT NULL,
    note character varying(500),
    reference character varying(100),
    status public.scheduled_payment_status DEFAULT 'active'::public.scheduled_payment_status NOT NULL,
    scheduled_at bigint NOT NULL,
    last_run_at bigint,
    next_run_at bigint,
    run_count integer DEFAULT 0 NOT NULL,
    failure_reason text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE public.scheduled_payments OWNER TO tourismpay;

--
-- Name: service_availability; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.service_availability (
    id integer NOT NULL,
    product_id integer NOT NULL,
    establishment_id integer NOT NULL,
    date character varying(10) NOT NULL,
    total_slots integer DEFAULT 0 NOT NULL,
    booked_slots integer DEFAULT 0 NOT NULL,
    is_blocked boolean DEFAULT false NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.service_availability OWNER TO tourismpay;

--
-- Name: service_availability_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.service_availability_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.service_availability_id_seq OWNER TO tourismpay;

--
-- Name: service_availability_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.service_availability_id_seq OWNED BY public.service_availability.id;


--
-- Name: service_health_alerts; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.service_health_alerts (
    id character varying(36) NOT NULL,
    service_key character varying(50) NOT NULL,
    last_alert_at integer NOT NULL,
    last_status character varying(20) DEFAULT 'unreachable'::character varying NOT NULL,
    alert_count integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.service_health_alerts OWNER TO tourismpay;

--
-- Name: service_health_history; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.service_health_history (
    id character varying(36) NOT NULL,
    service_key character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    http_status integer,
    response_ms integer,
    checked_at integer NOT NULL
);


ALTER TABLE public.service_health_history OWNER TO tourismpay;

--
-- Name: smart_contract_deployments; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.smart_contract_deployments (
    id character varying(36) NOT NULL,
    contract_name character varying(64) NOT NULL,
    network character varying(30) NOT NULL,
    contract_address character varying(128) NOT NULL,
    deploy_tx_hash character varying(128) NOT NULL,
    version character varying(20) NOT NULL,
    abi_hash character varying(128),
    deployer character varying(128) NOT NULL,
    supply_cap numeric(30,6),
    mint_cap_per_epoch numeric(20,6),
    burn_cap_per_epoch numeric(20,6),
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    audit_report_url character varying(500),
    created_at bigint NOT NULL
);


ALTER TABLE public.smart_contract_deployments OWNER TO tourismpay;

--
-- Name: smart_contract_events; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.smart_contract_events (
    id character varying(36) NOT NULL,
    contract_name character varying(64) NOT NULL,
    event_type character varying(64) NOT NULL,
    tx_hash character varying(128) NOT NULL,
    block_number integer NOT NULL,
    gas_used integer NOT NULL,
    from_address character varying(128),
    to_address character varying(128),
    amount numeric(30,6),
    nonce character varying(128),
    metadata text,
    created_at bigint NOT NULL
);


ALTER TABLE public.smart_contract_events OWNER TO tourismpay;

--
-- Name: soc_alerts; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.soc_alerts (
    id integer NOT NULL,
    alert_id character varying(30) NOT NULL,
    type public.soc_alert_type NOT NULL,
    severity public.fraud_alert_severity NOT NULL,
    status public.fraud_alert_status DEFAULT 'open'::public.fraud_alert_status NOT NULL,
    source character varying(100),
    title character varying(255) NOT NULL,
    description text,
    affected_system character varying(100),
    source_ip character varying(45),
    mitre_tactic character varying(100),
    mitre_id character varying(20),
    raw_payload jsonb,
    resolved_by integer,
    resolved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.soc_alerts OWNER TO tourismpay;

--
-- Name: soc_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.soc_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.soc_alerts_id_seq OWNER TO tourismpay;

--
-- Name: soc_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.soc_alerts_id_seq OWNED BY public.soc_alerts.id;


--
-- Name: stablecoin_limit_orders; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.stablecoin_limit_orders (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    direction character varying(10) NOT NULL,
    stablecoin character varying(10) DEFAULT 'USDC'::character varying NOT NULL,
    fiat_currency character varying(10) NOT NULL,
    amount numeric(20,6) NOT NULL,
    target_rate numeric(20,8) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    filled_at bigint,
    expires_at bigint,
    result_order_id character varying(36),
    created_at bigint NOT NULL
);


ALTER TABLE public.stablecoin_limit_orders OWNER TO tourismpay;

--
-- Name: stablecoin_offramp_requests; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.stablecoin_offramp_requests (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    status public.offramp_status DEFAULT 'quote'::public.offramp_status NOT NULL,
    source_stablecoin character varying(10) DEFAULT 'USDC'::character varying NOT NULL,
    source_amount numeric(20,6) NOT NULL,
    source_network character varying(32) DEFAULT 'stellar'::character varying,
    burn_tx_hash character varying(128),
    target_currency character varying(10) NOT NULL,
    target_amount numeric(20,6),
    payout_rail public.payment_rail NOT NULL,
    payout_ref character varying(255),
    recipient_name character varying(255),
    recipient_phone character varying(32),
    recipient_bank character varying(128),
    recipient_account character varying(64),
    recipient_country character varying(3),
    exchange_rate numeric(20,8),
    fee numeric(20,6) DEFAULT '0'::numeric,
    fee_percent numeric(6,4) DEFAULT '0'::numeric,
    spread_percent numeric(6,4) DEFAULT '0'::numeric,
    provider_name character varying(64),
    provider_ref character varying(255),
    mojaloop_ref character varying(128),
    tb_transfer_id character varying(128),
    kyc_verified boolean DEFAULT false,
    bis_reference_id character varying(64),
    fraud_score numeric(5,2),
    velocity_check_passed boolean,
    error_code character varying(64),
    error_message text,
    quote_expires_at bigint,
    completed_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE public.stablecoin_offramp_requests OWNER TO tourismpay;

--
-- Name: stablecoin_onramp_orders; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.stablecoin_onramp_orders (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    status public.onramp_status DEFAULT 'quote'::public.onramp_status NOT NULL,
    source_currency character varying(10) NOT NULL,
    source_amount numeric(20,6) NOT NULL,
    payment_rail public.payment_rail NOT NULL,
    payment_ref character varying(255),
    target_stablecoin character varying(10) DEFAULT 'USDC'::character varying NOT NULL,
    target_amount numeric(20,6),
    target_wallet_address character varying(128),
    target_network character varying(32) DEFAULT 'stellar'::character varying,
    exchange_rate numeric(20,8),
    fee numeric(20,6) DEFAULT '0'::numeric,
    fee_percent numeric(6,4) DEFAULT '0'::numeric,
    spread_percent numeric(6,4) DEFAULT '0'::numeric,
    mint_tx_hash character varying(128),
    provider_name character varying(64),
    provider_ref character varying(255),
    kyc_verified boolean DEFAULT false,
    bis_reference_id character varying(64),
    country character varying(3),
    mobile_number character varying(32),
    error_code character varying(64),
    error_message text,
    quote_expires_at bigint,
    completed_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE public.stablecoin_onramp_orders OWNER TO tourismpay;

--
-- Name: stablecoin_yield_positions; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.stablecoin_yield_positions (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    stablecoin character varying(10) DEFAULT 'USDC'::character varying NOT NULL,
    principal_amount numeric(20,6) NOT NULL,
    current_amount numeric(20,6) NOT NULL,
    apy_bps integer NOT NULL,
    protocol character varying(64) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    deposit_tx_hash character varying(128),
    withdraw_tx_hash character varying(128),
    accrued_yield numeric(20,6) DEFAULT '0'::numeric,
    last_accrual_at bigint,
    withdrawn_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE public.stablecoin_yield_positions OWNER TO tourismpay;

--
-- Name: staff_invites; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.staff_invites (
    id integer NOT NULL,
    token character varying(128) NOT NULL,
    establishment_id integer NOT NULL,
    inviter_user_id integer NOT NULL,
    email character varying(255) NOT NULL,
    role public.staff_role DEFAULT 'cashier'::public.staff_role NOT NULL,
    status public.staff_invite_status DEFAULT 'pending'::public.staff_invite_status NOT NULL,
    accepted_by_user_id integer,
    accepted_at timestamp without time zone,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.staff_invites OWNER TO tourismpay;

--
-- Name: staff_invites_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.staff_invites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.staff_invites_id_seq OWNER TO tourismpay;

--
-- Name: staff_invites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.staff_invites_id_seq OWNED BY public.staff_invites.id;


--
-- Name: tip_configs; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.tip_configs (
    id character varying(36) NOT NULL,
    establishment_id integer,
    jurisdiction_code character varying(8),
    custom_percentages jsonb DEFAULT '[]'::jsonb,
    distribution_type character varying(16) DEFAULT 'pool'::character varying,
    pool_split_rules jsonb DEFAULT '[]'::jsonb,
    is_enabled boolean DEFAULT true,
    created_at bigint,
    updated_at bigint
);


ALTER TABLE public.tip_configs OWNER TO tourismpay;

--
-- Name: tourism_events; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.tourism_events (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    country character varying(2) NOT NULL,
    city character varying(100),
    category character varying(50),
    expected_attendees integer,
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tourism_events OWNER TO tourismpay;

--
-- Name: tourism_events_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.tourism_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tourism_events_id_seq OWNER TO tourismpay;

--
-- Name: tourism_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.tourism_events_id_seq OWNED BY public.tourism_events.id;


--
-- Name: tourist_bookings; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.tourist_bookings (
    id integer NOT NULL,
    user_id integer NOT NULL,
    establishment_id integer NOT NULL,
    service_type character varying(64) DEFAULT 'general'::character varying NOT NULL,
    service_name text NOT NULL,
    booking_date timestamp without time zone NOT NULL,
    party_size integer DEFAULT 1 NOT NULL,
    price_usd numeric(18,6) DEFAULT '0'::numeric NOT NULL,
    currency character varying(10) DEFAULT 'USDC'::character varying NOT NULL,
    status public.booking_status DEFAULT 'pending'::public.booking_status NOT NULL,
    notes text,
    confirmation_code character varying(32),
    wallet_tx_id character varying(128),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    reminder_enabled boolean DEFAULT true NOT NULL,
    reminder_sent_at timestamp without time zone,
    tourist_reminder_sent_at timestamp without time zone,
    product_id integer,
    booking_date_str character varying(10)
);


ALTER TABLE public.tourist_bookings OWNER TO tourismpay;

--
-- Name: tourist_bookings_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.tourist_bookings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tourist_bookings_id_seq OWNER TO tourismpay;

--
-- Name: tourist_bookings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.tourist_bookings_id_seq OWNED BY public.tourist_bookings.id;


--
-- Name: tourist_budgets; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.tourist_budgets (
    id integer NOT NULL,
    user_id integer NOT NULL,
    daily_limit_usd numeric(18,6) DEFAULT '100'::numeric NOT NULL,
    weekly_limit_usd numeric(18,6) DEFAULT '500'::numeric NOT NULL,
    trip_limit_usd numeric(18,6),
    alert_at_80_percent boolean DEFAULT true NOT NULL,
    alert_at_100_percent boolean DEFAULT true NOT NULL,
    categories jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tourist_budgets OWNER TO tourismpay;

--
-- Name: tourist_budgets_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.tourist_budgets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tourist_budgets_id_seq OWNER TO tourismpay;

--
-- Name: tourist_budgets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.tourist_budgets_id_seq OWNED BY public.tourist_budgets.id;


--
-- Name: tourist_concierge_sessions; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.tourist_concierge_sessions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    messages jsonb DEFAULT '[]'::jsonb NOT NULL,
    context jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tourist_concierge_sessions OWNER TO tourismpay;

--
-- Name: tourist_concierge_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.tourist_concierge_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tourist_concierge_sessions_id_seq OWNER TO tourismpay;

--
-- Name: tourist_concierge_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.tourist_concierge_sessions_id_seq OWNED BY public.tourist_concierge_sessions.id;


--
-- Name: tourist_deal_redemptions; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.tourist_deal_redemptions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    deal_id integer NOT NULL,
    establishment_id integer,
    redemption_code character varying(32) NOT NULL,
    status character varying(32) DEFAULT 'redeemed'::character varying NOT NULL,
    redeemed_at timestamp without time zone DEFAULT now() NOT NULL,
    confirmed_at timestamp without time zone,
    confirmed_by integer,
    notes text,
    review_prompted_at timestamp without time zone
);


ALTER TABLE public.tourist_deal_redemptions OWNER TO tourismpay;

--
-- Name: tourist_deal_redemptions_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.tourist_deal_redemptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tourist_deal_redemptions_id_seq OWNER TO tourismpay;

--
-- Name: tourist_deal_redemptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.tourist_deal_redemptions_id_seq OWNED BY public.tourist_deal_redemptions.id;


--
-- Name: tourist_deal_wishlists; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.tourist_deal_wishlists (
    id integer NOT NULL,
    user_id integer NOT NULL,
    deal_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    alerted_at timestamp without time zone
);


ALTER TABLE public.tourist_deal_wishlists OWNER TO tourismpay;

--
-- Name: tourist_deal_wishlists_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.tourist_deal_wishlists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tourist_deal_wishlists_id_seq OWNER TO tourismpay;

--
-- Name: tourist_deal_wishlists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.tourist_deal_wishlists_id_seq OWNED BY public.tourist_deal_wishlists.id;


--
-- Name: tourist_deals; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.tourist_deals (
    id integer NOT NULL,
    establishment_id integer NOT NULL,
    title character varying(128) NOT NULL,
    description text,
    discount_percent integer DEFAULT 0 NOT NULL,
    discount_amount_usd numeric(18,6),
    promo_code character varying(32),
    category character varying(64) DEFAULT 'general'::character varying NOT NULL,
    image_url text,
    valid_from timestamp without time zone NOT NULL,
    valid_to timestamp without time zone NOT NULL,
    max_redemptions integer,
    redemption_count integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    visibility_score integer DEFAULT 0 NOT NULL,
    boosted_until timestamp without time zone,
    boosted_at timestamp without time zone,
    boost_budget_usd numeric(12,2),
    boost_spent_usd numeric(12,2) DEFAULT '0'::numeric NOT NULL
);


ALTER TABLE public.tourist_deals OWNER TO tourismpay;

--
-- Name: tourist_deals_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.tourist_deals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tourist_deals_id_seq OWNER TO tourismpay;

--
-- Name: tourist_deals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.tourist_deals_id_seq OWNED BY public.tourist_deals.id;


--
-- Name: tourist_itineraries; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.tourist_itineraries (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title character varying(128) NOT NULL,
    destination character varying(128),
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    budget_usd numeric(18,6),
    is_public boolean DEFAULT false NOT NULL,
    cover_image_url text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    status character varying(32) DEFAULT 'draft'::character varying NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying NOT NULL,
    description text,
    share_token character varying(64),
    share_export_url text
);


ALTER TABLE public.tourist_itineraries OWNER TO tourismpay;

--
-- Name: tourist_itineraries_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.tourist_itineraries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tourist_itineraries_id_seq OWNER TO tourismpay;

--
-- Name: tourist_itineraries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.tourist_itineraries_id_seq OWNED BY public.tourist_itineraries.id;


--
-- Name: tourist_itinerary_items; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.tourist_itinerary_items (
    id integer NOT NULL,
    itinerary_id integer NOT NULL,
    day_number integer DEFAULT 1 NOT NULL,
    order_in_day integer DEFAULT 1 NOT NULL,
    establishment_id integer,
    booking_id integer,
    deal_id integer,
    title character varying(255) NOT NULL,
    notes text,
    start_time character varying(10),
    end_time character varying(10),
    estimated_cost_usd numeric(18,2) DEFAULT '0'::numeric,
    item_type character varying(32) DEFAULT 'activity'::character varying NOT NULL,
    status character varying(32) DEFAULT 'planned'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tourist_itinerary_items OWNER TO tourismpay;

--
-- Name: tourist_itinerary_items_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.tourist_itinerary_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tourist_itinerary_items_id_seq OWNER TO tourismpay;

--
-- Name: tourist_itinerary_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.tourist_itinerary_items_id_seq OWNED BY public.tourist_itinerary_items.id;


--
-- Name: tourist_onboarding_state; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.tourist_onboarding_state (
    id integer NOT NULL,
    user_id integer NOT NULL,
    step integer DEFAULT 1 NOT NULL,
    completed_steps jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tourist_onboarding_state OWNER TO tourismpay;

--
-- Name: tourist_onboarding_state_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.tourist_onboarding_state_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tourist_onboarding_state_id_seq OWNER TO tourismpay;

--
-- Name: tourist_onboarding_state_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.tourist_onboarding_state_id_seq OWNED BY public.tourist_onboarding_state.id;


--
-- Name: tourist_profiles; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.tourist_profiles (
    id integer NOT NULL,
    user_id integer NOT NULL,
    home_currency character varying(10) DEFAULT 'USD'::character varying NOT NULL,
    home_country character varying(3) DEFAULT 'US'::character varying NOT NULL,
    preferred_language character varying(10) DEFAULT 'en'::character varying NOT NULL,
    linked_card_last4 character varying(4),
    linked_card_brand character varying(32),
    onboarding_completed boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tourist_profiles OWNER TO tourismpay;

--
-- Name: tourist_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.tourist_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tourist_profiles_id_seq OWNER TO tourismpay;

--
-- Name: tourist_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.tourist_profiles_id_seq OWNED BY public.tourist_profiles.id;


--
-- Name: tourist_reviews; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.tourist_reviews (
    id integer NOT NULL,
    user_id integer NOT NULL,
    establishment_id integer NOT NULL,
    booking_id integer,
    rating integer NOT NULL,
    title character varying(128),
    body text,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    photos jsonb DEFAULT '[]'::jsonb NOT NULL,
    helpful_votes integer DEFAULT 0 NOT NULL,
    is_verified_purchase boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    merchant_response text,
    merchant_responded_at timestamp without time zone
);


ALTER TABLE public.tourist_reviews OWNER TO tourismpay;

--
-- Name: tourist_reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.tourist_reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tourist_reviews_id_seq OWNER TO tourismpay;

--
-- Name: tourist_reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.tourist_reviews_id_seq OWNED BY public.tourist_reviews.id;


--
-- Name: tourist_topups; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.tourist_topups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    amount_usd numeric(18,6) NOT NULL,
    target_currency character varying(10) DEFAULT 'USDC'::character varying NOT NULL,
    fx_rate numeric(18,8) DEFAULT '1'::numeric NOT NULL,
    credited_amount numeric(18,6),
    stripe_payment_intent_id character varying(128),
    stripe_session_id character varying(128),
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tourist_topups OWNER TO tourismpay;

--
-- Name: tourist_topups_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.tourist_topups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tourist_topups_id_seq OWNER TO tourismpay;

--
-- Name: tourist_topups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.tourist_topups_id_seq OWNED BY public.tourist_topups.id;


--
-- Name: tourist_trip_summaries; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.tourist_trip_summaries (
    id integer NOT NULL,
    user_id integer NOT NULL,
    date_from timestamp without time zone NOT NULL,
    date_to timestamp without time zone NOT NULL,
    total_spent_usd numeric(18,6) DEFAULT '0'::numeric NOT NULL,
    total_points_earned integer DEFAULT 0 NOT NULL,
    payment_count integer DEFAULT 0 NOT NULL,
    establishment_count integer DEFAULT 0 NOT NULL,
    report_url text,
    report_key text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tourist_trip_summaries OWNER TO tourismpay;

--
-- Name: tourist_trip_summaries_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.tourist_trip_summaries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tourist_trip_summaries_id_seq OWNER TO tourismpay;

--
-- Name: tourist_trip_summaries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.tourist_trip_summaries_id_seq OWNED BY public.tourist_trip_summaries.id;


--
-- Name: trusted_devices; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.trusted_devices (
    id integer NOT NULL,
    user_id character varying(64) NOT NULL,
    device_fingerprint character varying(255) NOT NULL,
    device_name character varying(255),
    device_type character varying(100),
    last_used_at bigint NOT NULL,
    expires_at bigint,
    created_at bigint NOT NULL
);


ALTER TABLE public.trusted_devices OWNER TO tourismpay;

--
-- Name: trusted_devices_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.trusted_devices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.trusted_devices_id_seq OWNER TO tourismpay;

--
-- Name: trusted_devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.trusted_devices_id_seq OWNED BY public.trusted_devices.id;


--
-- Name: user_notifications; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.user_notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    category public.notification_category DEFAULT 'system'::public.notification_category NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    action_url character varying(500),
    action_label character varying(100),
    is_read boolean DEFAULT false NOT NULL,
    read_at timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_notifications OWNER TO tourismpay;

--
-- Name: user_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.user_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_notifications_id_seq OWNER TO tourismpay;

--
-- Name: user_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.user_notifications_id_seq OWNED BY public.user_notifications.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.users (
    id integer NOT NULL,
    open_id character varying(64) NOT NULL,
    name text,
    email character varying(320),
    login_method character varying(64),
    role public.user_role DEFAULT 'user'::public.user_role NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    last_signed_in timestamp without time zone DEFAULT now() NOT NULL,
    login_count integer DEFAULT 0 NOT NULL,
    onboarding_completed boolean DEFAULT false NOT NULL,
    theme character varying(16) DEFAULT 'dark'::character varying,
    preferred_language character varying(8) DEFAULT 'en'::character varying,
    preferred_currency character varying(8) DEFAULT 'USDC'::character varying
);


ALTER TABLE public.users OWNER TO tourismpay;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: tourismpay
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO tourismpay;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tourismpay
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: verifiable_credentials; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.verifiable_credentials (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    type character varying(200) NOT NULL,
    issuer character varying(200) NOT NULL,
    subject character varying(500) NOT NULL,
    credential_data text NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    expires_at integer,
    revoked_at integer,
    created_at integer NOT NULL
);


ALTER TABLE public.verifiable_credentials OWNER TO tourismpay;

--
-- Name: wallet_balance_alerts; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.wallet_balance_alerts (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    currency character varying(20) NOT NULL,
    threshold numeric(20,6) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at integer NOT NULL,
    updated_at integer NOT NULL
);


ALTER TABLE public.wallet_balance_alerts OWNER TO tourismpay;

--
-- Name: wallet_balances; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.wallet_balances (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    currency character varying(20) NOT NULL,
    balance numeric(20,6) DEFAULT '0'::numeric NOT NULL,
    locked_balance numeric(20,6) DEFAULT '0'::numeric NOT NULL,
    wallet_address character varying(100),
    network character varying(50),
    created_at integer NOT NULL,
    updated_at integer NOT NULL
);


ALTER TABLE public.wallet_balances OWNER TO tourismpay;

--
-- Name: wallet_recurring_payments; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.wallet_recurring_payments (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    currency character varying(20) NOT NULL,
    recipient_address character varying(200) NOT NULL,
    recipient_name character varying(200),
    amount numeric(20,6) NOT NULL,
    note text,
    frequency public.recurring_payment_frequency NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    next_run_at bigint NOT NULL,
    last_run_at bigint,
    run_count integer DEFAULT 0 NOT NULL,
    failure_reason text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE public.wallet_recurring_payments OWNER TO tourismpay;

--
-- Name: wallet_spending_limits; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.wallet_spending_limits (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    currency character varying(20) NOT NULL,
    period character varying(10) DEFAULT 'daily'::character varying NOT NULL,
    limit_amount numeric(20,6) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at integer NOT NULL,
    updated_at integer NOT NULL
);


ALTER TABLE public.wallet_spending_limits OWNER TO tourismpay;

--
-- Name: wallet_transactions; Type: TABLE; Schema: public; Owner: tourismpay
--

CREATE TABLE public.wallet_transactions (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    type character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    from_currency character varying(20) NOT NULL,
    to_currency character varying(20),
    amount numeric(20,6) NOT NULL,
    to_amount numeric(20,6),
    fee numeric(20,6) DEFAULT '0'::numeric NOT NULL,
    counterparty character varying(200),
    counterparty_address character varying(100),
    reference character varying(100),
    note text,
    tx_hash character varying(100),
    completed_at integer,
    created_at integer NOT NULL
);


ALTER TABLE public.wallet_transactions OWNER TO tourismpay;

--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: tourismpay
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: bis_auto_flag_config id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_auto_flag_config ALTER COLUMN id SET DEFAULT nextval('public.bis_auto_flag_config_id_seq'::regclass);


--
-- Name: bis_auto_flags id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_auto_flags ALTER COLUMN id SET DEFAULT nextval('public.bis_auto_flags_id_seq'::regclass);


--
-- Name: bis_directors id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_directors ALTER COLUMN id SET DEFAULT nextval('public.bis_directors_id_seq'::regclass);


--
-- Name: bis_export_schedules id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_export_schedules ALTER COLUMN id SET DEFAULT nextval('public.bis_export_schedules_id_seq'::regclass);


--
-- Name: bis_investigations id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_investigations ALTER COLUMN id SET DEFAULT nextval('public.bis_investigations_id_seq'::regclass);


--
-- Name: bis_kill_switch_activations id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_kill_switch_activations ALTER COLUMN id SET DEFAULT nextval('public.bis_kill_switch_activations_id_seq'::regclass);


--
-- Name: bis_report_exports id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_report_exports ALTER COLUMN id SET DEFAULT nextval('public.bis_report_exports_id_seq'::regclass);


--
-- Name: channel_connections id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.channel_connections ALTER COLUMN id SET DEFAULT nextval('public.channel_connections_id_seq'::regclass);


--
-- Name: establishment_score_snapshots id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.establishment_score_snapshots ALTER COLUMN id SET DEFAULT nextval('public.establishment_score_snapshots_id_seq'::regclass);


--
-- Name: establishments id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.establishments ALTER COLUMN id SET DEFAULT nextval('public.establishments_id_seq'::regclass);


--
-- Name: exchange_rate_overrides id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.exchange_rate_overrides ALTER COLUMN id SET DEFAULT nextval('public.exchange_rate_overrides_id_seq'::regclass);


--
-- Name: fraud_alerts id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.fraud_alerts ALTER COLUMN id SET DEFAULT nextval('public.fraud_alerts_id_seq'::regclass);


--
-- Name: itinerary_changelog id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.itinerary_changelog ALTER COLUMN id SET DEFAULT nextval('public.itinerary_changelog_id_seq'::regclass);


--
-- Name: itinerary_collaborators id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.itinerary_collaborators ALTER COLUMN id SET DEFAULT nextval('public.itinerary_collaborators_id_seq'::regclass);


--
-- Name: kyb_applications id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.kyb_applications ALTER COLUMN id SET DEFAULT nextval('public.kyb_applications_id_seq'::regclass);


--
-- Name: kyb_documents id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.kyb_documents ALTER COLUMN id SET DEFAULT nextval('public.kyb_documents_id_seq'::regclass);


--
-- Name: kyc_verification_records id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.kyc_verification_records ALTER COLUMN id SET DEFAULT nextval('public.kyc_verification_records_id_seq'::regclass);


--
-- Name: login_history id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.login_history ALTER COLUMN id SET DEFAULT nextval('public.login_history_id_seq'::regclass);


--
-- Name: merchant_payout_schedules id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.merchant_payout_schedules ALTER COLUMN id SET DEFAULT nextval('public.merchant_payout_schedules_id_seq'::regclass);


--
-- Name: merchant_products id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.merchant_products ALTER COLUMN id SET DEFAULT nextval('public.merchant_products_id_seq'::regclass);


--
-- Name: noc_alert_thresholds id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.noc_alert_thresholds ALTER COLUMN id SET DEFAULT nextval('public.noc_alert_thresholds_id_seq'::regclass);


--
-- Name: noc_events id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.noc_events ALTER COLUMN id SET DEFAULT nextval('public.noc_events_id_seq'::regclass);


--
-- Name: notification_preferences id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.notification_preferences ALTER COLUMN id SET DEFAULT nextval('public.notification_preferences_id_seq'::regclass);


--
-- Name: ps_corridor_rate_limit_usage id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_corridor_rate_limit_usage ALTER COLUMN id SET DEFAULT nextval('public.ps_corridor_rate_limit_usage_id_seq'::regclass);


--
-- Name: ps_corridor_rate_limits id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_corridor_rate_limits ALTER COLUMN id SET DEFAULT nextval('public.ps_corridor_rate_limits_id_seq'::regclass);


--
-- Name: ps_fraud_rules id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_fraud_rules ALTER COLUMN id SET DEFAULT nextval('public.ps_fraud_rules_id_seq'::regclass);


--
-- Name: ps_kill_switch_history id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_kill_switch_history ALTER COLUMN id SET DEFAULT nextval('public.ps_kill_switch_history_id_seq'::regclass);


--
-- Name: ps_kill_switch_state id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_kill_switch_state ALTER COLUMN id SET DEFAULT nextval('public.ps_kill_switch_state_id_seq'::regclass);


--
-- Name: ps_kill_switches id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_kill_switches ALTER COLUMN id SET DEFAULT nextval('public.ps_kill_switches_id_seq'::regclass);


--
-- Name: ps_two_factor_settings id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_two_factor_settings ALTER COLUMN id SET DEFAULT nextval('public.ps_two_factor_settings_id_seq'::regclass);


--
-- Name: ps_webhook_deliveries id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_webhook_deliveries ALTER COLUMN id SET DEFAULT nextval('public.ps_webhook_deliveries_id_seq'::regclass);


--
-- Name: ps_webhooks id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_webhooks ALTER COLUMN id SET DEFAULT nextval('public.ps_webhooks_id_seq'::regclass);


--
-- Name: push_subscriptions id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.push_subscriptions ALTER COLUMN id SET DEFAULT nextval('public.push_subscriptions_id_seq'::regclass);


--
-- Name: qr_payment_receipts id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.qr_payment_receipts ALTER COLUMN id SET DEFAULT nextval('public.qr_payment_receipts_id_seq'::regclass);


--
-- Name: qr_payment_tokens id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.qr_payment_tokens ALTER COLUMN id SET DEFAULT nextval('public.qr_payment_tokens_id_seq'::regclass);


--
-- Name: rate_alerts id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.rate_alerts ALTER COLUMN id SET DEFAULT nextval('public.rate_alerts_id_seq'::regclass);


--
-- Name: review_sentiment_cache id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.review_sentiment_cache ALTER COLUMN id SET DEFAULT nextval('public.review_sentiment_cache_id_seq'::regclass);


--
-- Name: review_sentiment_history id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.review_sentiment_history ALTER COLUMN id SET DEFAULT nextval('public.review_sentiment_history_id_seq'::regclass);


--
-- Name: role_permissions id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.role_permissions ALTER COLUMN id SET DEFAULT nextval('public.role_permissions_id_seq'::regclass);


--
-- Name: service_availability id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.service_availability ALTER COLUMN id SET DEFAULT nextval('public.service_availability_id_seq'::regclass);


--
-- Name: soc_alerts id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.soc_alerts ALTER COLUMN id SET DEFAULT nextval('public.soc_alerts_id_seq'::regclass);


--
-- Name: staff_invites id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.staff_invites ALTER COLUMN id SET DEFAULT nextval('public.staff_invites_id_seq'::regclass);


--
-- Name: tourism_events id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourism_events ALTER COLUMN id SET DEFAULT nextval('public.tourism_events_id_seq'::regclass);


--
-- Name: tourist_bookings id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_bookings ALTER COLUMN id SET DEFAULT nextval('public.tourist_bookings_id_seq'::regclass);


--
-- Name: tourist_budgets id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_budgets ALTER COLUMN id SET DEFAULT nextval('public.tourist_budgets_id_seq'::regclass);


--
-- Name: tourist_concierge_sessions id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_concierge_sessions ALTER COLUMN id SET DEFAULT nextval('public.tourist_concierge_sessions_id_seq'::regclass);


--
-- Name: tourist_deal_redemptions id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_deal_redemptions ALTER COLUMN id SET DEFAULT nextval('public.tourist_deal_redemptions_id_seq'::regclass);


--
-- Name: tourist_deal_wishlists id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_deal_wishlists ALTER COLUMN id SET DEFAULT nextval('public.tourist_deal_wishlists_id_seq'::regclass);


--
-- Name: tourist_deals id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_deals ALTER COLUMN id SET DEFAULT nextval('public.tourist_deals_id_seq'::regclass);


--
-- Name: tourist_itineraries id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_itineraries ALTER COLUMN id SET DEFAULT nextval('public.tourist_itineraries_id_seq'::regclass);


--
-- Name: tourist_itinerary_items id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_itinerary_items ALTER COLUMN id SET DEFAULT nextval('public.tourist_itinerary_items_id_seq'::regclass);


--
-- Name: tourist_onboarding_state id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_onboarding_state ALTER COLUMN id SET DEFAULT nextval('public.tourist_onboarding_state_id_seq'::regclass);


--
-- Name: tourist_profiles id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_profiles ALTER COLUMN id SET DEFAULT nextval('public.tourist_profiles_id_seq'::regclass);


--
-- Name: tourist_reviews id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_reviews ALTER COLUMN id SET DEFAULT nextval('public.tourist_reviews_id_seq'::regclass);


--
-- Name: tourist_topups id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_topups ALTER COLUMN id SET DEFAULT nextval('public.tourist_topups_id_seq'::regclass);


--
-- Name: tourist_trip_summaries id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_trip_summaries ALTER COLUMN id SET DEFAULT nextval('public.tourist_trip_summaries_id_seq'::regclass);


--
-- Name: trusted_devices id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.trusted_devices ALTER COLUMN id SET DEFAULT nextval('public.trusted_devices_id_seq'::regclass);


--
-- Name: user_notifications id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.user_notifications ALTER COLUMN id SET DEFAULT nextval('public.user_notifications_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: tourismpay
--

COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM stdin;
1	e8abaa56ab9b71d2e2ae648699002ccfdb26bc1819636ea6d9cd504d8e72e169	1771826168765
2	669346030376de74c2ef9595ec15e08a661d29802ff2b45e58afb78244b4cd37	1771828393832
3	5dffa7a99deb163e7e750c9140fb5e9f3fc3772e9e5a78c59c3f511f265d9cc9	1771833764442
4	80eeaf7993d1b2ec4627a302607a146d3715026fa0ed3814196ee7dfc79eec6d	1771834915626
5	2cae35d806773b4e99f5078bf079c881d0e72d50a611b0b4518cc56511732b86	1771837699081
6	e96e6a06416a64f97fb0ea97cebbb0339196f8bfd058a7aef6500fc8130401e1	1771929925504
7	15801ee3b9a22a1fc473e421f5238ae44ca2262fe6a39da3b0036dcd2660a898	1771934250142
8	d0439a2d0a05bd9a1e925fc6500891d51aaf91308d835c2df5ab9eb2fdd105e4	1771937092825
9	180bbda8b065c5adba3feadf5d2596a88271369f2f1cfdcb6d029efa0e6dbe72	1771937518811
10	0f91843abe6112cfbdd7ffc8bbc4368ea29a79e0dac15e760dc884b0d6ea09a9	1771975035185
11	0b647462d59ab1c30a92678f08cccf2d60b97242e856f8a2d3e12f5e20d06123	1771978896116
12	4983f36f55171da08a9bbad3c38ab5868f9f12000b9502f1da7635f82bd62641	1771999617964
13	7c3d454cedf34c0c19be6f9dac5cb417a7edb172eb000490863f537bc1674ee8	1772000151902
14	ea4de4f79733bf825c41d80778e861c09f4183858d5af862fc7677511cc17f88	1772002354635
15	cd12b7e4b17a58b581d780d0bb16d5ed1ab7434b3d9c788ac27d9faa1814a632	1772003318318
16	20801bbe44f100e0ac1c080e83c835cdc01f34597abbdc470517a4ce76a1ceb9	1772004035171
17	d8aaa66cec5dc8972b27f45ad191352fc4559439a8534115aebcd4572ffc6720	1772007805335
18	8b92b2099fa50d632270fb9cb7a803198bb77fb948ce3f27cf8e6f3a6f58dac0	1772008547599
19	9caa226e55f23c17a78f7159c6d0a7dc05d6e2547e9dd082d6662235c70bd372	1772009530497
20	5f379b57980eb3fcb539309d2628d51fcf20f21050fe9b324d52f7305fe1eb1b	1772019387911
21	5ca6e083979c78f6717e87a8dc4abc674ce74aff44978efc4aa1de6239f13f65	1772029286616
22	d46f0f2cbba7b06efe21c55dd5b22a8e63718790eda241d4d826903e3acaed4f	1772047315042
23	a024fea5110fe57269473de3b58df3fe03e00792ddc043d5ebe3f4e333b7f189	1772049171512
24	9a494ec4b3c722991257180e46422187c636f4cecacc63a5dbc0a49edae43181	1772058876163
25	a081b5c776342c96ae5c9d15a4b5998a59789c441f314244233be4fc0948be0d	1772059474629
26	4f9f523f81b14d0204977d9db75df281baffafb41b64ea2c2489d6f8582179d7	1772061203167
27	4bd5c0b0c13d2bf9da18a85ddb29da3e91a8c9952baa237df2e6f7c9ff68a2bd	1772090908263
28	613056ec4fd72f27beea306a5c678e70f3dd5c516c1ab7b4e310a94ad97820fe	1772093574445
29	27dff1db076e2b79bd74472df88e95b2b4865a4f6484511e130dd653508eee32	1772093852881
30	afdd090b2f3d0d232fe208b570695d2ace08db0c9cf2a7194a2b7599dbe5c9d0	1772099362321
31	63ff95ea15cb431e9a39ccb6de6fde072ace30a5e6f0f9e907da275c43fc8c65	1772100850254
32	0fdfd6809a62a1d1a484664948094fc23982c85ea82646079da5b937ec1b4718	1772102086104
33	954c09abfd3399e043fab5e8ceec283e64e22a8c2eac6fa4c09b2fbd32c4ff89	1772105700684
34	9b988689afbcbf4fc27d57f48d316bef127bebb3cbd01a5f98da5266abbdb5c3	1772109720545
35	6ecb2b83b438e20fb9c582f0a6e6983c750c09a2d8b9d5bbabedcc7a439594b6	1772112140924
36	357c17889fda62f84682e3e783bd3b77499fd5c3f9e6c095937df0efc23abcc2	1772114328449
37	e1f81a442850f095c1e4546a29fff0c89c924f41e6eabbfaa04a97fd6e1e40e6	1772116762397
38	799a6885dfc31c35738bffa61eda5623fbdac212b5e30834ce16af4ffa4b8685	1772120254188
39	f627d9c6b20a0515f6171e0b3fd060fe817681a4fe2a7e991e09453599b02419	1772132370909
40	a400fb5a6f910629951306dd6267a8254f2145f9ee1682ae68513f6ed10e39c8	1772139384294
41	dee7e08909e9ddb50aa92c5012df128815b29bb2091b85b23d994d1ed0ddec13	1772165733355
42	29b3eddaf6200dd5e092f085c6ea4bc3b14c27708af8f05bd941038071922e43	1772171183539
43	ec9c13a077da2d2ae411fd6bdbce7ebbd08c7cfce98f42d5ab56b31d9eee39be	1772173189063
44	dc6d74ecaf3a41197bd13bfbb7a2d3fb162e017fe5d9d19a9f060c712bdc2900	1772317607191
45	281bc9b1c64c068a22f066e97736f4ac236a61ac572ef3431b7f3182102f6672	1772320188835
46	a0677d13de89a5415f0c3cb63ed1315e44d9eb6c43537d3f9ee6be2ccfb62333	1772331546395
47	1e247482210d4e617836fd750fb5b2de40be8be0135a34059e218622012b707a	1772332936246
48	422af6cd95eb5d27ba4d623088b81ef4b28081d96b1975b89884ce569e8b97ea	1772333761909
49	22cff780ec8409a30ae021060e207a60982703d5d3a3b7bb9e63e5226a6f7a13	1772334829586
50	919c92afb07fa892f218e0d26ef3fbeed91c70b63806346245639ec932de724a	1772335561645
51	979cd183edae7a78e648e6aeda51c140434445728c78f0cccd2a55d3252c9b2c	1772335604814
52	25370878b6c66136b3a12ee42858184933b098e0472b9c9c4aa62359ec118710	1772338276498
53	38d5cefc35dd980b3cb1db717137cf2f94437b4d1f620f0d5a2985515e5e228a	1772338972161
54	8c28fba0aa29e8a2887c8333449ca110263147d9576157df161b7975292892e0	1772360582884
55	85df7cbfc0cfe17cf6054061ba31429586a7b95331e85ea2dfa40130dff9284c	1772361797880
56	5a465bb96b5f02af624ebaa618d78418322d93e2730335922ea194ec076a9125	1772397997661
57	8a0bea891c8d9cd54b4b26fbac2f0327987db92ea841889f2c1bcbf4f59144dc	1772398317579
58	39d2256fc41f7b00b88f7b27a78f731d67e6a7bf27265985f89e4eb72e97a2db	1772399314809
59	e16d494745f145974a39f0fbe5976fd6073bcedd5b88ef4538f9493300116880	1772399712098
60	edfef38c4cd62975c60c13bfe4d0f3b9a3ab640831c42bc0133958e7e77a8ead	1772400884914
61	08501cd1fe19f9570bda2b0de94859351591b36361088371a7928c7d3506eeea	1772411650870
62	d72bd94be4a8b072c58b6893714659f68f8308a2fe30afad1a87fcefc6e2a7f2	1772412257586
63	f80ff3f4f5b8dce44fb0e50400206ad1aa45900d10b239474f837a8ad0b59289	1772413994709
64	58afcd6cbcf3600db704974aae59e3333b81dd37e1811e712cd06458dc768f96	1781279415920
65	4a01e7813dbe8227f01158ec20f570e1003ad0392156b35f1031f1c49eb84aac	1781279501000
66	740855e43d13c69d0222d98aa49286488298a5b700ad199cd39c0b39c037bdcf	1781279502000
67	3324429b3ad5e551c58cab4a807accdbe4251c9ca6b63fc8ca792953f1224f05	1781279503000
68	0624cc7408f2ac76c914da10d7264e2b20646cb388dd20fa45afd3a68b386967	1781279504000
69	5f90b49268a15d18267f2600a252b9e57c8524a5cd403fa58f878f1edf3eb455	1781279505000
70	c97f68eda81d10499c45c893722337850c94f4664bc7a472f9cd93fd7c613443	1781279506000
71	a201aa18854b8289219b60b2913047340549b4051301e0b274577b7e0965b912	1781279507000
72	645c5c614fdbc5915af8d629ff519c3b723c97b4af67355d168e1e1d26627d2b	1781279508000
73	1ca4d85b19c37cf6ee7c54691e0723b12df2f12d1bc72f8c97c2c050ca7f4116	1781279509000
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.audit_logs (id, actor_id, actor_name, actor_email, action, entity_type, entity_id, before, after, description, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: biometric_enrollments; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.biometric_enrollments (id, user_id, credential_id, public_key, device_name, aaguid, sign_count, is_active, last_used_at, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: bis_auto_flag_config; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.bis_auto_flag_config (id, currency, threshold_usd, velocity_count, bis_tier, is_active, updated_by, created_at, updated_at) FROM stdin;
1	GLOBAL	5000.0000	10	standard	t	\N	1782229624936	1782229624936
2	USDC	5000.0000	10	standard	t	\N	1782229624936	1782229624936
3	USD	5000.0000	10	standard	t	\N	1782229624936	1782229624936
4	NGN	3000.0000	15	basic	t	\N	1782229624936	1782229624936
5	KES	3000.0000	15	basic	t	\N	1782229624936	1782229624936
6	GHS	3000.0000	15	basic	t	\N	1782229624936	1782229624936
7	ZAR	3000.0000	15	basic	t	\N	1782229624936	1782229624936
8	XLM	4000.0000	12	standard	t	\N	1782229624936	1782229624936
\.


--
-- Data for Name: bis_auto_flags; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.bis_auto_flags (id, wallet_tx_id, user_id, currency, amount_usd, trigger_reason, threshold_usd, bis_investigation_id, bis_reference_id, status, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: bis_directors; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.bis_directors (id, entity_investigation_id, full_name, role, nationality, nin, email, phone, ownership_percent, linked_investigation_id, bundle_discount_percent, created_at) FROM stdin;
\.


--
-- Data for Name: bis_export_schedules; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.bis_export_schedules (id, user_id, frequency, enabled, include_internal, filters, next_run_at, last_run_at, created_at, updated_at, last_export_note_count) FROM stdin;
\.


--
-- Data for Name: bis_investigation_notes; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.bis_investigation_notes (id, investigation_id, author_id, author_name, content, is_internal, created_at) FROM stdin;
\.


--
-- Data for Name: bis_investigations; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.bis_investigations (id, reference_id, establishment_id, requested_by, subject_full_name, subject_dob, subject_nationality, subject_nin, subject_phone, subject_email, subject_role, subject_country, tier, status, risk_level, risk_score, module_results, recommendations, report_url, consent_obtained, price_paid, currency, external_bis_ref, completed_at, created_at, updated_at, assigned_to_id, assigned_to_name, assigned_at, due_at, sla_hours, linked_transaction_id, subject_type, entity_registration_number, entity_type, entity_website, entity_year_founded, linked_entity_investigation_id) FROM stdin;
25	BIS-2026-0001	14	1	Amara Diallo	\N	\N	\N	\N	\N	\N	KE	standard	completed	low	27	\N	[]	\N	t	75.00	USD	\N	2026-06-20 21:50:55.460046	2026-06-19 21:50:55.460046	2026-06-19 21:50:55.460046	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
26	BIS-2026-0002	15	1	Kwame Osei	\N	\N	\N	\N	\N	\N	NG	comprehensive	completed	medium	34	\N	[]	\N	t	150.00	USD	\N	2026-06-17 21:50:55.460046	2026-06-16 21:50:55.460046	2026-06-16 21:50:55.460046	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
27	BIS-2026-0003	16	1	Fatima Bello	\N	\N	\N	\N	\N	\N	GH	basic	flagged	high	41	\N	[]	\N	t	25.00	USD	\N	\N	2026-06-12 21:50:55.460046	2026-06-12 21:50:55.460046	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
29	BIS-2026-0005	18	1	Grace Mwangi	\N	\N	\N	\N	\N	\N	TZ	comprehensive	completed	low	55	\N	[]	\N	t	150.00	USD	\N	2026-06-06 21:50:55.460046	2026-06-05 21:50:55.460046	2026-06-05 21:50:55.460046	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
30	BIS-2026-0006	19	1	Ibrahim Sani	\N	\N	\N	\N	\N	\N	KE	basic	completed	low	62	\N	[]	\N	t	25.00	USD	\N	2026-06-03 21:50:55.460046	2026-06-02 21:50:55.460046	2026-06-02 21:50:55.460046	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
31	BIS-2026-0007	1	1	Lerato Dube	\N	\N	\N	\N	\N	\N	NG	standard	completed	medium	69	\N	[]	\N	t	75.00	USD	\N	2026-05-30 21:50:55.460046	2026-05-29 21:50:55.460046	2026-05-29 21:50:55.460046	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
32	BIS-2026-0008	14	1	John Mensah	\N	\N	\N	\N	\N	\N	GH	comprehensive	flagged	high	76	\N	[]	\N	t	150.00	USD	\N	\N	2026-05-26 21:50:55.460046	2026-05-26 21:50:55.460046	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
34	BIS-2026-0010	16	1	Kwame Osei	\N	\N	\N	\N	\N	\N	TZ	standard	completed	low	90	\N	[]	\N	t	75.00	USD	\N	2026-05-20 21:50:55.460046	2026-05-19 21:50:55.460046	2026-05-19 21:50:55.460046	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
35	BIS-2026-0011	17	1	Fatima Bello	\N	\N	\N	\N	\N	\N	KE	comprehensive	completed	low	97	\N	[]	\N	t	150.00	USD	\N	2026-05-16 21:50:55.460046	2026-05-15 21:50:55.460046	2026-05-15 21:50:55.460046	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
36	BIS-2026-0012	18	1	Thabo Nkosi	\N	\N	\N	\N	\N	\N	NG	basic	completed	medium	24	\N	[]	\N	t	25.00	USD	\N	2026-05-13 21:50:55.460046	2026-05-12 21:50:55.460046	2026-05-12 21:50:55.460046	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
37	BIS-2026-0013	19	1	Grace Mwangi	\N	\N	\N	\N	\N	\N	GH	standard	flagged	high	31	\N	[]	\N	t	75.00	USD	\N	\N	2026-05-08 21:50:55.460046	2026-05-08 21:50:55.460046	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
39	BIS-2026-0015	14	1	Lerato Dube	\N	\N	\N	\N	\N	\N	TZ	basic	completed	low	45	\N	[]	\N	t	25.00	USD	\N	2026-05-02 21:50:55.460046	2026-05-01 21:50:55.460046	2026-05-01 21:50:55.460046	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
40	BIS-2026-0016	15	1	John Mensah	\N	\N	\N	\N	\N	\N	KE	standard	completed	low	52	\N	[]	\N	t	75.00	USD	\N	2026-04-29 21:50:55.460046	2026-04-28 21:50:55.460046	2026-04-28 21:50:55.460046	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
41	BIS-2026-0017	16	1	Amara Diallo	\N	\N	\N	\N	\N	\N	NG	comprehensive	completed	medium	59	\N	[]	\N	t	150.00	USD	\N	2026-04-25 21:50:55.460046	2026-04-24 21:50:55.460046	2026-04-24 21:50:55.460046	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
42	BIS-2026-0018	17	1	Kwame Osei	\N	\N	\N	\N	\N	\N	GH	basic	flagged	high	66	\N	[]	\N	t	25.00	USD	\N	\N	2026-04-21 21:50:55.460046	2026-04-21 21:50:55.460046	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
44	BIS-2026-0020	19	1	Thabo Nkosi	\N	\N	\N	\N	\N	\N	TZ	comprehensive	completed	low	80	\N	[]	\N	t	150.00	USD	\N	2026-04-15 21:50:55.460046	2026-04-14 21:50:55.460046	2026-04-14 21:50:55.460046	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
45	BIS-2026-0021	1	1	Grace Mwangi	\N	\N	\N	\N	\N	\N	KE	basic	completed	low	87	\N	[]	\N	t	25.00	USD	\N	2026-04-11 21:50:55.460046	2026-04-10 21:50:55.460046	2026-04-10 21:50:55.460046	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
46	BIS-2026-0022	14	1	Ibrahim Sani	\N	\N	\N	\N	\N	\N	NG	standard	completed	medium	94	\N	[]	\N	t	75.00	USD	\N	2026-04-08 21:50:55.460046	2026-04-07 21:50:55.460046	2026-04-07 21:50:55.460046	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
47	BIS-2026-0023	15	1	Lerato Dube	\N	\N	\N	\N	\N	\N	GH	comprehensive	flagged	high	21	\N	[]	\N	t	150.00	USD	\N	\N	2026-04-03 21:50:55.460046	2026-04-03 21:50:55.460046	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
48	BIS-2026-0024	16	1	John Mensah	\N	\N	\N	\N	\N	\N	ZA	basic	completed	low	21	{"criminal": {"score": 83.2, "detail": "No criminal records found", "status": "CLEAR"}, "identity": {"score": 79, "detail": "NIN matched successfully", "status": "VERIFIED"}}	["Proceed with hiring — low risk profile", "Standard annual re-verification recommended"]	\N	t	25.00	USD	\N	2026-06-23 21:51:51.844	2026-03-31 21:50:55.460046	2026-06-23 21:51:51.844	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
43	BIS-2026-0019	18	1	Fatima Bello	\N	\N	\N	\N	\N	\N	ZA	standard	completed	low	24	{"criminal": {"score": 80.8, "detail": "No criminal records found", "status": "CLEAR"}, "identity": {"score": 76, "detail": "NIN matched successfully", "status": "VERIFIED"}, "financial": {"score": 83.2, "detail": "No adverse financial records", "status": "CLEAR"}, "employment": {"score": 85.6, "detail": "Employment history verified", "status": "VERIFIED"}}	["Proceed with hiring — low risk profile", "Standard annual re-verification recommended"]	\N	t	75.00	USD	\N	2026-06-23 21:51:51.876	2026-04-17 21:50:55.460046	2026-06-23 21:51:51.876	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
38	BIS-2026-0014	1	1	Ibrahim Sani	\N	\N	\N	\N	\N	\N	ZA	comprehensive	flagged	critical	81	{"criminal": {"score": 50, "detail": "Minor offence record found (2019)", "status": "RECORDS_FOUND"}, "identity": {"score": 60, "detail": "NIN could not be matched", "status": "UNVERIFIED"}, "financial": {"score": 50, "detail": "County court judgment found", "status": "ADVERSE"}, "sanctions": {"score": 75.7, "detail": "No sanctions matches", "status": "CLEAR"}, "employment": {"score": 55, "detail": "Employment gap of 8 months detected", "status": "DISCREPANCY"}, "social_media": {"score": 60, "detail": "Potentially problematic content identified", "status": "FLAGGED"}}	["Critical risk — do not proceed without full legal review", "Escalate to compliance team immediately", "Consider reporting to relevant regulatory authority", "Monthly monitoring mandatory if exception granted"]	\N	t	150.00	USD	\N	2026-06-23 21:51:51.903	2026-05-05 21:50:55.460046	2026-06-23 21:51:51.903	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
33	BIS-2026-0009	15	1	Amara Diallo	\N	\N	\N	\N	\N	\N	ZA	basic	completed	low	11	{"criminal": {"score": 91.2, "detail": "No criminal records found", "status": "CLEAR"}, "identity": {"score": 89, "detail": "NIN matched successfully", "status": "VERIFIED"}}	["Proceed with hiring — low risk profile", "Standard annual re-verification recommended"]	\N	t	25.00	USD	\N	2026-06-23 21:51:51.93	2026-05-22 21:50:55.460046	2026-06-23 21:51:51.93	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
28	BIS-2026-0004	17	1	Thabo Nkosi	\N	\N	\N	\N	\N	\N	ZA	standard	completed	medium	51	{"criminal": {"score": 59.199999999999996, "detail": "No criminal records found", "status": "CLEAR"}, "identity": {"score": 60, "detail": "NIN matched successfully", "status": "VERIFIED"}, "financial": {"score": 64.30000000000001, "detail": "No adverse financial records", "status": "CLEAR"}, "employment": {"score": 69.4, "detail": "Employment history verified", "status": "VERIFIED"}}	["Proceed with caution — medium risk profile", "Conduct in-person interview to clarify employment gaps", "Semi-annual re-verification recommended"]	\N	t	75.00	USD	\N	2026-06-23 21:51:51.957	2026-06-09 21:50:55.460046	2026-06-23 21:51:51.957	\N	\N	\N	\N	\N	\N	individual	\N	\N	\N	\N	\N
\.


--
-- Data for Name: bis_kill_switch_activations; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.bis_kill_switch_activations (id, bis_investigation_id, bis_reference_id, subject_full_name, risk_level, risk_score, corridor, reason, activated_by, created_at) FROM stdin;
\.


--
-- Data for Name: bis_report_exports; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.bis_report_exports (id, investigation_id, generated_by, file_key, file_url, file_size_bytes, llm_summary, export_format, created_at) FROM stdin;
\.


--
-- Data for Name: bis_timeline; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.bis_timeline (id, investigation_id, actor_id, actor_name, event_type, title, description, metadata, severity, created_at) FROM stdin;
\.


--
-- Data for Name: carbon_offsets; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.carbon_offsets (id, user_id, amount, project_name, project_country, cost_usd, certificate_url, vintage_year, created_at) FROM stdin;
\.


--
-- Data for Name: channel_connections; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.channel_connections (id, establishment_id, channel_name, display_name, status, config, last_sync_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: did_documents; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.did_documents (id, user_id, did, did_document, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: establishment_score_snapshots; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.establishment_score_snapshots (id, establishment_id, composite_score, booking_count, avg_rating, response_rate, snapshot_date, created_at) FROM stdin;
1	1	0	0	0.0	0	2026-06-22	2026-06-23 11:29:00.896135
10	14	0	0	0.0	0	2026-06-22	2026-06-23 22:00:32.852343
11	15	0	0	0.0	0	2026-06-22	2026-06-23 22:00:32.887412
12	16	0	0	0.0	0	2026-06-22	2026-06-23 22:00:32.901673
13	17	0	0	0.0	0	2026-06-22	2026-06-23 22:00:32.913453
14	18	0	0	0.0	0	2026-06-22	2026-06-23 22:00:32.924874
15	19	0	0	0.0	0	2026-06-22	2026-06-23 22:00:32.93564
23	1	0	0	0.0	0	2026-06-29	2026-06-30 22:24:44.759462
24	14	0	0	0.0	0	2026-06-29	2026-06-30 22:24:44.796887
25	15	0	0	0.0	0	2026-06-29	2026-06-30 22:24:44.841616
26	16	0	0	0.0	0	2026-06-29	2026-06-30 22:24:44.871533
27	17	0	0	0.0	0	2026-06-29	2026-06-30 22:24:44.884679
28	18	0	0	0.0	0	2026-06-29	2026-06-30 22:24:44.897907
29	19	0	0	0.0	0	2026-06-29	2026-06-30 22:24:44.906528
30	14	0	0	0.0	0	2026-07-06	2026-07-07 22:24:44.745235
31	15	0	0	0.0	0	2026-07-06	2026-07-07 22:24:44.781342
32	16	0	0	0.0	0	2026-07-06	2026-07-07 22:24:44.794952
33	17	0	0	0.0	0	2026-07-06	2026-07-07 22:24:44.805777
34	18	0	0	0.0	0	2026-07-06	2026-07-07 22:24:44.829196
35	19	0	0	0.0	0	2026-07-06	2026-07-07 22:24:44.837087
36	1	0	0	0.0	0	2026-07-06	2026-07-07 22:24:44.84905
37	14	0	0	0.0	0	2026-07-13	2026-07-14 22:24:44.748829
38	15	0	0	0.0	0	2026-07-13	2026-07-14 22:24:44.76838
39	16	0	0	0.0	0	2026-07-13	2026-07-14 22:24:44.793228
40	17	0	0	0.0	0	2026-07-13	2026-07-14 22:24:44.805309
41	18	0	0	0.0	0	2026-07-13	2026-07-14 22:24:44.815027
42	19	0	0	0.0	0	2026-07-13	2026-07-14 22:24:44.830517
43	1	0	0	0.0	0	2026-07-13	2026-07-14 22:24:44.838569
44	14	0	0	0.0	0	2026-07-20	2026-07-21 22:24:44.75377
45	15	0	0	0.0	0	2026-07-20	2026-07-21 22:24:44.769304
46	1	0	0	0.0	0	2026-07-20	2026-07-21 22:24:44.78111
47	16	0	0	0.0	0	2026-07-20	2026-07-21 22:24:44.808988
48	17	0	0	0.0	0	2026-07-20	2026-07-21 22:24:44.819286
49	18	0	0	0.0	0	2026-07-20	2026-07-21 22:24:44.83342
50	19	0	0	0.0	0	2026-07-20	2026-07-21 22:24:44.843706
\.


--
-- Data for Name: establishments; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.establishments (id, name, type, country, city, address, registration_number, tax_id, contact_email, contact_phone, website, kyb_status, kyb_score, kyb_notes, owner_id, employee_count, annual_revenue, currency, metadata, created_at, updated_at, latitude, longitude, stripe_account_id, stripe_connect_status, stripe_payouts_enabled, stripe_details_submitted) FROM stdin;
1	Serengeti Safari Experience	tour_operator	TZ	Arusha	123 Safari Road, Arusha, Tanzania	\N	\N	info@serengetisafari.tz	+255 27 250 1234	\N	approved	\N	\N	2	\N	\N	TZS	\N	2026-06-23 11:27:52.988733	2026-06-23 22:06:31.294	-3.3869000	36.6830000	\N	not_started	f	f
14	Zanzibar Beach Resort	beach_resort	TZ	Zanzibar	\N	\N	\N	info@zanzibar.tz	\N	\N	approved	88	\N	2	45	1200000.00	TZS	{"lastNudgeSentAt": 1784672684777}	2026-05-14 21:50:55.460046	2026-07-21 22:24:44.836	\N	\N	\N	not_started	f	f
15	Kilimanjaro Adventures	tour_operator	TZ	Moshi	\N	\N	\N	hello@kili.tz	\N	\N	approved	82	\N	2	22	680000.00	TZS	{"lastNudgeSentAt": 1784672684777}	2026-05-19 21:50:55.460046	2026-07-21 22:24:44.855	\N	\N	\N	not_started	f	f
16	Nairobi Night Safari	safari_lodge	KE	Nairobi	\N	\N	\N	safari@nairobi.ke	\N	\N	approved	61	\N	2	17	430000.00	KES	{"lastNudgeSentAt": 1784672684777}	2026-06-03 21:50:55.460046	2026-07-21 22:24:44.883	\N	\N	\N	not_started	f	f
17	Cape Town Wine Tours	tour_operator	ZA	Cape Town	\N	\N	\N	wine@cpt.za	\N	\N	approved	0	\N	2	9	290000.00	ZAR	{"lastNudgeSentAt": 1784672684777}	2026-06-14 21:50:55.460046	2026-07-21 22:24:44.894	\N	\N	\N	not_started	f	f
18	Accra Artisan Market	museum	GH	Accra	\N	\N	\N	market@accra.gh	\N	\N	approved	76	\N	2	12	150000.00	GHS	{"lastNudgeSentAt": 1784672684777}	2026-05-04 21:50:55.460046	2026-07-21 22:24:44.904	\N	\N	\N	not_started	f	f
19	Victoria Falls Hotel	hotel	ZA	Livingstone	\N	\N	\N	stay@vicfalls.za	\N	\N	approved	31	\N	2	30	510000.00	ZAR	{"lastNudgeSentAt": 1784672684777}	2026-06-08 21:50:55.460046	2026-07-21 22:24:44.916	\N	\N	\N	not_started	f	f
\.


--
-- Data for Name: exchange_rate_overrides; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.exchange_rate_overrides (id, base_currency, target_currency, rate, reason, is_active, expires_at, created_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: finance_requests; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.finance_requests (id, user_id, type, amount, currency, status, description, metadata, admin_notes, reviewed_by, reviewed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fraud_alerts; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.fraud_alerts (id, alert_id, transaction_id, establishment_id, country, severity, status, rule_triggered, description, amount, currency, gnn_score, metadata, resolved_by, resolved_at, created_at, updated_at) FROM stdin;
1	FRD-00001	TXN-000001	14	KE	low	investigating	geo_anomaly	Automated fraud detection triggered	87.00	USD	0.30	\N	\N	\N	2026-06-22 21:50:55.460046	2026-06-22 21:50:55.460046
2	FRD-00002	TXN-000002	15	NG	medium	resolved	device_mismatch	Automated fraud detection triggered	124.00	USD	0.40	\N	\N	\N	2026-06-21 21:50:55.460046	2026-06-21 21:50:55.460046
3	FRD-00003	TXN-000003	16	GH	high	resolved	amount_outlier	Automated fraud detection triggered	161.00	USD	0.50	\N	\N	\N	2026-06-20 21:50:55.460046	2026-06-20 21:50:55.460046
4	FRD-00004	TXN-000004	17	ZA	critical	false_positive	velocity_spike	Automated fraud detection triggered	198.00	USD	0.60	\N	\N	\N	2026-06-19 21:50:55.460046	2026-06-19 21:50:55.460046
5	FRD-00005	TXN-000005	18	TZ	info	open	geo_anomaly	Automated fraud detection triggered	235.00	USD	0.70	\N	\N	\N	2026-06-18 21:50:55.460046	2026-06-18 21:50:55.460046
6	FRD-00006	TXN-000006	19	KE	low	investigating	device_mismatch	Automated fraud detection triggered	272.00	USD	0.80	\N	\N	\N	2026-06-17 21:50:55.460046	2026-06-17 21:50:55.460046
7	FRD-00007	TXN-000007	1	NG	medium	resolved	amount_outlier	Automated fraud detection triggered	309.00	USD	0.90	\N	\N	\N	2026-06-16 21:50:55.460046	2026-06-16 21:50:55.460046
8	FRD-00008	TXN-000008	14	GH	high	resolved	velocity_spike	Automated fraud detection triggered	346.00	USD	0.20	\N	\N	\N	2026-06-15 21:50:55.460046	2026-06-15 21:50:55.460046
9	FRD-00009	TXN-000009	15	ZA	critical	false_positive	geo_anomaly	Automated fraud detection triggered	383.00	USD	0.30	\N	\N	\N	2026-06-14 21:50:55.460046	2026-06-14 21:50:55.460046
10	FRD-00010	TXN-000010	16	TZ	info	open	device_mismatch	Automated fraud detection triggered	420.00	USD	0.40	\N	\N	\N	2026-06-13 21:50:55.460046	2026-06-13 21:50:55.460046
11	FRD-00011	TXN-000011	17	KE	low	investigating	amount_outlier	Automated fraud detection triggered	457.00	USD	0.50	\N	\N	\N	2026-06-12 21:50:55.460046	2026-06-12 21:50:55.460046
12	FRD-00012	TXN-000012	18	NG	medium	resolved	velocity_spike	Automated fraud detection triggered	494.00	USD	0.60	\N	\N	\N	2026-06-11 21:50:55.460046	2026-06-11 21:50:55.460046
13	FRD-00013	TXN-000013	19	GH	high	resolved	geo_anomaly	Automated fraud detection triggered	531.00	USD	0.70	\N	\N	\N	2026-06-10 21:50:55.460046	2026-06-10 21:50:55.460046
14	FRD-00014	TXN-000014	1	ZA	critical	false_positive	device_mismatch	Automated fraud detection triggered	568.00	USD	0.80	\N	\N	\N	2026-06-09 21:50:55.460046	2026-06-09 21:50:55.460046
15	FRD-00015	TXN-000015	14	TZ	info	open	amount_outlier	Automated fraud detection triggered	605.00	USD	0.90	\N	\N	\N	2026-06-08 21:50:55.460046	2026-06-08 21:50:55.460046
16	FRD-00016	TXN-000016	15	KE	low	investigating	velocity_spike	Automated fraud detection triggered	642.00	USD	0.20	\N	\N	\N	2026-06-07 21:50:55.460046	2026-06-07 21:50:55.460046
17	FRD-00017	TXN-000017	16	NG	medium	resolved	geo_anomaly	Automated fraud detection triggered	679.00	USD	0.30	\N	\N	\N	2026-06-06 21:50:55.460046	2026-06-06 21:50:55.460046
18	FRD-00018	TXN-000018	17	GH	high	resolved	device_mismatch	Automated fraud detection triggered	716.00	USD	0.40	\N	\N	\N	2026-06-05 21:50:55.460046	2026-06-05 21:50:55.460046
19	FRD-00019	TXN-000019	18	ZA	critical	false_positive	amount_outlier	Automated fraud detection triggered	753.00	USD	0.50	\N	\N	\N	2026-06-04 21:50:55.460046	2026-06-04 21:50:55.460046
20	FRD-00020	TXN-000020	19	TZ	info	open	velocity_spike	Automated fraud detection triggered	790.00	USD	0.60	\N	\N	\N	2026-06-03 21:50:55.460046	2026-06-03 21:50:55.460046
21	FRD-00021	TXN-000021	1	KE	low	investigating	geo_anomaly	Automated fraud detection triggered	827.00	USD	0.70	\N	\N	\N	2026-06-02 21:50:55.460046	2026-06-02 21:50:55.460046
22	FRD-00022	TXN-000022	14	NG	medium	resolved	device_mismatch	Automated fraud detection triggered	864.00	USD	0.80	\N	\N	\N	2026-06-01 21:50:55.460046	2026-06-01 21:50:55.460046
\.


--
-- Data for Name: itinerary_changelog; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.itinerary_changelog (id, itinerary_id, user_id, action, item_id, diff, created_at) FROM stdin;
\.


--
-- Data for Name: itinerary_collaborators; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.itinerary_collaborators (id, itinerary_id, user_id, role, invite_token, invite_email, accepted_at, created_at) FROM stdin;
\.


--
-- Data for Name: kyb_applications; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.kyb_applications (id, establishment_id, submitted_by, status, current_step, total_steps, documents_uploaded, review_notes, reviewed_by, reviewed_at, compliance_score, risk_flags, external_kyb_ref, created_at, updated_at) FROM stdin;
1	1	2	approved	5	5	[]	\N	\N	\N	50	[]	\N	2026-06-23 11:27:52.988733	2026-06-23 21:50:55.460046
2	14	2	approved	5	5	[]	\N	\N	\N	88	[]	\N	2026-05-14 21:50:55.460046	2026-06-23 21:50:55.460046
3	15	2	approved	5	5	[]	\N	\N	\N	82	[]	\N	2026-05-19 21:50:55.460046	2026-06-23 21:50:55.460046
4	16	2	under_review	3	5	[]	\N	\N	\N	61	[]	\N	2026-06-03 21:50:55.460046	2026-06-23 21:50:55.460046
5	17	2	submitted	4	5	[]	\N	\N	\N	50	[]	\N	2026-06-14 21:50:55.460046	2026-06-23 21:50:55.460046
6	18	2	approved	5	5	[]	\N	\N	\N	76	[]	\N	2026-05-04 21:50:55.460046	2026-06-23 21:50:55.460046
7	19	2	rejected	3	5	[]	\N	\N	\N	31	[]	\N	2026-06-08 21:50:55.460046	2026-06-23 21:50:55.460046
\.


--
-- Data for Name: kyb_documents; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.kyb_documents (id, application_id, establishment_id, uploaded_by, document_type, status, file_name, file_key, file_url, mime_type, file_size_bytes, review_notes, reviewed_by, reviewed_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: kyc_verification_records; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.kyc_verification_records (id, user_id, status, document_type, document_country, document_number_hash, full_name_encrypted, date_of_birth, nationality, liveness_score, document_match_score, risk_score, sanctions_clear, pep_clear, reviewer_id, rejection_reason, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ledger_accounts; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.ledger_accounts (id, user_id, establishment_id, ledger_code, currency_code, debits_pending, debits_posted, credits_pending, credits_posted, flags, created_at) FROM stdin;
\.


--
-- Data for Name: ledger_transfers; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.ledger_transfers (id, debit_account_id, credit_account_id, amount, ledger_code, transfer_code, pending_id, flags, status, idempotency_key, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: login_history; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.login_history (id, user_id, ip_address, user_agent, device_fingerprint, country, city, login_method, success, is_suspicious, is_trusted_device, session_id, session_active, created_at) FROM stdin;
\.


--
-- Data for Name: loyalty_accounts; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.loyalty_accounts (id, user_id, points_balance, tier, lifetime_points, created_at, updated_at, tier_protected_until, leaderboard_opt_out, hide_transaction_history) FROM stdin;
db7186b1-98ea-4d6c-912c-616821067977	1	0	BRONZE	0	1782235644	1782235644	\N	f	f
64439369-c1f3-4e57-b5e7-35510d4c6cab	3	4200	GOLD	12500	1782249856	1782249856	\N	f	f
fbf228a8-433f-459d-938e-05408c394fc6	2	2100	SILVER	8200	1782251455	1782251455	\N	f	f
\.


--
-- Data for Name: loyalty_partners; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.loyalty_partners (id, name, logo_url, description, bonus_multiplier, category, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: loyalty_referrals; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.loyalty_referrals (id, referrer_id, referee_id, code, status, referrer_points_awarded, referee_points_awarded, used_at, created_at) FROM stdin;
\.


--
-- Data for Name: loyalty_rewards; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.loyalty_rewards (id, name, description, points_cost, category, image_url, is_active, stock, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: loyalty_transactions; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.loyalty_transactions (id, user_id, type, points, description, partner, reference_id, created_at, expires_at, is_expired) FROM stdin;
038a3bcf-1dd2-48e7-a7f4-a6c4e62022eb	3	earn	170	QR payment	TourismPay	\N	1782165055	\N	f
49c3d1b8-69b6-4664-9fd5-f7ebbd75a974	3	earn	290	Tier bonus	TourismPay	\N	1782078655	\N	f
10aec1eb-da4e-4b80-90f0-48eed5a2d070	3	redeem	-120	Reward redemption	TourismPay	\N	1781992255	\N	f
d04ddb6d-788c-44c6-a005-066a82e5dcac	3	earn	530	Safari booking	TourismPay	\N	1781905855	\N	f
151bf91c-4822-4a99-aaae-1d903b18d649	3	earn	650	QR payment	TourismPay	\N	1781819455	\N	f
b49c472b-aa0c-4b01-93e7-1ef2bfaca9ba	3	earn	770	Tier bonus	TourismPay	\N	1781733055	\N	f
f1c5a2f4-77b1-4558-8ad8-37c5c6234091	3	redeem	-280	Reward redemption	TourismPay	\N	1781646655	\N	f
3f63af10-82cc-4d71-ab0b-0c3f3a1fecd1	3	earn	1010	Safari booking	TourismPay	\N	1781560255	\N	f
3ea6a4ac-7aa9-44ef-9c78-2ac7790a3579	3	earn	1130	QR payment	TourismPay	\N	1781473855	\N	f
e93e20ae-cd40-4b97-b960-458ea1cf6a93	3	earn	1250	Tier bonus	TourismPay	\N	1781387455	\N	f
7c2f347e-ee7e-4df8-a928-f29f44289828	3	redeem	-440	Reward redemption	TourismPay	\N	1781301055	\N	f
dfca97d1-153f-4daf-acdf-778be391fed2	3	earn	1490	Safari booking	TourismPay	\N	1781214655	\N	f
88f42150-f7aa-4e51-8a8d-41977d440db4	3	earn	110	QR payment	TourismPay	\N	1781128255	\N	f
44a93c49-dd56-49dd-b9cf-7d06ff2e1877	3	earn	230	Tier bonus	TourismPay	\N	1781041855	\N	f
07e15c0c-98a6-4442-a17a-7ab82085d579	3	redeem	-600	Reward redemption	TourismPay	\N	1780955455	\N	f
541fc268-e6f6-46f4-9cb6-b73e20096ca7	3	earn	470	Safari booking	TourismPay	\N	1780869055	\N	f
\.


--
-- Data for Name: lp_applications; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.lp_applications (id, user_id, entity_type, entity_name, registration_country, tax_id, wallet_address, intended_pools, intended_deposit_usd, tier, status, notes, reviewed_by, reviewed_at, created_at) FROM stdin;
\.


--
-- Data for Name: lp_pool_snapshots; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.lp_pool_snapshots (id, pool_id, total_liquidity, lp_count, snapshot_at) FROM stdin;
\.


--
-- Data for Name: lp_positions; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.lp_positions (id, lp_id, user_id, pool_id, stablecoin, amount, status, deposit_tx_hash, locked_until, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lp_providers; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.lp_providers (id, user_id, entity_type, entity_name, tier, status, wallet_address, total_deposited, total_earned, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lp_rebalance_events; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.lp_rebalance_events (id, from_pool, to_pool, amount, initiated_by, status, created_at) FROM stdin;
\.


--
-- Data for Name: lp_rewards; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.lp_rewards (id, lp_id, pool_id, amount, period_start, period_end, created_at) FROM stdin;
\.


--
-- Data for Name: lp_withdrawals; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.lp_withdrawals (id, lp_id, user_id, position_id, pool_id, amount, destination_address, requires_multisig, status, created_at) FROM stdin;
\.


--
-- Data for Name: merchant_payout_schedules; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.merchant_payout_schedules (id, merchant_id, frequency, preferred_day, is_active, next_run_at, last_run_at, last_batch_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: merchant_products; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.merchant_products (id, establishment_id, name, description, category, price, currency, image_url, sku, available, featured, sort_order, metadata, created_at, updated_at) FROM stdin;
57	1	Full-Day Game Drive	\N	experience	350.00	TZS	\N	\N	t	t	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
58	1	Sunset Dhow Cruise	\N	experience	85.00	TZS	\N	\N	t	f	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
59	1	Cultural Village Visit	\N	experience	45.00	TZS	\N	\N	t	f	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
60	1	Spice Farm Tour	\N	experience	60.00	TZS	\N	\N	t	f	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
61	14	Full-Day Game Drive	\N	experience	350.00	TZS	\N	\N	t	t	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
62	14	Sunset Dhow Cruise	\N	experience	85.00	TZS	\N	\N	t	f	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
63	14	Cultural Village Visit	\N	experience	45.00	TZS	\N	\N	t	f	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
64	14	Spice Farm Tour	\N	experience	60.00	TZS	\N	\N	t	f	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
65	15	Full-Day Game Drive	\N	experience	350.00	TZS	\N	\N	t	t	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
66	15	Sunset Dhow Cruise	\N	experience	85.00	TZS	\N	\N	t	f	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
67	15	Cultural Village Visit	\N	experience	45.00	TZS	\N	\N	t	f	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
68	15	Spice Farm Tour	\N	experience	60.00	TZS	\N	\N	t	f	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
69	16	Full-Day Game Drive	\N	experience	350.00	KES	\N	\N	t	t	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
70	16	Sunset Dhow Cruise	\N	experience	85.00	KES	\N	\N	t	f	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
71	16	Cultural Village Visit	\N	experience	45.00	KES	\N	\N	t	f	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
72	16	Spice Farm Tour	\N	experience	60.00	KES	\N	\N	t	f	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
73	17	Full-Day Game Drive	\N	experience	350.00	ZAR	\N	\N	t	t	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
74	17	Sunset Dhow Cruise	\N	experience	85.00	ZAR	\N	\N	t	f	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
75	17	Cultural Village Visit	\N	experience	45.00	ZAR	\N	\N	t	f	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
76	17	Spice Farm Tour	\N	experience	60.00	ZAR	\N	\N	t	f	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
77	18	Full-Day Game Drive	\N	experience	350.00	GHS	\N	\N	t	t	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
78	18	Sunset Dhow Cruise	\N	experience	85.00	GHS	\N	\N	t	f	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
79	18	Cultural Village Visit	\N	experience	45.00	GHS	\N	\N	t	f	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
80	18	Spice Farm Tour	\N	experience	60.00	GHS	\N	\N	t	f	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
81	19	Full-Day Game Drive	\N	experience	350.00	ZAR	\N	\N	t	t	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
82	19	Sunset Dhow Cruise	\N	experience	85.00	ZAR	\N	\N	t	f	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
83	19	Cultural Village Visit	\N	experience	45.00	ZAR	\N	\N	t	f	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
84	19	Spice Farm Tour	\N	experience	60.00	ZAR	\N	\N	t	f	0	\N	2026-06-13 21:50:55.460046	2026-06-23 21:50:55.460046
\.


--
-- Data for Name: mesh_transactions; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.mesh_transactions (id, user_id, corridor_id, from_currency, to_currency, amount, converted_amount, fee_amount, exchange_rate, recipient_address, status, tx_hash, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: noc_alert_thresholds; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.noc_alert_thresholds (id, metric, warn_min, warn_max, crit_min, crit_max, unit, label, updated_by, updated_at) FROM stdin;
1	tps	\N	500.00	\N	800.00	tps	Transactions Per Second	\N	1782229452986
2	successRate	95.00	\N	90.00	\N	%	Success Rate	\N	1782229452986
3	avgLatency	\N	300.00	\N	500.00	ms	Avg Latency	\N	1782229452986
4	todayVolume	\N	\N	\N	\N	txns	Today's Volume	\N	1782229452986
\.


--
-- Data for Name: noc_events; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.noc_events (id, type, severity, title, description, actor_id, actor_name, target_id, target_type, metadata, resolved_at, created_at) FROM stdin;
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.notification_preferences (id, user_id, bis_enabled, kyb_enabled, fraud_enabled, soc_enabled, system_enabled, report_enabled, in_app_enabled, email_enabled, quiet_hours_start, quiet_hours_end, created_at, updated_at, wishlist_expiry_alerts, sentiment_alert_threshold) FROM stdin;
\.


--
-- Data for Name: pin_lockout_history; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.pin_lockout_history (id, user_id, tier, locked_at, unlocks_at, failed_attempts, resolved) FROM stdin;
\.


--
-- Data for Name: ps_account_recovery; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.ps_account_recovery (id, user_id, method, token, status, expires_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: ps_api_keys; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.ps_api_keys (id, user_id, name, key_hash, key_prefix, environment, permissions, is_active, last_used_at, expires_at, rate_limit, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ps_corridor_rate_limit_usage; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.ps_corridor_rate_limit_usage (id, corridor, window_start, day_window_start, tx_count, volume_sum, currency, last_updated_at) FROM stdin;
\.


--
-- Data for Name: ps_corridor_rate_limits; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.ps_corridor_rate_limits (id, corridor, max_tx_per_minute, max_volume_per_day, currency, is_active, notes, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ps_fraud_rules; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.ps_fraud_rules (id, rule_id, name, description, rule_type, conditions, action, severity, is_active, hit_count, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ps_kill_switch_history; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.ps_kill_switch_history (id, corridor, action, actor_id, actor_name, reason, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: ps_kill_switch_state; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.ps_kill_switch_state (id, is_active, activated_by, activated_by_name, reason, activated_at, deactivated_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ps_kill_switches; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.ps_kill_switches (id, corridor, is_active, activated_by, activated_by_name, reason, activated_at, deactivated_at, deactivated_by, deactivated_by_name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ps_ledger_entries; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.ps_ledger_entries (id, account_id, participant_id, ledger, code, debit_amount, credit_amount, currency, transfer_id, remittance_id, settlement_id, tb_transfer_id, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: ps_notification_channels; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.ps_notification_channels (id, user_id, type, name, config, is_active, last_tested_at, created_at) FROM stdin;
\.


--
-- Data for Name: ps_participants; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.ps_participants (id, name, type, status, country, currency, tb_account_id, mojaloop_fsp_id, health_score, last_health_check, api_endpoint, api_key_hash, daily_limit, monthly_limit, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ps_reminder_emails; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.ps_reminder_emails (id, user_id, type, subject, body, scheduled_at, sent_at, status, created_at) FROM stdin;
\.


--
-- Data for Name: ps_settlements; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.ps_settlements (id, batch_id, participant_id, currency, total_amount, transaction_count, status, tb_batch_id, mojaloop_window_id, settled_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ps_two_factor_settings; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.ps_two_factor_settings (id, user_id, enabled, method, secret, backup_codes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ps_webhook_deliveries; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.ps_webhook_deliveries (id, delivery_id, webhook_id, event, payload, status, attempts, max_attempts, next_retry_at, last_attempt_at, response_code, response_body, response_time_ms, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ps_webhooks; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.ps_webhooks (id, webhook_id, name, endpoint, events, secret, is_active, participant_id, created_by, created_by_name, last_delivery_at, last_delivery_status, total_deliveries, failure_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.push_subscriptions (id, user_id, endpoint, p256dh, auth, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: qr_payment_receipts; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.qr_payment_receipts (id, token, tourist_user_id, establishment_id, merchant_name, amount_usd, currency, line_items, status, pdf_url, created_at) FROM stdin;
\.


--
-- Data for Name: qr_payment_tokens; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.qr_payment_tokens (id, token, establishment_id, amount_usd, currency, description, status, expires_at, paid_at, paid_by_user_id, wallet_tx_id, created_at) FROM stdin;
\.


--
-- Data for Name: rate_alerts; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.rate_alerts (id, user_id, base_currency, target_currency, target_rate, condition, status, notify_email, notify_sms, triggered_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: remittances; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.remittances (id, user_id, sender_currency, sender_amount, recipient_currency, recipient_amount, exchange_rate, fee, status, delivery_option, recipient_phone, recipient_name, recipient_bank, recipient_account, tb_transfer_id, mojaloop_ref, external_ref, error_code, error_message, metadata, completed_at, created_at, updated_at) FROM stdin;
59df3df3-2d25-4d90-bac0-6ec277ad8878	3	USD	153.00000000	NGN	237150.00000000	1550.00000000	2.50000000	completed	mobile_money	+254700000013	Joseph K.	\N	\N	\N	\N	\N	\N	\N	{}	1782078655460	1781992255460	1781992255460
03546197-ed47-42b8-846d-780ec2ede429	3	USD	206.00000000	GHS	2472.00000000	12.00000000	3.50000000	completed	agent_cash	+254700000026	Esther O.	\N	\N	\N	\N	\N	\N	\N	{}	1781905855460	1781819455460	1781819455460
4439e242-c27c-41e4-b5d5-634540bb14ee	3	USD	259.00000000	TZS	673400.00000000	2600.00000000	4.50000000	processing	wallet	+254700000039	Daniel M.	\N	\N	\N	\N	\N	\N	\N	{}	\N	1781560255460	1781560255460
57627b0c-59be-4fb9-9d99-92bee46298a7	3	USD	312.00000000	ZAR	5616.00000000	18.00000000	5.50000000	pending	bank_transfer	+254700000052	Mary A.	\N	\N	\N	\N	\N	\N	\N	{}	\N	1781387455460	1781387455460
6e846766-88fd-4a33-ade1-6056e0b88ab8	3	USD	365.00000000	KES	47085.00000000	129.00000000	1.50000000	completed	mobile_money	+254700000065	Joseph K.	\N	\N	\N	\N	\N	\N	\N	{}	1781214655460	1781128255460	1781128255460
b6cbf5a0-9207-4996-b0be-b562f6cf90db	3	USD	418.00000000	NGN	647900.00000000	1550.00000000	2.50000000	completed	agent_cash	+254700000078	Esther O.	\N	\N	\N	\N	\N	\N	\N	{}	1781041855460	1780955455460	1780955455460
1823aed3-7a7e-478a-ad55-08d245a781c2	3	USD	471.00000000	GHS	5652.00000000	12.00000000	3.50000000	completed	wallet	+254700000091	Daniel M.	\N	\N	\N	\N	\N	\N	\N	{}	1780782655460	1780696255460	1780696255460
e30607b9-a8f8-46da-8cc8-89820669488f	3	USD	524.00000000	TZS	1362400.00000000	2600.00000000	4.50000000	processing	bank_transfer	+254700000104	Mary A.	\N	\N	\N	\N	\N	\N	\N	{}	\N	1780523455460	1780523455460
5bd1136f-c9ea-4c2c-bcf0-9db236aacebd	3	USD	577.00000000	ZAR	10386.00000000	18.00000000	5.50000000	pending	mobile_money	+254700000117	Joseph K.	\N	\N	\N	\N	\N	\N	\N	{}	\N	1780264255460	1780264255460
34261456-a1dc-402c-93f0-168b4b89893e	3	USD	630.00000000	KES	81270.00000000	129.00000000	1.50000000	completed	agent_cash	+254700000130	Esther O.	\N	\N	\N	\N	\N	\N	\N	{}	1780177855460	1780091455460	1780091455460
c1c6c761-f4a1-49a1-8192-ae6a95a5639a	3	USD	683.00000000	NGN	1058650.00000000	1550.00000000	2.50000000	completed	wallet	+254700000143	Daniel M.	\N	\N	\N	\N	\N	\N	\N	{}	1779918655460	1779832255460	1779832255460
178c2d6a-de57-479e-8c82-1bc7cb7dc888	3	USD	736.00000000	GHS	8832.00000000	12.00000000	3.50000000	completed	bank_transfer	+254700000156	Mary A.	\N	\N	\N	\N	\N	\N	\N	{}	1779745855460	1779659455460	1779659455460
624012ad-9e89-4424-8aef-8a40bce2beed	3	USD	789.00000000	TZS	2051400.00000000	2600.00000000	4.50000000	processing	mobile_money	+254700000169	Joseph K.	\N	\N	\N	\N	\N	\N	\N	{}	\N	1779400255460	1779400255460
66590068-7085-416d-89a6-9a5f6bd6a7a9	3	USD	842.00000000	ZAR	15156.00000000	18.00000000	5.50000000	pending	agent_cash	+254700000182	Esther O.	\N	\N	\N	\N	\N	\N	\N	{}	\N	1779227455460	1779227455460
b9ecf41d-2e73-468f-a1a9-9a82f97472e4	3	USD	895.00000000	KES	115455.00000000	129.00000000	1.50000000	completed	wallet	+254700000195	Daniel M.	\N	\N	\N	\N	\N	\N	\N	{}	1779054655460	1778968255460	1778968255460
a37165fd-9cea-4bd4-982a-c61e0d2f1293	3	USD	948.00000000	NGN	1469400.00000000	1550.00000000	2.50000000	completed	bank_transfer	+254700000208	Mary A.	\N	\N	\N	\N	\N	\N	\N	{}	1778881855460	1778795455460	1778795455460
d95460c6-07d1-4c1c-ac34-b1d0a794d0e2	3	USD	101.00000000	GHS	1212.00000000	12.00000000	3.50000000	completed	mobile_money	+254700000221	Joseph K.	\N	\N	\N	\N	\N	\N	\N	{}	1778622655460	1778536255460	1778536255460
c89d8823-52da-4679-849d-c01ab34c8484	3	USD	154.00000000	TZS	400400.00000000	2600.00000000	4.50000000	processing	agent_cash	+254700000234	Esther O.	\N	\N	\N	\N	\N	\N	\N	{}	\N	1778363455460	1778363455460
\.


--
-- Data for Name: review_sentiment_cache; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.review_sentiment_cache (id, establishment_id, positive_percent, themes, summary, review_count, generated_at) FROM stdin;
\.


--
-- Data for Name: review_sentiment_history; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.review_sentiment_history (id, establishment_id, positive_percent, review_count, snapshot_date, created_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.role_permissions (id, role, resource, action, granted, created_at) FROM stdin;
\.


--
-- Data for Name: scheduled_payments; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.scheduled_payments (id, user_id, to_address, counterparty_name, amount, currency, recurrence, note, reference, status, scheduled_at, last_run_at, next_run_at, run_count, failure_reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: service_availability; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.service_availability (id, product_id, establishment_id, date, total_slots, booked_slots, is_blocked, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: service_health_alerts; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.service_health_alerts (id, service_key, last_alert_at, last_status, alert_count) FROM stdin;
\.


--
-- Data for Name: service_health_history; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.service_health_history (id, service_key, status, http_status, response_ms, checked_at) FROM stdin;
\.


--
-- Data for Name: smart_contract_deployments; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.smart_contract_deployments (id, contract_name, network, contract_address, deploy_tx_hash, version, abi_hash, deployer, supply_cap, mint_cap_per_epoch, burn_cap_per_epoch, status, audit_report_url, created_at) FROM stdin;
\.


--
-- Data for Name: smart_contract_events; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.smart_contract_events (id, contract_name, event_type, tx_hash, block_number, gas_used, from_address, to_address, amount, nonce, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: soc_alerts; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.soc_alerts (id, alert_id, type, severity, status, source, title, description, affected_system, source_ip, mitre_tactic, mitre_id, raw_payload, resolved_by, resolved_at, created_at, updated_at) FROM stdin;
1	SOC-00001	anomaly	medium	investigating	siem	Unusual data egress	Security event detected by monitoring pipeline	wallet-svc	102.89.1.7	\N	\N	\N	\N	\N	2026-06-22 21:50:55.460046	2026-06-22 21:50:55.460046
2	SOC-00002	policy_violation	high	resolved	siem	WAF rule triggered	Security event detected by monitoring pipeline	bis-engine	102.89.2.14	\N	\N	\N	\N	\N	2026-06-21 21:50:55.460046	2026-06-21 21:50:55.460046
3	SOC-00003	threat_intel	critical	open	siem	Brute-force attempt	Security event detected by monitoring pipeline	auth-svc	102.89.3.21	\N	\N	\N	\N	\N	2026-06-20 21:50:55.460046	2026-06-20 21:50:55.460046
4	SOC-00004	compliance	low	investigating	siem	Privilege escalation	Security event detected by monitoring pipeline	api-gateway	102.89.4.28	\N	\N	\N	\N	\N	2026-06-19 21:50:55.460046	2026-06-19 21:50:55.460046
5	SOC-00005	data_exfiltration	medium	resolved	siem	Suspicious login burst	Security event detected by monitoring pipeline	wallet-svc	102.89.5.35	\N	\N	\N	\N	\N	2026-06-18 21:50:55.460046	2026-06-18 21:50:55.460046
6	SOC-00006	intrusion	high	open	siem	Unusual data egress	Security event detected by monitoring pipeline	bis-engine	102.89.6.42	\N	\N	\N	\N	\N	2026-06-17 21:50:55.460046	2026-06-17 21:50:55.460046
7	SOC-00007	anomaly	critical	investigating	siem	WAF rule triggered	Security event detected by monitoring pipeline	auth-svc	102.89.7.49	\N	\N	\N	\N	\N	2026-06-16 21:50:55.460046	2026-06-16 21:50:55.460046
8	SOC-00008	policy_violation	low	resolved	siem	Brute-force attempt	Security event detected by monitoring pipeline	api-gateway	102.89.8.56	\N	\N	\N	\N	\N	2026-06-15 21:50:55.460046	2026-06-15 21:50:55.460046
9	SOC-00009	threat_intel	medium	open	siem	Privilege escalation	Security event detected by monitoring pipeline	wallet-svc	102.89.9.63	\N	\N	\N	\N	\N	2026-06-14 21:50:55.460046	2026-06-14 21:50:55.460046
10	SOC-00010	compliance	high	investigating	siem	Suspicious login burst	Security event detected by monitoring pipeline	bis-engine	102.89.10.70	\N	\N	\N	\N	\N	2026-06-13 21:50:55.460046	2026-06-13 21:50:55.460046
11	SOC-00011	data_exfiltration	critical	resolved	siem	Unusual data egress	Security event detected by monitoring pipeline	auth-svc	102.89.11.77	\N	\N	\N	\N	\N	2026-06-12 21:50:55.460046	2026-06-12 21:50:55.460046
12	SOC-00012	intrusion	low	open	siem	WAF rule triggered	Security event detected by monitoring pipeline	api-gateway	102.89.12.84	\N	\N	\N	\N	\N	2026-06-11 21:50:55.460046	2026-06-11 21:50:55.460046
13	SOC-00013	anomaly	medium	investigating	siem	Brute-force attempt	Security event detected by monitoring pipeline	wallet-svc	102.89.13.91	\N	\N	\N	\N	\N	2026-06-10 21:50:55.460046	2026-06-10 21:50:55.460046
14	SOC-00014	policy_violation	high	resolved	siem	Privilege escalation	Security event detected by monitoring pipeline	bis-engine	102.89.14.98	\N	\N	\N	\N	\N	2026-06-09 21:50:55.460046	2026-06-09 21:50:55.460046
\.


--
-- Data for Name: stablecoin_limit_orders; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.stablecoin_limit_orders (id, user_id, direction, stablecoin, fiat_currency, amount, target_rate, status, filled_at, expires_at, result_order_id, created_at) FROM stdin;
\.


--
-- Data for Name: stablecoin_offramp_requests; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.stablecoin_offramp_requests (id, user_id, status, source_stablecoin, source_amount, source_network, burn_tx_hash, target_currency, target_amount, payout_rail, payout_ref, recipient_name, recipient_phone, recipient_bank, recipient_account, recipient_country, exchange_rate, fee, fee_percent, spread_percent, provider_name, provider_ref, mojaloop_ref, tb_transfer_id, kyc_verified, bis_reference_id, fraud_score, velocity_check_passed, error_code, error_message, quote_expires_at, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stablecoin_onramp_orders; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.stablecoin_onramp_orders (id, user_id, status, source_currency, source_amount, payment_rail, payment_ref, target_stablecoin, target_amount, target_wallet_address, target_network, exchange_rate, fee, fee_percent, spread_percent, mint_tx_hash, provider_name, provider_ref, kyc_verified, bis_reference_id, country, mobile_number, error_code, error_message, quote_expires_at, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stablecoin_yield_positions; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.stablecoin_yield_positions (id, user_id, stablecoin, principal_amount, current_amount, apy_bps, protocol, status, deposit_tx_hash, withdraw_tx_hash, accrued_yield, last_accrual_at, withdrawn_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: staff_invites; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.staff_invites (id, token, establishment_id, inviter_user_id, email, role, status, accepted_by_user_id, accepted_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tip_configs; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.tip_configs (id, establishment_id, jurisdiction_code, custom_percentages, distribution_type, pool_split_rules, is_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tourism_events; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.tourism_events (id, name, country, city, category, expected_attendees, start_date, end_date, description, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: tourist_bookings; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.tourist_bookings (id, user_id, establishment_id, service_type, service_name, booking_date, party_size, price_usd, currency, status, notes, confirmation_code, wallet_tx_id, created_at, updated_at, reminder_enabled, reminder_sent_at, tourist_reminder_sent_at, product_id, booking_date_str) FROM stdin;
\.


--
-- Data for Name: tourist_budgets; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.tourist_budgets (id, user_id, daily_limit_usd, weekly_limit_usd, trip_limit_usd, alert_at_80_percent, alert_at_100_percent, categories, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tourist_concierge_sessions; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.tourist_concierge_sessions (id, user_id, messages, context, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tourist_deal_redemptions; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.tourist_deal_redemptions (id, user_id, deal_id, establishment_id, redemption_code, status, redeemed_at, confirmed_at, confirmed_by, notes, review_prompted_at) FROM stdin;
268	3	29	1	RDM-29-10	redeemed	2026-06-13 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.151
142	3	29	1	RDM-29-1	redeemed	2026-06-22 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:51.852
143	3	30	1	RDM-30-1	redeemed	2026-06-22 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:51.868
144	3	31	14	RDM-31-1	redeemed	2026-06-22 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:51.88
145	3	32	14	RDM-32-1	redeemed	2026-06-22 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:51.89
146	3	33	15	RDM-33-1	redeemed	2026-06-22 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:51.901
147	3	34	15	RDM-34-1	redeemed	2026-06-22 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:51.912
148	3	35	16	RDM-35-1	redeemed	2026-06-22 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:51.921
149	3	36	16	RDM-36-1	redeemed	2026-06-22 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:51.931
150	3	37	17	RDM-37-1	redeemed	2026-06-22 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:51.942
151	3	38	17	RDM-38-1	redeemed	2026-06-22 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:51.955
152	3	39	18	RDM-39-1	redeemed	2026-06-22 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:51.965
153	3	40	18	RDM-40-1	redeemed	2026-06-22 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:51.979
154	3	41	19	RDM-41-1	redeemed	2026-06-22 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:51.988
155	3	42	19	RDM-42-1	redeemed	2026-06-22 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:51.998
156	3	29	1	RDM-29-2	redeemed	2026-06-21 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.008
157	3	30	1	RDM-30-2	redeemed	2026-06-21 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.018
158	3	31	14	RDM-31-2	redeemed	2026-06-21 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.028
159	3	32	14	RDM-32-2	redeemed	2026-06-21 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.039
160	3	33	15	RDM-33-2	redeemed	2026-06-21 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.05
161	3	34	15	RDM-34-2	redeemed	2026-06-21 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.06
162	3	35	16	RDM-35-2	redeemed	2026-06-21 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.069
163	3	36	16	RDM-36-2	redeemed	2026-06-21 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.079
164	3	37	17	RDM-37-2	redeemed	2026-06-21 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.09
165	3	38	17	RDM-38-2	redeemed	2026-06-21 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.1
166	3	39	18	RDM-39-2	redeemed	2026-06-21 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.108
167	3	40	18	RDM-40-2	redeemed	2026-06-21 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.115
168	3	41	19	RDM-41-2	redeemed	2026-06-21 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.124
169	3	42	19	RDM-42-2	redeemed	2026-06-21 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.134
170	3	29	1	RDM-29-3	redeemed	2026-06-20 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.143
171	3	30	1	RDM-30-3	redeemed	2026-06-20 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.151
172	3	31	14	RDM-31-3	redeemed	2026-06-20 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.162
173	3	32	14	RDM-32-3	redeemed	2026-06-20 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.17
174	3	33	15	RDM-33-3	redeemed	2026-06-20 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.182
175	3	34	15	RDM-34-3	redeemed	2026-06-20 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.202
176	3	35	16	RDM-35-3	redeemed	2026-06-20 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.218
177	3	36	16	RDM-36-3	redeemed	2026-06-20 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.227
178	3	37	17	RDM-37-3	redeemed	2026-06-20 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.263
179	3	38	17	RDM-38-3	redeemed	2026-06-20 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.275
180	3	39	18	RDM-39-3	redeemed	2026-06-20 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.285
181	3	40	18	RDM-40-3	redeemed	2026-06-20 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.295
182	3	41	19	RDM-41-3	redeemed	2026-06-20 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.304
183	3	42	19	RDM-42-3	redeemed	2026-06-20 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.314
184	3	29	1	RDM-29-4	redeemed	2026-06-19 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.324
185	3	30	1	RDM-30-4	redeemed	2026-06-19 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.335
186	3	31	14	RDM-31-4	redeemed	2026-06-19 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.343
187	3	32	14	RDM-32-4	redeemed	2026-06-19 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.352
188	3	33	15	RDM-33-4	redeemed	2026-06-19 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.36
189	3	34	15	RDM-34-4	redeemed	2026-06-19 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.367
190	3	35	16	RDM-35-4	redeemed	2026-06-19 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.376
191	3	36	16	RDM-36-4	redeemed	2026-06-19 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.384
192	3	37	17	RDM-37-4	redeemed	2026-06-19 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.392
193	3	38	17	RDM-38-4	redeemed	2026-06-19 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.4
194	3	39	18	RDM-39-4	redeemed	2026-06-19 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.408
195	3	40	18	RDM-40-4	redeemed	2026-06-19 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.414
275	3	36	16	RDM-36-10	redeemed	2026-06-13 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.22
196	3	41	19	RDM-41-4	redeemed	2026-06-19 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.423
197	3	42	19	RDM-42-4	redeemed	2026-06-19 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.431
198	3	29	1	RDM-29-5	redeemed	2026-06-18 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.439
199	3	30	1	RDM-30-5	redeemed	2026-06-18 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.446
200	3	31	14	RDM-31-5	redeemed	2026-06-18 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.452
201	3	32	14	RDM-32-5	redeemed	2026-06-18 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.459
202	3	33	15	RDM-33-5	redeemed	2026-06-18 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.468
203	3	34	15	RDM-34-5	redeemed	2026-06-18 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.479
204	3	35	16	RDM-35-5	redeemed	2026-06-18 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.487
205	3	36	16	RDM-36-5	redeemed	2026-06-18 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.495
206	3	37	17	RDM-37-5	redeemed	2026-06-18 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.502
207	3	38	17	RDM-38-5	redeemed	2026-06-18 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.509
208	3	39	18	RDM-39-5	redeemed	2026-06-18 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.516
209	3	40	18	RDM-40-5	redeemed	2026-06-18 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.523
210	3	41	19	RDM-41-5	redeemed	2026-06-18 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.53
211	3	42	19	RDM-42-5	redeemed	2026-06-18 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.538
212	3	29	1	RDM-29-6	redeemed	2026-06-17 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.546
213	3	30	1	RDM-30-6	redeemed	2026-06-17 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.553
214	3	31	14	RDM-31-6	redeemed	2026-06-17 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.56
215	3	32	14	RDM-32-6	redeemed	2026-06-17 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.566
216	3	33	15	RDM-33-6	redeemed	2026-06-17 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.573
217	3	34	15	RDM-34-6	redeemed	2026-06-17 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.579
218	3	35	16	RDM-35-6	redeemed	2026-06-17 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.586
219	3	36	16	RDM-36-6	redeemed	2026-06-17 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.592
220	3	37	17	RDM-37-6	redeemed	2026-06-17 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.598
221	3	38	17	RDM-38-6	redeemed	2026-06-17 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.604
222	3	39	18	RDM-39-6	redeemed	2026-06-17 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.611
223	3	40	18	RDM-40-6	redeemed	2026-06-17 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.618
224	3	41	19	RDM-41-6	redeemed	2026-06-17 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.625
225	3	42	19	RDM-42-6	redeemed	2026-06-17 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.633
226	3	29	1	RDM-29-7	redeemed	2026-06-16 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.642
227	3	30	1	RDM-30-7	redeemed	2026-06-16 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.658
228	3	31	14	RDM-31-7	redeemed	2026-06-16 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.665
229	3	32	14	RDM-32-7	redeemed	2026-06-16 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.674
230	3	33	15	RDM-33-7	redeemed	2026-06-16 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.682
231	3	34	15	RDM-34-7	redeemed	2026-06-16 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.69
232	3	35	16	RDM-35-7	redeemed	2026-06-16 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.697
233	3	36	16	RDM-36-7	redeemed	2026-06-16 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.704
234	3	37	17	RDM-37-7	redeemed	2026-06-16 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.711
235	3	38	17	RDM-38-7	redeemed	2026-06-16 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.72
236	3	39	18	RDM-39-7	redeemed	2026-06-16 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.731
237	3	40	18	RDM-40-7	redeemed	2026-06-16 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.74
238	3	41	19	RDM-41-7	redeemed	2026-06-16 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.75
239	3	42	19	RDM-42-7	redeemed	2026-06-16 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.758
240	3	29	1	RDM-29-8	redeemed	2026-06-15 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.768
241	3	30	1	RDM-30-8	redeemed	2026-06-15 21:50:55.460046	\N	\N	\N	2026-06-23 21:58:52.777
242	3	31	14	RDM-31-8	redeemed	2026-06-15 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:32.812
243	3	32	14	RDM-32-8	redeemed	2026-06-15 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:32.826
244	3	33	15	RDM-33-8	redeemed	2026-06-15 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:32.845
245	3	34	15	RDM-34-8	redeemed	2026-06-15 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:32.884
246	3	35	16	RDM-35-8	redeemed	2026-06-15 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:32.896
247	3	36	16	RDM-36-8	redeemed	2026-06-15 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:32.914
248	3	37	17	RDM-37-8	redeemed	2026-06-15 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:32.927
249	3	38	17	RDM-38-8	redeemed	2026-06-15 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:32.951
250	3	39	18	RDM-39-8	redeemed	2026-06-15 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:32.964
251	3	40	18	RDM-40-8	redeemed	2026-06-15 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:32.974
252	3	41	19	RDM-41-8	redeemed	2026-06-15 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:32.982
253	3	42	19	RDM-42-8	redeemed	2026-06-15 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:32.991
254	3	29	1	RDM-29-9	redeemed	2026-06-14 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:32.999
255	3	30	1	RDM-30-9	redeemed	2026-06-14 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.009
256	3	31	14	RDM-31-9	redeemed	2026-06-14 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.018
257	3	32	14	RDM-32-9	redeemed	2026-06-14 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.027
258	3	33	15	RDM-33-9	redeemed	2026-06-14 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.038
259	3	34	15	RDM-34-9	redeemed	2026-06-14 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.049
260	3	35	16	RDM-35-9	redeemed	2026-06-14 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.058
261	3	36	16	RDM-36-9	redeemed	2026-06-14 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.086
262	3	37	17	RDM-37-9	redeemed	2026-06-14 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.094
263	3	38	17	RDM-38-9	redeemed	2026-06-14 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.103
264	3	39	18	RDM-39-9	redeemed	2026-06-14 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.112
265	3	40	18	RDM-40-9	redeemed	2026-06-14 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.121
266	3	41	19	RDM-41-9	redeemed	2026-06-14 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.131
267	3	42	19	RDM-42-9	redeemed	2026-06-14 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.142
269	3	30	1	RDM-30-10	redeemed	2026-06-13 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.16
270	3	31	14	RDM-31-10	redeemed	2026-06-13 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.169
271	3	32	14	RDM-32-10	redeemed	2026-06-13 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.178
272	3	33	15	RDM-33-10	redeemed	2026-06-13 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.188
273	3	34	15	RDM-34-10	redeemed	2026-06-13 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.202
274	3	35	16	RDM-35-10	redeemed	2026-06-13 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.211
276	3	37	17	RDM-37-10	redeemed	2026-06-13 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.229
277	3	38	17	RDM-38-10	redeemed	2026-06-13 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.24
278	3	39	18	RDM-39-10	redeemed	2026-06-13 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.251
279	3	40	18	RDM-40-10	redeemed	2026-06-13 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.309
280	3	41	19	RDM-41-10	redeemed	2026-06-13 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.325
281	3	42	19	RDM-42-10	redeemed	2026-06-13 21:50:55.460046	\N	\N	\N	2026-06-23 22:00:33.335
\.


--
-- Data for Name: tourist_deal_wishlists; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.tourist_deal_wishlists (id, user_id, deal_id, created_at, alerted_at) FROM stdin;
\.


--
-- Data for Name: tourist_deals; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.tourist_deals (id, establishment_id, title, description, discount_percent, discount_amount_usd, promo_code, category, image_url, valid_from, valid_to, max_redemptions, redemption_count, is_active, created_at, visibility_score, boosted_until, boosted_at, boost_budget_usd, boost_spent_usd) FROM stdin;
29	1	Safari 20% Off	Save on game drives	20	70.000000	SAFARI20-1	experience	\N	2026-05-24 21:50:55.460046	2026-07-23 21:50:55.460046	200	84	t	2026-05-29 21:50:55.460046	0	\N	\N	\N	0.00
30	1	Early Bird Cruise	Book ahead and save	15	12.750000	EARLY15-1	experience	\N	2026-05-24 21:50:55.460046	2026-07-23 21:50:55.460046	150	52	t	2026-05-29 21:50:55.460046	0	\N	\N	\N	0.00
31	14	Safari 20% Off	Save on game drives	20	70.000000	SAFARI20-14	experience	\N	2026-05-24 21:50:55.460046	2026-07-23 21:50:55.460046	200	84	t	2026-05-29 21:50:55.460046	0	\N	\N	\N	0.00
32	14	Early Bird Cruise	Book ahead and save	15	12.750000	EARLY15-14	experience	\N	2026-05-24 21:50:55.460046	2026-07-23 21:50:55.460046	150	52	t	2026-05-29 21:50:55.460046	0	\N	\N	\N	0.00
33	15	Safari 20% Off	Save on game drives	20	70.000000	SAFARI20-15	experience	\N	2026-05-24 21:50:55.460046	2026-07-23 21:50:55.460046	200	84	t	2026-05-29 21:50:55.460046	0	\N	\N	\N	0.00
34	15	Early Bird Cruise	Book ahead and save	15	12.750000	EARLY15-15	experience	\N	2026-05-24 21:50:55.460046	2026-07-23 21:50:55.460046	150	52	t	2026-05-29 21:50:55.460046	0	\N	\N	\N	0.00
35	16	Safari 20% Off	Save on game drives	20	70.000000	SAFARI20-16	experience	\N	2026-05-24 21:50:55.460046	2026-07-23 21:50:55.460046	200	84	t	2026-05-29 21:50:55.460046	0	\N	\N	\N	0.00
36	16	Early Bird Cruise	Book ahead and save	15	12.750000	EARLY15-16	experience	\N	2026-05-24 21:50:55.460046	2026-07-23 21:50:55.460046	150	52	t	2026-05-29 21:50:55.460046	0	\N	\N	\N	0.00
37	17	Safari 20% Off	Save on game drives	20	70.000000	SAFARI20-17	experience	\N	2026-05-24 21:50:55.460046	2026-07-23 21:50:55.460046	200	84	t	2026-05-29 21:50:55.460046	0	\N	\N	\N	0.00
38	17	Early Bird Cruise	Book ahead and save	15	12.750000	EARLY15-17	experience	\N	2026-05-24 21:50:55.460046	2026-07-23 21:50:55.460046	150	52	t	2026-05-29 21:50:55.460046	0	\N	\N	\N	0.00
39	18	Safari 20% Off	Save on game drives	20	70.000000	SAFARI20-18	experience	\N	2026-05-24 21:50:55.460046	2026-07-23 21:50:55.460046	200	84	t	2026-05-29 21:50:55.460046	0	\N	\N	\N	0.00
40	18	Early Bird Cruise	Book ahead and save	15	12.750000	EARLY15-18	experience	\N	2026-05-24 21:50:55.460046	2026-07-23 21:50:55.460046	150	52	t	2026-05-29 21:50:55.460046	0	\N	\N	\N	0.00
41	19	Safari 20% Off	Save on game drives	20	70.000000	SAFARI20-19	experience	\N	2026-05-24 21:50:55.460046	2026-07-23 21:50:55.460046	200	84	t	2026-05-29 21:50:55.460046	0	\N	\N	\N	0.00
42	19	Early Bird Cruise	Book ahead and save	15	12.750000	EARLY15-19	experience	\N	2026-05-24 21:50:55.460046	2026-07-23 21:50:55.460046	150	52	t	2026-05-29 21:50:55.460046	0	\N	\N	\N	0.00
\.


--
-- Data for Name: tourist_itineraries; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.tourist_itineraries (id, user_id, title, destination, start_date, end_date, items, budget_usd, is_public, cover_image_url, created_at, updated_at, status, currency, description, share_token, share_export_url) FROM stdin;
\.


--
-- Data for Name: tourist_itinerary_items; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.tourist_itinerary_items (id, itinerary_id, day_number, order_in_day, establishment_id, booking_id, deal_id, title, notes, start_time, end_time, estimated_cost_usd, item_type, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tourist_onboarding_state; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.tourist_onboarding_state (id, user_id, step, completed_steps, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tourist_profiles; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.tourist_profiles (id, user_id, home_currency, home_country, preferred_language, linked_card_last4, linked_card_brand, onboarding_completed, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tourist_reviews; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.tourist_reviews (id, user_id, establishment_id, booking_id, rating, title, body, tags, photos, helpful_votes, is_verified_purchase, created_at, updated_at, merchant_response, merchant_responded_at) FROM stdin;
\.


--
-- Data for Name: tourist_topups; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.tourist_topups (id, user_id, amount_usd, target_currency, fx_rate, credited_amount, stripe_payment_intent_id, stripe_session_id, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tourist_trip_summaries; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.tourist_trip_summaries (id, user_id, date_from, date_to, total_spent_usd, total_points_earned, payment_count, establishment_count, report_url, report_key, created_at) FROM stdin;
\.


--
-- Data for Name: trusted_devices; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.trusted_devices (id, user_id, device_fingerprint, device_name, device_type, last_used_at, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_notifications; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.user_notifications (id, user_id, category, title, content, action_url, action_label, is_read, read_at, metadata, created_at) FROM stdin;
1	1	bis	✅ Investigation Completed: John Mensah	Background investigation for John Mensah (BIS-2026-0024) is completed. Risk score: 21/100 (low). Proceed with hiring — low risk profile	/bis/report/48	View Report	f	\N	\N	2026-06-23 21:51:51.853172
2	2	bis	✅ BIS Investigation Complete — KYB Eligible	Your Background Investigation (BIS-2026-0024) for Nairobi Night Safari is complete. Risk score: 21/100 (low). Your KYB application is now eligible for admin approval — this typically takes 1–3 business days.	/merchant/bis-status	View BIS Status	f	\N	\N	2026-06-23 21:51:51.863646
3	2	bis	✅ BIS Investigation Complete — KYB Eligible — TourismPay	Your Background Investigation (BIS-2026-0024) for Nairobi Night Safari is complete. Risk score: 21/100 (low). Your KYB application is now eligible for admin approval — this typically takes 1–3 business days.	/merchant/bis-status	View BIS Status	f	\N	\N	2026-06-23 21:51:51.870744
4	1	bis	✅ Investigation Completed: Fatima Bello	Background investigation for Fatima Bello (BIS-2026-0019) is completed. Risk score: 24/100 (low). Proceed with hiring — low risk profile	/bis/report/43	View Report	f	\N	\N	2026-06-23 21:51:51.884629
5	2	bis	✅ BIS Investigation Complete — KYB Eligible	Your Background Investigation (BIS-2026-0019) for Accra Artisan Market is complete. Risk score: 24/100 (low). Your KYB application is now eligible for admin approval — this typically takes 1–3 business days.	/merchant/bis-status	View BIS Status	f	\N	\N	2026-06-23 21:51:51.892329
6	2	bis	✅ BIS Investigation Complete — KYB Eligible — TourismPay	Your Background Investigation (BIS-2026-0019) for Accra Artisan Market is complete. Risk score: 24/100 (low). Your KYB application is now eligible for admin approval — this typically takes 1–3 business days.	/merchant/bis-status	View BIS Status	f	\N	\N	2026-06-23 21:51:51.898882
7	1	bis	🚩 Investigation Flagged: Ibrahim Sani	Background investigation for Ibrahim Sani (BIS-2026-0014) is flagged. Risk score: 81/100 (critical). Critical risk — do not proceed without full legal review	/bis/report/38	View Report	f	\N	\N	2026-06-23 21:51:51.912337
8	2	bis	⚠️ BIS Investigation Flagged — Action Required	Your Background Investigation (BIS-2026-0014) for Serengeti Safari Experience has been flagged for review. Risk score: 81/100. A compliance officer will contact you within 2 business days. You can view the status on your BIS Compliance page.	/merchant/bis-status	View BIS Status	f	\N	\N	2026-06-23 21:51:51.920072
9	2	bis	⚠️ BIS Investigation Flagged — Action Required — TourismPay	Your Background Investigation (BIS-2026-0014) for Serengeti Safari Experience has been flagged for review. Risk score: 81/100. A compliance officer will contact you within 2 business days. You can view the status on your BIS Compliance page.	/merchant/bis-status	View BIS Status	f	\N	\N	2026-06-23 21:51:51.926047
10	1	bis	✅ Investigation Completed: Amara Diallo	Background investigation for Amara Diallo (BIS-2026-0009) is completed. Risk score: 11/100 (low). Proceed with hiring — low risk profile	/bis/report/33	View Report	f	\N	\N	2026-06-23 21:51:51.939137
11	2	bis	✅ BIS Investigation Complete — KYB Eligible	Your Background Investigation (BIS-2026-0009) for Kilimanjaro Adventures is complete. Risk score: 11/100 (low). Your KYB application is now eligible for admin approval — this typically takes 1–3 business days.	/merchant/bis-status	View BIS Status	f	\N	\N	2026-06-23 21:51:51.946895
12	2	bis	✅ BIS Investigation Complete — KYB Eligible — TourismPay	Your Background Investigation (BIS-2026-0009) for Kilimanjaro Adventures is complete. Risk score: 11/100 (low). Your KYB application is now eligible for admin approval — this typically takes 1–3 business days.	/merchant/bis-status	View BIS Status	f	\N	\N	2026-06-23 21:51:51.953085
13	1	bis	✅ Investigation Completed: Thabo Nkosi	Background investigation for Thabo Nkosi (BIS-2026-0004) is completed. Risk score: 51/100 (medium). Proceed with caution — medium risk profile	/bis/report/28	View Report	f	\N	\N	2026-06-23 21:51:51.964543
14	2	bis	✅ BIS Investigation Complete — KYB Eligible	Your Background Investigation (BIS-2026-0004) for Cape Town Wine Tours is complete. Risk score: 51/100 (medium). Your KYB application is now eligible for admin approval — this typically takes 1–3 business days.	/merchant/bis-status	View BIS Status	f	\N	\N	2026-06-23 21:51:51.971099
15	2	bis	✅ BIS Investigation Complete — KYB Eligible — TourismPay	Your Background Investigation (BIS-2026-0004) for Cape Town Wine Tours is complete. Risk score: 51/100 (medium). Your KYB application is now eligible for admin approval — this typically takes 1–3 business days.	/merchant/bis-status	View BIS Status	f	\N	\N	2026-06-23 21:51:51.976438
16	2	system	Complete your setup — 50% done	Your onboarding score for **Zanzibar Beach Resort** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-06-23 22:01:02.634
17	2	system	Complete your setup — 50% done	Your onboarding score for **Kilimanjaro Adventures** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-06-23 22:01:02.662
18	2	system	Complete your setup — 50% done	Your onboarding score for **Nairobi Night Safari** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-06-23 22:01:02.683
19	2	system	Complete your setup — 50% done	Your onboarding score for **Cape Town Wine Tours** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-06-23 22:01:02.701
20	2	system	Complete your setup — 50% done	Your onboarding score for **Accra Artisan Market** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-06-23 22:01:02.719
21	2	system	Complete your setup — 50% done	Your onboarding score for **Victoria Falls Hotel** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-06-23 22:01:02.734
22	2	system	Complete your setup — 50% done	Your onboarding score for **Zanzibar Beach Resort** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-06-30 22:24:44.831
23	2	system	Complete your setup — 50% done	Your onboarding score for **Kilimanjaro Adventures** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-06-30 22:24:44.878
24	2	system	Complete your setup — 50% done	Your onboarding score for **Nairobi Night Safari** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-06-30 22:24:44.902
25	2	system	Complete your setup — 50% done	Your onboarding score for **Cape Town Wine Tours** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-06-30 22:24:44.92
26	2	system	Complete your setup — 50% done	Your onboarding score for **Accra Artisan Market** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-06-30 22:24:44.939
27	2	system	Complete your setup — 50% done	Your onboarding score for **Victoria Falls Hotel** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-06-30 22:24:44.961
28	2	system	Complete your setup — 50% done	Your onboarding score for **Zanzibar Beach Resort** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-07-07 22:24:44.798
29	2	system	Complete your setup — 50% done	Your onboarding score for **Kilimanjaro Adventures** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-07-07 22:24:44.824
30	2	system	Complete your setup — 50% done	Your onboarding score for **Nairobi Night Safari** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-07-07 22:24:44.842
31	2	system	Complete your setup — 50% done	Your onboarding score for **Cape Town Wine Tours** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-07-07 22:24:44.867
32	2	system	Complete your setup — 50% done	Your onboarding score for **Accra Artisan Market** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-07-07 22:24:44.884
33	2	system	Complete your setup — 50% done	Your onboarding score for **Victoria Falls Hotel** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-07-07 22:24:44.899
34	2	system	Complete your setup — 50% done	Your onboarding score for **Zanzibar Beach Resort** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-07-14 22:24:44.808
35	2	system	Complete your setup — 50% done	Your onboarding score for **Kilimanjaro Adventures** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-07-14 22:24:44.828
36	2	system	Complete your setup — 50% done	Your onboarding score for **Nairobi Night Safari** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-07-14 22:24:44.852
37	2	system	Complete your setup — 50% done	Your onboarding score for **Cape Town Wine Tours** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-07-14 22:24:44.866
38	2	system	Complete your setup — 50% done	Your onboarding score for **Accra Artisan Market** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-07-14 22:24:44.879
39	2	system	Complete your setup — 50% done	Your onboarding score for **Victoria Falls Hotel** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-07-14 22:24:44.891
40	2	system	Complete your setup — 50% done	Your onboarding score for **Zanzibar Beach Resort** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-07-21 22:24:44.827
41	2	system	Complete your setup — 50% done	Your onboarding score for **Kilimanjaro Adventures** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-07-21 22:24:44.848
42	2	system	Complete your setup — 50% done	Your onboarding score for **Nairobi Night Safari** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-07-21 22:24:44.877
43	2	system	Complete your setup — 50% done	Your onboarding score for **Cape Town Wine Tours** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-07-21 22:24:44.89
44	2	system	Complete your setup — 50% done	Your onboarding score for **Accra Artisan Market** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-07-21 22:24:44.9
45	2	system	Complete your setup — 50% done	Your onboarding score for **Victoria Falls Hotel** is **50%** — below the recommended 60%.\n\nComplete these steps to start receiving bookings and payments:\n• Complete establishment details\n• Upload KYB compliance documents\n• Connect Stripe for payouts\n\nLog in to your dashboard to continue.	/restaurant-onboarding	Continue Setup	f	\N	\N	2026-07-21 22:24:44.912
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.users (id, open_id, name, email, login_method, role, created_at, updated_at, last_signed_in, login_count, onboarding_completed, theme, preferred_language, preferred_currency) FROM stdin;
2	demo_merchant_001	Kofi Mensah	kofi.mensah@demo.tourismpay.com	demo	merchant	2026-06-23 11:27:52.972574	2026-06-23 22:06:31.288	2026-06-23 22:06:58.942	90	t	dark	en	USDC
1	demo_admin_001	Patrick Munis	admin@tourismpay.io	demo	admin	2026-06-23 11:27:49.445666	2026-07-22 17:37:25.362	2026-07-22 18:35:36.127	2489	t	dark	en	USDC
3	demo_tourist_001	Amara Diallo	amara.diallo@demo.tourismpay.com	demo	tourist	2026-06-23 11:27:54.647939	2026-06-23 21:24:20.509	2026-07-22 18:40:29.758	89	t	dark	en	USDC
\.


--
-- Data for Name: verifiable_credentials; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.verifiable_credentials (id, user_id, type, issuer, subject, credential_data, status, expires_at, revoked_at, created_at) FROM stdin;
\.


--
-- Data for Name: wallet_balance_alerts; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.wallet_balance_alerts (id, user_id, currency, threshold, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: wallet_balances; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.wallet_balances (id, user_id, currency, balance, locked_balance, wallet_address, network, created_at, updated_at) FROM stdin;
7b96d4d7-6e5d-4bb2-9501-315e88fe75b9	1	USDC	0.000000	0.000000	tp_usdc_1	Stellar / Ethereum	1782229916	1782229916
f1bf9074-f71f-4fc1-80c2-11ede21ec53c	1	CBDC-NG	0.000000	0.000000	tp_cbdc_ng_1	CBN Digital	1782229916	1782229916
5964e477-fc0c-45f4-888a-686abf259dfa	1	XLM	0.000000	0.000000	tp_xlm_1	Stellar	1782229916	1782229916
4b1be736-e60f-4fca-969f-6fe0573af969	2	USDC	0.000000	0.000000	tp_usdc_2	Stellar / Ethereum	1782249837	1782249837
c09a0491-b39c-4bc3-8275-c339b03a81cc	2	USDC	0.000000	0.000000	tp_usdc_2	Stellar / Ethereum	1782249837	1782249837
8368005e-2402-42c0-8b83-4dd7fd3ee860	2	USDC	0.000000	0.000000	tp_usdc_2	Stellar / Ethereum	1782249837	1782249837
371fccb4-f8fc-4d47-8115-14abbd72b0b5	2	CBDC-NG	0.000000	0.000000	tp_cbdc_ng_2	CBN Digital	1782249837	1782249837
13d0eb1f-cd58-4558-ae56-1c6e7f4469e1	2	CBDC-NG	0.000000	0.000000	tp_cbdc_ng_2	CBN Digital	1782249837	1782249837
3f4f8e5e-fecc-45b5-8e70-f80c762a7696	2	CBDC-NG	0.000000	0.000000	tp_cbdc_ng_2	CBN Digital	1782249837	1782249837
f0fa8785-8673-4a91-9862-296e14fedba6	2	XLM	0.000000	0.000000	tp_xlm_2	Stellar	1782249837	1782249837
76618ebf-88d7-47bd-aaab-0d2be33b02a6	2	XLM	0.000000	0.000000	tp_xlm_2	Stellar	1782249837	1782249837
c79f502b-9750-4646-848c-05b0dba9c9f1	2	XLM	0.000000	0.000000	tp_xlm_2	Stellar	1782249837	1782249837
c596d448-0c11-4399-95ff-1981de922cd0	3	USDC	0.000000	0.000000	tp_usdc_3	Stellar / Ethereum	1782249856	1782249856
6ef3901e-32a9-4c73-86f5-539fa0ac9166	3	CBDC-NG	0.000000	0.000000	tp_cbdc_ng_3	CBN Digital	1782249856	1782249856
b4c1bc36-f3fc-4e8f-93ca-bf363dbef317	3	XLM	0.000000	0.000000	tp_xlm_3	Stellar	1782249856	1782249856
\.


--
-- Data for Name: wallet_recurring_payments; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.wallet_recurring_payments (id, user_id, currency, recipient_address, recipient_name, amount, note, frequency, status, next_run_at, last_run_at, run_count, failure_reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: wallet_spending_limits; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.wallet_spending_limits (id, user_id, currency, period, limit_amount, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: wallet_transactions; Type: TABLE DATA; Schema: public; Owner: tourismpay
--

COPY public.wallet_transactions (id, user_id, type, status, from_currency, to_currency, amount, to_amount, fee, counterparty, counterparty_address, reference, note, tx_hash, completed_at, created_at) FROM stdin;
743b40a5-83c2-4544-9033-a0a63427d78b	3	receive	completed	USD	\N	73.000000	\N	0.250000	Zanzibar Resort	\N	WTX-000001	\N	\N	1782165055	1782165055
c5426c2e-94cb-48b2-9c7a-aef0ff8f5c92	3	deposit	completed	KES	\N	126.000000	\N	0.500000	Local Vendor	\N	WTX-000002	\N	\N	1782078655	1782078655
aefdfb1a-87c5-4290-ad38-a9c82a5989b4	3	send	completed	TZS	\N	179.000000	\N	0.750000	ATM Withdrawal	\N	WTX-000003	\N	\N	1781992255	1781992255
39d23562-0478-46c6-98ce-ad0f493d7abb	3	receive	completed	USDC	\N	232.000000	\N	1.000000	Serengeti Safari	\N	WTX-000004	\N	\N	1781905855	1781905855
15cf3295-eeb0-4ce9-9e7a-c758a32abe10	3	send	completed	USD	\N	285.000000	\N	0.000000	Zanzibar Resort	\N	WTX-000005	\N	\N	1781819455	1781819455
a0ad6f52-87d7-4f5e-896a-c98fc654e859	3	receive	completed	KES	\N	338.000000	\N	0.250000	Local Vendor	\N	WTX-000006	\N	\N	1781733055	1781733055
0ca248c2-5ff4-47c2-b04f-740299ca322d	3	deposit	completed	TZS	\N	391.000000	\N	0.500000	ATM Withdrawal	\N	WTX-000007	\N	\N	1781646655	1781646655
9389627d-7c31-4db3-80c9-dc60342449f2	3	send	completed	USDC	\N	444.000000	\N	0.750000	Serengeti Safari	\N	WTX-000008	\N	\N	1781560255	1781560255
fa0d3395-1116-4ecd-8ccc-ab502129f55f	3	receive	completed	USD	\N	497.000000	\N	1.000000	Zanzibar Resort	\N	WTX-000009	\N	\N	1781473855	1781473855
d0e86603-bb07-4e19-9bc7-c7ef508318e5	3	send	completed	KES	\N	550.000000	\N	0.000000	Local Vendor	\N	WTX-000010	\N	\N	1781387455	1781387455
a6ea38f2-ca1b-4818-bf03-bac5c1cceace	3	receive	completed	TZS	\N	603.000000	\N	0.250000	ATM Withdrawal	\N	WTX-000011	\N	\N	1781301055	1781301055
440e6b10-cdba-4937-a10c-4d591bf7ff70	3	deposit	completed	USDC	\N	656.000000	\N	0.500000	Serengeti Safari	\N	WTX-000012	\N	\N	1781214655	1781214655
46d316ed-fea5-4209-8747-e85b7c51283d	3	send	completed	USD	\N	709.000000	\N	0.750000	Zanzibar Resort	\N	WTX-000013	\N	\N	1781128255	1781128255
c54233e9-41b5-47eb-ba53-aefc4dfc33d8	3	receive	completed	KES	\N	762.000000	\N	1.000000	Local Vendor	\N	WTX-000014	\N	\N	1781041855	1781041855
230a0cf8-5078-4949-88ce-c7295ba9f58f	3	send	completed	TZS	\N	815.000000	\N	0.000000	ATM Withdrawal	\N	WTX-000015	\N	\N	1780955455	1780955455
47db7885-b206-41f4-9e79-662ded987dbf	3	receive	completed	USDC	\N	868.000000	\N	0.250000	Serengeti Safari	\N	WTX-000016	\N	\N	1780869055	1780869055
13f61b6d-0faf-4a3e-8549-cab49c4924f4	3	deposit	completed	USD	\N	21.000000	\N	0.500000	Zanzibar Resort	\N	WTX-000017	\N	\N	1780782655	1780782655
bd07f2e3-0fdc-4b51-ab7c-df99ba9eda13	3	send	completed	KES	\N	74.000000	\N	0.750000	Local Vendor	\N	WTX-000018	\N	\N	1780696255	1780696255
4a53b3ef-9eb0-44bb-8fd4-bd5226ea0e84	3	receive	completed	TZS	\N	127.000000	\N	1.000000	ATM Withdrawal	\N	WTX-000019	\N	\N	1780609855	1780609855
7402b8e9-6357-4300-beee-5aee82dc2c2d	3	send	completed	USDC	\N	180.000000	\N	0.000000	Serengeti Safari	\N	WTX-000020	\N	\N	1780523455	1780523455
95225929-1617-4a76-8cc8-378c4af6a676	3	receive	completed	USD	\N	233.000000	\N	0.250000	Zanzibar Resort	\N	WTX-000021	\N	\N	1780437055	1780437055
09794e59-729f-409a-8e7f-8df85e1fbc0d	3	deposit	completed	KES	\N	286.000000	\N	0.500000	Local Vendor	\N	WTX-000022	\N	\N	1780350655	1780350655
b9100dfc-d90f-45e5-9c84-fbccbb38cb26	3	send	completed	TZS	\N	339.000000	\N	0.750000	ATM Withdrawal	\N	WTX-000023	\N	\N	1780264255	1780264255
cb5e914a-6c8f-4546-94ff-290cf5f6b3ca	3	receive	completed	USDC	\N	392.000000	\N	1.000000	Serengeti Safari	\N	WTX-000024	\N	\N	1780177855	1780177855
7aed5b3f-8983-4ab7-8f8d-219d1cdd47e0	3	send	completed	USD	\N	445.000000	\N	0.000000	Zanzibar Resort	\N	WTX-000025	\N	\N	1780091455	1780091455
ac35aa78-16a7-41d5-87df-0f90396c54ef	3	receive	completed	KES	\N	498.000000	\N	0.250000	Local Vendor	\N	WTX-000026	\N	\N	1780005055	1780005055
39fb1698-152f-477e-aea1-e07f20e3b929	3	deposit	completed	TZS	\N	551.000000	\N	0.500000	ATM Withdrawal	\N	WTX-000027	\N	\N	1779918655	1779918655
84f9a812-b1e7-4df7-9a6a-f9339cc6fc61	3	send	completed	USDC	\N	604.000000	\N	0.750000	Serengeti Safari	\N	WTX-000028	\N	\N	1782251455	1782251455
2e7dae1c-83ad-4eae-8fbf-b1d212dcc68a	3	receive	completed	USD	\N	657.000000	\N	1.000000	Zanzibar Resort	\N	WTX-000029	\N	\N	1782165055	1782165055
f70189d6-9cae-42cd-b225-453965b166ba	3	send	completed	KES	\N	710.000000	\N	0.000000	Local Vendor	\N	WTX-000030	\N	\N	1782078655	1782078655
\.


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: tourismpay
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 73, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 1, false);


--
-- Name: bis_auto_flag_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.bis_auto_flag_config_id_seq', 104, true);


--
-- Name: bis_auto_flags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.bis_auto_flags_id_seq', 1, false);


--
-- Name: bis_directors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.bis_directors_id_seq', 1, false);


--
-- Name: bis_export_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.bis_export_schedules_id_seq', 1, false);


--
-- Name: bis_investigations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.bis_investigations_id_seq', 48, true);


--
-- Name: bis_kill_switch_activations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.bis_kill_switch_activations_id_seq', 1, false);


--
-- Name: bis_report_exports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.bis_report_exports_id_seq', 1, false);


--
-- Name: channel_connections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.channel_connections_id_seq', 1, false);


--
-- Name: establishment_score_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.establishment_score_snapshots_id_seq', 50, true);


--
-- Name: establishments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.establishments_id_seq', 19, true);


--
-- Name: exchange_rate_overrides_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.exchange_rate_overrides_id_seq', 1, false);


--
-- Name: fraud_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.fraud_alerts_id_seq', 22, true);


--
-- Name: itinerary_changelog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.itinerary_changelog_id_seq', 1, false);


--
-- Name: itinerary_collaborators_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.itinerary_collaborators_id_seq', 1, false);


--
-- Name: kyb_applications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.kyb_applications_id_seq', 7, true);


--
-- Name: kyb_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.kyb_documents_id_seq', 1, false);


--
-- Name: kyc_verification_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.kyc_verification_records_id_seq', 1, false);


--
-- Name: login_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.login_history_id_seq', 1, false);


--
-- Name: merchant_payout_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.merchant_payout_schedules_id_seq', 1, false);


--
-- Name: merchant_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.merchant_products_id_seq', 84, true);


--
-- Name: noc_alert_thresholds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.noc_alert_thresholds_id_seq', 4, true);


--
-- Name: noc_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.noc_events_id_seq', 1, false);


--
-- Name: notification_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.notification_preferences_id_seq', 1, false);


--
-- Name: ps_corridor_rate_limit_usage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.ps_corridor_rate_limit_usage_id_seq', 1, false);


--
-- Name: ps_corridor_rate_limits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.ps_corridor_rate_limits_id_seq', 1, false);


--
-- Name: ps_fraud_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.ps_fraud_rules_id_seq', 1, false);


--
-- Name: ps_kill_switch_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.ps_kill_switch_history_id_seq', 1, false);


--
-- Name: ps_kill_switch_state_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.ps_kill_switch_state_id_seq', 1, false);


--
-- Name: ps_kill_switches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.ps_kill_switches_id_seq', 1, false);


--
-- Name: ps_two_factor_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.ps_two_factor_settings_id_seq', 1, false);


--
-- Name: ps_webhook_deliveries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.ps_webhook_deliveries_id_seq', 1, false);


--
-- Name: ps_webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.ps_webhooks_id_seq', 1, false);


--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.push_subscriptions_id_seq', 1, false);


--
-- Name: qr_payment_receipts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.qr_payment_receipts_id_seq', 1, false);


--
-- Name: qr_payment_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.qr_payment_tokens_id_seq', 1, false);


--
-- Name: rate_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.rate_alerts_id_seq', 1, false);


--
-- Name: review_sentiment_cache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.review_sentiment_cache_id_seq', 1, false);


--
-- Name: review_sentiment_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.review_sentiment_history_id_seq', 1, false);


--
-- Name: role_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.role_permissions_id_seq', 1, false);


--
-- Name: service_availability_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.service_availability_id_seq', 1, false);


--
-- Name: soc_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.soc_alerts_id_seq', 14, true);


--
-- Name: staff_invites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.staff_invites_id_seq', 1, false);


--
-- Name: tourism_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.tourism_events_id_seq', 1, false);


--
-- Name: tourist_bookings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.tourist_bookings_id_seq', 1, false);


--
-- Name: tourist_budgets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.tourist_budgets_id_seq', 1, false);


--
-- Name: tourist_concierge_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.tourist_concierge_sessions_id_seq', 1, false);


--
-- Name: tourist_deal_redemptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.tourist_deal_redemptions_id_seq', 281, true);


--
-- Name: tourist_deal_wishlists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.tourist_deal_wishlists_id_seq', 1, false);


--
-- Name: tourist_deals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.tourist_deals_id_seq', 42, true);


--
-- Name: tourist_itineraries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.tourist_itineraries_id_seq', 1, false);


--
-- Name: tourist_itinerary_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.tourist_itinerary_items_id_seq', 1, false);


--
-- Name: tourist_onboarding_state_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.tourist_onboarding_state_id_seq', 1, false);


--
-- Name: tourist_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.tourist_profiles_id_seq', 1, false);


--
-- Name: tourist_reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.tourist_reviews_id_seq', 1, false);


--
-- Name: tourist_topups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.tourist_topups_id_seq', 1, false);


--
-- Name: tourist_trip_summaries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.tourist_trip_summaries_id_seq', 1, false);


--
-- Name: trusted_devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.trusted_devices_id_seq', 1, false);


--
-- Name: user_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.user_notifications_id_seq', 45, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tourismpay
--

SELECT pg_catalog.setval('public.users_id_seq', 49, true);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: tourismpay
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: biometric_enrollments biometric_enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.biometric_enrollments
    ADD CONSTRAINT biometric_enrollments_pkey PRIMARY KEY (id);


--
-- Name: bis_auto_flag_config bis_auto_flag_config_currency_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_auto_flag_config
    ADD CONSTRAINT bis_auto_flag_config_currency_unique UNIQUE (currency);


--
-- Name: bis_auto_flag_config bis_auto_flag_config_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_auto_flag_config
    ADD CONSTRAINT bis_auto_flag_config_pkey PRIMARY KEY (id);


--
-- Name: bis_auto_flags bis_auto_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_auto_flags
    ADD CONSTRAINT bis_auto_flags_pkey PRIMARY KEY (id);


--
-- Name: bis_directors bis_directors_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_directors
    ADD CONSTRAINT bis_directors_pkey PRIMARY KEY (id);


--
-- Name: bis_export_schedules bis_export_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_export_schedules
    ADD CONSTRAINT bis_export_schedules_pkey PRIMARY KEY (id);


--
-- Name: bis_export_schedules bis_export_schedules_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_export_schedules
    ADD CONSTRAINT bis_export_schedules_user_id_unique UNIQUE (user_id);


--
-- Name: bis_investigation_notes bis_investigation_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_investigation_notes
    ADD CONSTRAINT bis_investigation_notes_pkey PRIMARY KEY (id);


--
-- Name: bis_investigations bis_investigations_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_investigations
    ADD CONSTRAINT bis_investigations_pkey PRIMARY KEY (id);


--
-- Name: bis_investigations bis_investigations_reference_id_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_investigations
    ADD CONSTRAINT bis_investigations_reference_id_unique UNIQUE (reference_id);


--
-- Name: bis_kill_switch_activations bis_kill_switch_activations_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_kill_switch_activations
    ADD CONSTRAINT bis_kill_switch_activations_pkey PRIMARY KEY (id);


--
-- Name: bis_report_exports bis_report_exports_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_report_exports
    ADD CONSTRAINT bis_report_exports_pkey PRIMARY KEY (id);


--
-- Name: bis_timeline bis_timeline_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_timeline
    ADD CONSTRAINT bis_timeline_pkey PRIMARY KEY (id);


--
-- Name: carbon_offsets carbon_offsets_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.carbon_offsets
    ADD CONSTRAINT carbon_offsets_pkey PRIMARY KEY (id);


--
-- Name: channel_connections channel_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.channel_connections
    ADD CONSTRAINT channel_connections_pkey PRIMARY KEY (id);


--
-- Name: did_documents did_documents_did_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.did_documents
    ADD CONSTRAINT did_documents_did_unique UNIQUE (did);


--
-- Name: did_documents did_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.did_documents
    ADD CONSTRAINT did_documents_pkey PRIMARY KEY (id);


--
-- Name: did_documents did_documents_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.did_documents
    ADD CONSTRAINT did_documents_user_id_unique UNIQUE (user_id);


--
-- Name: establishment_score_snapshots establishment_score_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.establishment_score_snapshots
    ADD CONSTRAINT establishment_score_snapshots_pkey PRIMARY KEY (id);


--
-- Name: establishments establishments_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.establishments
    ADD CONSTRAINT establishments_pkey PRIMARY KEY (id);


--
-- Name: exchange_rate_overrides exchange_rate_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.exchange_rate_overrides
    ADD CONSTRAINT exchange_rate_overrides_pkey PRIMARY KEY (id);


--
-- Name: finance_requests finance_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.finance_requests
    ADD CONSTRAINT finance_requests_pkey PRIMARY KEY (id);


--
-- Name: fraud_alerts fraud_alerts_alert_id_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.fraud_alerts
    ADD CONSTRAINT fraud_alerts_alert_id_unique UNIQUE (alert_id);


--
-- Name: fraud_alerts fraud_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.fraud_alerts
    ADD CONSTRAINT fraud_alerts_pkey PRIMARY KEY (id);


--
-- Name: itinerary_changelog itinerary_changelog_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.itinerary_changelog
    ADD CONSTRAINT itinerary_changelog_pkey PRIMARY KEY (id);


--
-- Name: itinerary_collaborators itinerary_collaborators_invite_token_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.itinerary_collaborators
    ADD CONSTRAINT itinerary_collaborators_invite_token_unique UNIQUE (invite_token);


--
-- Name: itinerary_collaborators itinerary_collaborators_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.itinerary_collaborators
    ADD CONSTRAINT itinerary_collaborators_pkey PRIMARY KEY (id);


--
-- Name: kyb_applications kyb_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.kyb_applications
    ADD CONSTRAINT kyb_applications_pkey PRIMARY KEY (id);


--
-- Name: kyb_documents kyb_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.kyb_documents
    ADD CONSTRAINT kyb_documents_pkey PRIMARY KEY (id);


--
-- Name: kyc_verification_records kyc_verification_records_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.kyc_verification_records
    ADD CONSTRAINT kyc_verification_records_pkey PRIMARY KEY (id);


--
-- Name: ledger_accounts ledger_accounts_establishment_id_ledger_code_currency_code_key; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ledger_accounts
    ADD CONSTRAINT ledger_accounts_establishment_id_ledger_code_currency_code_key UNIQUE (establishment_id, ledger_code, currency_code);


--
-- Name: ledger_accounts ledger_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ledger_accounts
    ADD CONSTRAINT ledger_accounts_pkey PRIMARY KEY (id);


--
-- Name: ledger_accounts ledger_accounts_user_id_ledger_code_currency_code_key; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ledger_accounts
    ADD CONSTRAINT ledger_accounts_user_id_ledger_code_currency_code_key UNIQUE (user_id, ledger_code, currency_code);


--
-- Name: ledger_transfers ledger_transfers_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ledger_transfers
    ADD CONSTRAINT ledger_transfers_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: ledger_transfers ledger_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ledger_transfers
    ADD CONSTRAINT ledger_transfers_pkey PRIMARY KEY (id);


--
-- Name: login_history login_history_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT login_history_pkey PRIMARY KEY (id);


--
-- Name: loyalty_accounts loyalty_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.loyalty_accounts
    ADD CONSTRAINT loyalty_accounts_pkey PRIMARY KEY (id);


--
-- Name: loyalty_accounts loyalty_accounts_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.loyalty_accounts
    ADD CONSTRAINT loyalty_accounts_user_id_unique UNIQUE (user_id);


--
-- Name: loyalty_partners loyalty_partners_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.loyalty_partners
    ADD CONSTRAINT loyalty_partners_pkey PRIMARY KEY (id);


--
-- Name: loyalty_referrals loyalty_referrals_code_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.loyalty_referrals
    ADD CONSTRAINT loyalty_referrals_code_unique UNIQUE (code);


--
-- Name: loyalty_referrals loyalty_referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.loyalty_referrals
    ADD CONSTRAINT loyalty_referrals_pkey PRIMARY KEY (id);


--
-- Name: loyalty_rewards loyalty_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.loyalty_rewards
    ADD CONSTRAINT loyalty_rewards_pkey PRIMARY KEY (id);


--
-- Name: loyalty_transactions loyalty_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.loyalty_transactions
    ADD CONSTRAINT loyalty_transactions_pkey PRIMARY KEY (id);


--
-- Name: lp_applications lp_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.lp_applications
    ADD CONSTRAINT lp_applications_pkey PRIMARY KEY (id);


--
-- Name: lp_pool_snapshots lp_pool_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.lp_pool_snapshots
    ADD CONSTRAINT lp_pool_snapshots_pkey PRIMARY KEY (id);


--
-- Name: lp_positions lp_positions_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.lp_positions
    ADD CONSTRAINT lp_positions_pkey PRIMARY KEY (id);


--
-- Name: lp_providers lp_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.lp_providers
    ADD CONSTRAINT lp_providers_pkey PRIMARY KEY (id);


--
-- Name: lp_rebalance_events lp_rebalance_events_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.lp_rebalance_events
    ADD CONSTRAINT lp_rebalance_events_pkey PRIMARY KEY (id);


--
-- Name: lp_rewards lp_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.lp_rewards
    ADD CONSTRAINT lp_rewards_pkey PRIMARY KEY (id);


--
-- Name: lp_withdrawals lp_withdrawals_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.lp_withdrawals
    ADD CONSTRAINT lp_withdrawals_pkey PRIMARY KEY (id);


--
-- Name: merchant_payout_schedules merchant_payout_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.merchant_payout_schedules
    ADD CONSTRAINT merchant_payout_schedules_pkey PRIMARY KEY (id);


--
-- Name: merchant_products merchant_products_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.merchant_products
    ADD CONSTRAINT merchant_products_pkey PRIMARY KEY (id);


--
-- Name: mesh_transactions mesh_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.mesh_transactions
    ADD CONSTRAINT mesh_transactions_pkey PRIMARY KEY (id);


--
-- Name: noc_alert_thresholds noc_alert_thresholds_metric_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.noc_alert_thresholds
    ADD CONSTRAINT noc_alert_thresholds_metric_unique UNIQUE (metric);


--
-- Name: noc_alert_thresholds noc_alert_thresholds_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.noc_alert_thresholds
    ADD CONSTRAINT noc_alert_thresholds_pkey PRIMARY KEY (id);


--
-- Name: noc_events noc_events_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.noc_events
    ADD CONSTRAINT noc_events_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_unique UNIQUE (user_id);


--
-- Name: pin_lockout_history pin_lockout_history_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.pin_lockout_history
    ADD CONSTRAINT pin_lockout_history_pkey PRIMARY KEY (id);


--
-- Name: ps_account_recovery ps_account_recovery_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_account_recovery
    ADD CONSTRAINT ps_account_recovery_pkey PRIMARY KEY (id);


--
-- Name: ps_api_keys ps_api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_api_keys
    ADD CONSTRAINT ps_api_keys_pkey PRIMARY KEY (id);


--
-- Name: ps_corridor_rate_limit_usage ps_corridor_rate_limit_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_corridor_rate_limit_usage
    ADD CONSTRAINT ps_corridor_rate_limit_usage_pkey PRIMARY KEY (id);


--
-- Name: ps_corridor_rate_limits ps_corridor_rate_limits_corridor_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_corridor_rate_limits
    ADD CONSTRAINT ps_corridor_rate_limits_corridor_unique UNIQUE (corridor);


--
-- Name: ps_corridor_rate_limits ps_corridor_rate_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_corridor_rate_limits
    ADD CONSTRAINT ps_corridor_rate_limits_pkey PRIMARY KEY (id);


--
-- Name: ps_fraud_rules ps_fraud_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_fraud_rules
    ADD CONSTRAINT ps_fraud_rules_pkey PRIMARY KEY (id);


--
-- Name: ps_fraud_rules ps_fraud_rules_rule_id_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_fraud_rules
    ADD CONSTRAINT ps_fraud_rules_rule_id_unique UNIQUE (rule_id);


--
-- Name: ps_kill_switch_history ps_kill_switch_history_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_kill_switch_history
    ADD CONSTRAINT ps_kill_switch_history_pkey PRIMARY KEY (id);


--
-- Name: ps_kill_switch_state ps_kill_switch_state_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_kill_switch_state
    ADD CONSTRAINT ps_kill_switch_state_pkey PRIMARY KEY (id);


--
-- Name: ps_kill_switches ps_kill_switches_corridor_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_kill_switches
    ADD CONSTRAINT ps_kill_switches_corridor_unique UNIQUE (corridor);


--
-- Name: ps_kill_switches ps_kill_switches_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_kill_switches
    ADD CONSTRAINT ps_kill_switches_pkey PRIMARY KEY (id);


--
-- Name: ps_ledger_entries ps_ledger_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_ledger_entries
    ADD CONSTRAINT ps_ledger_entries_pkey PRIMARY KEY (id);


--
-- Name: ps_notification_channels ps_notification_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_notification_channels
    ADD CONSTRAINT ps_notification_channels_pkey PRIMARY KEY (id);


--
-- Name: ps_participants ps_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_participants
    ADD CONSTRAINT ps_participants_pkey PRIMARY KEY (id);


--
-- Name: ps_reminder_emails ps_reminder_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_reminder_emails
    ADD CONSTRAINT ps_reminder_emails_pkey PRIMARY KEY (id);


--
-- Name: ps_settlements ps_settlements_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_settlements
    ADD CONSTRAINT ps_settlements_pkey PRIMARY KEY (id);


--
-- Name: ps_two_factor_settings ps_two_factor_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_two_factor_settings
    ADD CONSTRAINT ps_two_factor_settings_pkey PRIMARY KEY (id);


--
-- Name: ps_two_factor_settings ps_two_factor_settings_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_two_factor_settings
    ADD CONSTRAINT ps_two_factor_settings_user_id_unique UNIQUE (user_id);


--
-- Name: ps_webhook_deliveries ps_webhook_deliveries_delivery_id_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_webhook_deliveries
    ADD CONSTRAINT ps_webhook_deliveries_delivery_id_unique UNIQUE (delivery_id);


--
-- Name: ps_webhook_deliveries ps_webhook_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_webhook_deliveries
    ADD CONSTRAINT ps_webhook_deliveries_pkey PRIMARY KEY (id);


--
-- Name: ps_webhooks ps_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_webhooks
    ADD CONSTRAINT ps_webhooks_pkey PRIMARY KEY (id);


--
-- Name: ps_webhooks ps_webhooks_webhook_id_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_webhooks
    ADD CONSTRAINT ps_webhooks_webhook_id_unique UNIQUE (webhook_id);


--
-- Name: push_subscriptions push_subscriptions_endpoint_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_endpoint_unique UNIQUE (endpoint);


--
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: qr_payment_receipts qr_payment_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.qr_payment_receipts
    ADD CONSTRAINT qr_payment_receipts_pkey PRIMARY KEY (id);


--
-- Name: qr_payment_receipts qr_payment_receipts_token_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.qr_payment_receipts
    ADD CONSTRAINT qr_payment_receipts_token_unique UNIQUE (token);


--
-- Name: qr_payment_tokens qr_payment_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.qr_payment_tokens
    ADD CONSTRAINT qr_payment_tokens_pkey PRIMARY KEY (id);


--
-- Name: qr_payment_tokens qr_payment_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.qr_payment_tokens
    ADD CONSTRAINT qr_payment_tokens_token_unique UNIQUE (token);


--
-- Name: rate_alerts rate_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.rate_alerts
    ADD CONSTRAINT rate_alerts_pkey PRIMARY KEY (id);


--
-- Name: remittances remittances_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.remittances
    ADD CONSTRAINT remittances_pkey PRIMARY KEY (id);


--
-- Name: review_sentiment_cache review_sentiment_cache_establishment_id_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.review_sentiment_cache
    ADD CONSTRAINT review_sentiment_cache_establishment_id_unique UNIQUE (establishment_id);


--
-- Name: review_sentiment_cache review_sentiment_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.review_sentiment_cache
    ADD CONSTRAINT review_sentiment_cache_pkey PRIMARY KEY (id);


--
-- Name: review_sentiment_history review_sentiment_history_establishment_id_snapshot_date_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.review_sentiment_history
    ADD CONSTRAINT review_sentiment_history_establishment_id_snapshot_date_unique UNIQUE (establishment_id, snapshot_date);


--
-- Name: review_sentiment_history review_sentiment_history_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.review_sentiment_history
    ADD CONSTRAINT review_sentiment_history_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: scheduled_payments scheduled_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.scheduled_payments
    ADD CONSTRAINT scheduled_payments_pkey PRIMARY KEY (id);


--
-- Name: service_availability service_availability_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.service_availability
    ADD CONSTRAINT service_availability_pkey PRIMARY KEY (id);


--
-- Name: service_health_alerts service_health_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.service_health_alerts
    ADD CONSTRAINT service_health_alerts_pkey PRIMARY KEY (id);


--
-- Name: service_health_alerts service_health_alerts_service_key_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.service_health_alerts
    ADD CONSTRAINT service_health_alerts_service_key_unique UNIQUE (service_key);


--
-- Name: service_health_history service_health_history_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.service_health_history
    ADD CONSTRAINT service_health_history_pkey PRIMARY KEY (id);


--
-- Name: smart_contract_deployments smart_contract_deployments_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.smart_contract_deployments
    ADD CONSTRAINT smart_contract_deployments_pkey PRIMARY KEY (id);


--
-- Name: smart_contract_events smart_contract_events_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.smart_contract_events
    ADD CONSTRAINT smart_contract_events_pkey PRIMARY KEY (id);


--
-- Name: soc_alerts soc_alerts_alert_id_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.soc_alerts
    ADD CONSTRAINT soc_alerts_alert_id_unique UNIQUE (alert_id);


--
-- Name: soc_alerts soc_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.soc_alerts
    ADD CONSTRAINT soc_alerts_pkey PRIMARY KEY (id);


--
-- Name: stablecoin_limit_orders stablecoin_limit_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.stablecoin_limit_orders
    ADD CONSTRAINT stablecoin_limit_orders_pkey PRIMARY KEY (id);


--
-- Name: stablecoin_offramp_requests stablecoin_offramp_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.stablecoin_offramp_requests
    ADD CONSTRAINT stablecoin_offramp_requests_pkey PRIMARY KEY (id);


--
-- Name: stablecoin_onramp_orders stablecoin_onramp_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.stablecoin_onramp_orders
    ADD CONSTRAINT stablecoin_onramp_orders_pkey PRIMARY KEY (id);


--
-- Name: stablecoin_yield_positions stablecoin_yield_positions_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.stablecoin_yield_positions
    ADD CONSTRAINT stablecoin_yield_positions_pkey PRIMARY KEY (id);


--
-- Name: staff_invites staff_invites_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.staff_invites
    ADD CONSTRAINT staff_invites_pkey PRIMARY KEY (id);


--
-- Name: staff_invites staff_invites_token_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.staff_invites
    ADD CONSTRAINT staff_invites_token_unique UNIQUE (token);


--
-- Name: tip_configs tip_configs_establishment_id_key; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tip_configs
    ADD CONSTRAINT tip_configs_establishment_id_key UNIQUE (establishment_id);


--
-- Name: tip_configs tip_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tip_configs
    ADD CONSTRAINT tip_configs_pkey PRIMARY KEY (id);


--
-- Name: tourism_events tourism_events_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourism_events
    ADD CONSTRAINT tourism_events_pkey PRIMARY KEY (id);


--
-- Name: tourist_bookings tourist_bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_bookings
    ADD CONSTRAINT tourist_bookings_pkey PRIMARY KEY (id);


--
-- Name: tourist_budgets tourist_budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_budgets
    ADD CONSTRAINT tourist_budgets_pkey PRIMARY KEY (id);


--
-- Name: tourist_budgets tourist_budgets_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_budgets
    ADD CONSTRAINT tourist_budgets_user_id_unique UNIQUE (user_id);


--
-- Name: tourist_concierge_sessions tourist_concierge_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_concierge_sessions
    ADD CONSTRAINT tourist_concierge_sessions_pkey PRIMARY KEY (id);


--
-- Name: tourist_deal_redemptions tourist_deal_redemptions_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_deal_redemptions
    ADD CONSTRAINT tourist_deal_redemptions_pkey PRIMARY KEY (id);


--
-- Name: tourist_deal_redemptions tourist_deal_redemptions_redemption_code_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_deal_redemptions
    ADD CONSTRAINT tourist_deal_redemptions_redemption_code_unique UNIQUE (redemption_code);


--
-- Name: tourist_deal_wishlists tourist_deal_wishlists_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_deal_wishlists
    ADD CONSTRAINT tourist_deal_wishlists_pkey PRIMARY KEY (id);


--
-- Name: tourist_deals tourist_deals_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_deals
    ADD CONSTRAINT tourist_deals_pkey PRIMARY KEY (id);


--
-- Name: tourist_itineraries tourist_itineraries_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_itineraries
    ADD CONSTRAINT tourist_itineraries_pkey PRIMARY KEY (id);


--
-- Name: tourist_itineraries tourist_itineraries_share_token_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_itineraries
    ADD CONSTRAINT tourist_itineraries_share_token_unique UNIQUE (share_token);


--
-- Name: tourist_itinerary_items tourist_itinerary_items_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_itinerary_items
    ADD CONSTRAINT tourist_itinerary_items_pkey PRIMARY KEY (id);


--
-- Name: tourist_onboarding_state tourist_onboarding_state_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_onboarding_state
    ADD CONSTRAINT tourist_onboarding_state_pkey PRIMARY KEY (id);


--
-- Name: tourist_onboarding_state tourist_onboarding_state_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_onboarding_state
    ADD CONSTRAINT tourist_onboarding_state_user_id_unique UNIQUE (user_id);


--
-- Name: tourist_profiles tourist_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_profiles
    ADD CONSTRAINT tourist_profiles_pkey PRIMARY KEY (id);


--
-- Name: tourist_reviews tourist_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_reviews
    ADD CONSTRAINT tourist_reviews_pkey PRIMARY KEY (id);


--
-- Name: tourist_topups tourist_topups_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_topups
    ADD CONSTRAINT tourist_topups_pkey PRIMARY KEY (id);


--
-- Name: tourist_trip_summaries tourist_trip_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_trip_summaries
    ADD CONSTRAINT tourist_trip_summaries_pkey PRIMARY KEY (id);


--
-- Name: trusted_devices trusted_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.trusted_devices
    ADD CONSTRAINT trusted_devices_pkey PRIMARY KEY (id);


--
-- Name: user_notifications user_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.user_notifications
    ADD CONSTRAINT user_notifications_pkey PRIMARY KEY (id);


--
-- Name: users users_open_id_unique; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_open_id_unique UNIQUE (open_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: verifiable_credentials verifiable_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.verifiable_credentials
    ADD CONSTRAINT verifiable_credentials_pkey PRIMARY KEY (id);


--
-- Name: wallet_balance_alerts wallet_balance_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.wallet_balance_alerts
    ADD CONSTRAINT wallet_balance_alerts_pkey PRIMARY KEY (id);


--
-- Name: wallet_balances wallet_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.wallet_balances
    ADD CONSTRAINT wallet_balances_pkey PRIMARY KEY (id);


--
-- Name: wallet_recurring_payments wallet_recurring_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.wallet_recurring_payments
    ADD CONSTRAINT wallet_recurring_payments_pkey PRIMARY KEY (id);


--
-- Name: wallet_spending_limits wallet_spending_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.wallet_spending_limits
    ADD CONSTRAINT wallet_spending_limits_pkey PRIMARY KEY (id);


--
-- Name: wallet_transactions wallet_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_pkey PRIMARY KEY (id);


--
-- Name: audit_action_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX audit_action_idx ON public.audit_logs USING btree (action);


--
-- Name: audit_actor_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX audit_actor_idx ON public.audit_logs USING btree (actor_id);


--
-- Name: audit_created_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX audit_created_idx ON public.audit_logs USING btree (created_at);


--
-- Name: audit_entity_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX audit_entity_idx ON public.audit_logs USING btree (entity_type, entity_id);


--
-- Name: bis_auto_flags_created_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX bis_auto_flags_created_idx ON public.bis_auto_flags USING btree (created_at);


--
-- Name: bis_auto_flags_tx_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX bis_auto_flags_tx_idx ON public.bis_auto_flags USING btree (wallet_tx_id);


--
-- Name: bis_auto_flags_user_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX bis_auto_flags_user_idx ON public.bis_auto_flags USING btree (user_id);


--
-- Name: bis_directors_entity_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX bis_directors_entity_idx ON public.bis_directors USING btree (entity_investigation_id);


--
-- Name: bis_est_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX bis_est_idx ON public.bis_investigations USING btree (establishment_id);


--
-- Name: bis_export_inv_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX bis_export_inv_idx ON public.bis_report_exports USING btree (investigation_id);


--
-- Name: bis_export_sched_enabled_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX bis_export_sched_enabled_idx ON public.bis_export_schedules USING btree (enabled);


--
-- Name: bis_export_sched_next_run_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX bis_export_sched_next_run_idx ON public.bis_export_schedules USING btree (next_run_at);


--
-- Name: bis_export_sched_user_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX bis_export_sched_user_idx ON public.bis_export_schedules USING btree (user_id);


--
-- Name: bis_ks_act_corridor_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX bis_ks_act_corridor_idx ON public.bis_kill_switch_activations USING btree (corridor);


--
-- Name: bis_ks_act_created_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX bis_ks_act_created_idx ON public.bis_kill_switch_activations USING btree (created_at);


--
-- Name: bis_ks_act_inv_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX bis_ks_act_inv_idx ON public.bis_kill_switch_activations USING btree (bis_investigation_id);


--
-- Name: bis_notes_author_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX bis_notes_author_idx ON public.bis_investigation_notes USING btree (author_id);


--
-- Name: bis_notes_created_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX bis_notes_created_idx ON public.bis_investigation_notes USING btree (created_at);


--
-- Name: bis_notes_investigation_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX bis_notes_investigation_idx ON public.bis_investigation_notes USING btree (investigation_id);


--
-- Name: bis_ref_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX bis_ref_idx ON public.bis_investigations USING btree (reference_id);


--
-- Name: bis_risk_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX bis_risk_idx ON public.bis_investigations USING btree (risk_level);


--
-- Name: bis_status_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX bis_status_idx ON public.bis_investigations USING btree (status);


--
-- Name: channel_conn_est_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX channel_conn_est_idx ON public.channel_connections USING btree (establishment_id);


--
-- Name: channel_conn_name_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX channel_conn_name_idx ON public.channel_connections USING btree (channel_name);


--
-- Name: ero_active_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ero_active_idx ON public.exchange_rate_overrides USING btree (is_active);


--
-- Name: ero_currencies_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ero_currencies_idx ON public.exchange_rate_overrides USING btree (base_currency, target_currency);


--
-- Name: est_country_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX est_country_idx ON public.establishments USING btree (country);


--
-- Name: est_kyb_status_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX est_kyb_status_idx ON public.establishments USING btree (kyb_status);


--
-- Name: est_snapshot_date_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX est_snapshot_date_idx ON public.establishment_score_snapshots USING btree (snapshot_date);


--
-- Name: est_snapshot_est_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX est_snapshot_est_idx ON public.establishment_score_snapshots USING btree (establishment_id);


--
-- Name: est_snapshot_unique; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE UNIQUE INDEX est_snapshot_unique ON public.establishment_score_snapshots USING btree (establishment_id, snapshot_date);


--
-- Name: event_category_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX event_category_idx ON public.tourism_events USING btree (category);


--
-- Name: event_country_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX event_country_idx ON public.tourism_events USING btree (country);


--
-- Name: fraud_created_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX fraud_created_idx ON public.fraud_alerts USING btree (created_at);


--
-- Name: fraud_severity_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX fraud_severity_idx ON public.fraud_alerts USING btree (severity);


--
-- Name: fraud_status_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX fraud_status_idx ON public.fraud_alerts USING btree (status);


--
-- Name: idx_ledger_accounts_est; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX idx_ledger_accounts_est ON public.ledger_accounts USING btree (establishment_id);


--
-- Name: idx_ledger_accounts_user; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX idx_ledger_accounts_user ON public.ledger_accounts USING btree (user_id);


--
-- Name: idx_ledger_transfers_credit; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX idx_ledger_transfers_credit ON public.ledger_transfers USING btree (credit_account_id);


--
-- Name: idx_ledger_transfers_debit; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX idx_ledger_transfers_debit ON public.ledger_transfers USING btree (debit_account_id);


--
-- Name: idx_ledger_transfers_status; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX idx_ledger_transfers_status ON public.ledger_transfers USING btree (status);


--
-- Name: kyb_doc_app_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX kyb_doc_app_idx ON public.kyb_documents USING btree (application_id);


--
-- Name: kyb_doc_est_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX kyb_doc_est_idx ON public.kyb_documents USING btree (establishment_id);


--
-- Name: kyb_doc_status_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX kyb_doc_status_idx ON public.kyb_documents USING btree (status);


--
-- Name: kyb_doc_type_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX kyb_doc_type_idx ON public.kyb_documents USING btree (document_type);


--
-- Name: kyb_est_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX kyb_est_idx ON public.kyb_applications USING btree (establishment_id);


--
-- Name: kyb_status_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX kyb_status_idx ON public.kyb_applications USING btree (status);


--
-- Name: kyc_doc_hash_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX kyc_doc_hash_idx ON public.kyc_verification_records USING btree (document_number_hash);


--
-- Name: kyc_status_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX kyc_status_idx ON public.kyc_verification_records USING btree (status);


--
-- Name: kyc_user_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX kyc_user_idx ON public.kyc_verification_records USING btree (user_id);


--
-- Name: limit_order_status_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX limit_order_status_idx ON public.stablecoin_limit_orders USING btree (status);


--
-- Name: limit_order_user_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX limit_order_user_idx ON public.stablecoin_limit_orders USING btree (user_id);


--
-- Name: loyalty_partners_active_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX loyalty_partners_active_idx ON public.loyalty_partners USING btree (is_active);


--
-- Name: loyalty_partners_category_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX loyalty_partners_category_idx ON public.loyalty_partners USING btree (category);


--
-- Name: loyalty_referrals_code_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX loyalty_referrals_code_idx ON public.loyalty_referrals USING btree (code);


--
-- Name: loyalty_referrals_referee_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX loyalty_referrals_referee_idx ON public.loyalty_referrals USING btree (referee_id);


--
-- Name: loyalty_referrals_referrer_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX loyalty_referrals_referrer_idx ON public.loyalty_referrals USING btree (referrer_id);


--
-- Name: lp_position_lp_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX lp_position_lp_idx ON public.lp_positions USING btree (lp_id);


--
-- Name: lp_position_pool_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX lp_position_pool_idx ON public.lp_positions USING btree (pool_id);


--
-- Name: mp_available_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX mp_available_idx ON public.merchant_products USING btree (available);


--
-- Name: mp_category_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX mp_category_idx ON public.merchant_products USING btree (category);


--
-- Name: mp_est_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX mp_est_idx ON public.merchant_products USING btree (establishment_id);


--
-- Name: noc_events_created_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX noc_events_created_idx ON public.noc_events USING btree (created_at);


--
-- Name: noc_events_severity_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX noc_events_severity_idx ON public.noc_events USING btree (severity);


--
-- Name: noc_events_type_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX noc_events_type_idx ON public.noc_events USING btree (type);


--
-- Name: noc_thresholds_metric_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX noc_thresholds_metric_idx ON public.noc_alert_thresholds USING btree (metric);


--
-- Name: notif_created_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX notif_created_idx ON public.user_notifications USING btree (created_at);


--
-- Name: notif_pref_user_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX notif_pref_user_idx ON public.notification_preferences USING btree (user_id);


--
-- Name: notif_read_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX notif_read_idx ON public.user_notifications USING btree (is_read);


--
-- Name: notif_user_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX notif_user_idx ON public.user_notifications USING btree (user_id);


--
-- Name: offramp_created_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX offramp_created_idx ON public.stablecoin_offramp_requests USING btree (created_at);


--
-- Name: offramp_rail_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX offramp_rail_idx ON public.stablecoin_offramp_requests USING btree (payout_rail);


--
-- Name: offramp_status_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX offramp_status_idx ON public.stablecoin_offramp_requests USING btree (status);


--
-- Name: offramp_user_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX offramp_user_idx ON public.stablecoin_offramp_requests USING btree (user_id);


--
-- Name: onramp_created_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX onramp_created_idx ON public.stablecoin_onramp_orders USING btree (created_at);


--
-- Name: onramp_rail_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX onramp_rail_idx ON public.stablecoin_onramp_orders USING btree (payment_rail);


--
-- Name: onramp_status_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX onramp_status_idx ON public.stablecoin_onramp_orders USING btree (status);


--
-- Name: onramp_user_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX onramp_user_idx ON public.stablecoin_onramp_orders USING btree (user_id);


--
-- Name: ps_corridor_rl_active_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_corridor_rl_active_idx ON public.ps_corridor_rate_limits USING btree (is_active);


--
-- Name: ps_corridor_rl_corridor_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_corridor_rl_corridor_idx ON public.ps_corridor_rate_limits USING btree (corridor);


--
-- Name: ps_corridor_rl_usage_corridor_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_corridor_rl_usage_corridor_idx ON public.ps_corridor_rate_limit_usage USING btree (corridor);


--
-- Name: ps_corridor_rl_usage_day_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_corridor_rl_usage_day_idx ON public.ps_corridor_rate_limit_usage USING btree (day_window_start);


--
-- Name: ps_corridor_rl_usage_window_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_corridor_rl_usage_window_idx ON public.ps_corridor_rate_limit_usage USING btree (window_start);


--
-- Name: ps_fraud_rules_active_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_fraud_rules_active_idx ON public.ps_fraud_rules USING btree (is_active);


--
-- Name: ps_fraud_rules_severity_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_fraud_rules_severity_idx ON public.ps_fraud_rules USING btree (severity);


--
-- Name: ps_fraud_rules_type_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_fraud_rules_type_idx ON public.ps_fraud_rules USING btree (rule_type);


--
-- Name: ps_kill_switch_history_corridor_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_kill_switch_history_corridor_idx ON public.ps_kill_switch_history USING btree (corridor);


--
-- Name: ps_kill_switch_history_created_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_kill_switch_history_created_idx ON public.ps_kill_switch_history USING btree (created_at);


--
-- Name: ps_kill_switches_active_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_kill_switches_active_idx ON public.ps_kill_switches USING btree (is_active);


--
-- Name: ps_kill_switches_corridor_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_kill_switches_corridor_idx ON public.ps_kill_switches USING btree (corridor);


--
-- Name: ps_ledger_account_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_ledger_account_idx ON public.ps_ledger_entries USING btree (account_id);


--
-- Name: ps_ledger_created_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_ledger_created_idx ON public.ps_ledger_entries USING btree (created_at);


--
-- Name: ps_ledger_participant_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_ledger_participant_idx ON public.ps_ledger_entries USING btree (participant_id);


--
-- Name: ps_ledger_transfer_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_ledger_transfer_idx ON public.ps_ledger_entries USING btree (transfer_id);


--
-- Name: ps_participants_country_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_participants_country_idx ON public.ps_participants USING btree (country);


--
-- Name: ps_participants_status_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_participants_status_idx ON public.ps_participants USING btree (status);


--
-- Name: ps_settlements_batch_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_settlements_batch_idx ON public.ps_settlements USING btree (batch_id);


--
-- Name: ps_settlements_created_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_settlements_created_idx ON public.ps_settlements USING btree (created_at);


--
-- Name: ps_settlements_participant_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_settlements_participant_idx ON public.ps_settlements USING btree (participant_id);


--
-- Name: ps_settlements_status_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_settlements_status_idx ON public.ps_settlements USING btree (status);


--
-- Name: ps_webhook_deliveries_created_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_webhook_deliveries_created_idx ON public.ps_webhook_deliveries USING btree (created_at);


--
-- Name: ps_webhook_deliveries_event_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_webhook_deliveries_event_idx ON public.ps_webhook_deliveries USING btree (event);


--
-- Name: ps_webhook_deliveries_retry_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_webhook_deliveries_retry_idx ON public.ps_webhook_deliveries USING btree (next_retry_at);


--
-- Name: ps_webhook_deliveries_status_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_webhook_deliveries_status_idx ON public.ps_webhook_deliveries USING btree (status);


--
-- Name: ps_webhook_deliveries_webhook_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_webhook_deliveries_webhook_idx ON public.ps_webhook_deliveries USING btree (webhook_id);


--
-- Name: ps_webhooks_active_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_webhooks_active_idx ON public.ps_webhooks USING btree (is_active);


--
-- Name: ps_webhooks_created_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_webhooks_created_idx ON public.ps_webhooks USING btree (created_at);


--
-- Name: ps_webhooks_participant_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX ps_webhooks_participant_idx ON public.ps_webhooks USING btree (participant_id);


--
-- Name: qpr_est_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX qpr_est_idx ON public.qr_payment_receipts USING btree (establishment_id);


--
-- Name: qpr_token_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX qpr_token_idx ON public.qr_payment_receipts USING btree (token);


--
-- Name: qpr_tourist_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX qpr_tourist_idx ON public.qr_payment_receipts USING btree (tourist_user_id);


--
-- Name: remittances_created_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX remittances_created_idx ON public.remittances USING btree (created_at);


--
-- Name: remittances_status_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX remittances_status_idx ON public.remittances USING btree (status);


--
-- Name: remittances_user_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX remittances_user_idx ON public.remittances USING btree (user_id);


--
-- Name: sav_date_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX sav_date_idx ON public.service_availability USING btree (date);


--
-- Name: sav_est_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX sav_est_idx ON public.service_availability USING btree (establishment_id);


--
-- Name: sav_product_date_unique; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE UNIQUE INDEX sav_product_date_unique ON public.service_availability USING btree (product_id, date);


--
-- Name: sav_product_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX sav_product_idx ON public.service_availability USING btree (product_id);


--
-- Name: sce_contract_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX sce_contract_idx ON public.smart_contract_events USING btree (contract_name);


--
-- Name: sce_created_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX sce_created_idx ON public.smart_contract_events USING btree (created_at);


--
-- Name: sce_event_type_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX sce_event_type_idx ON public.smart_contract_events USING btree (event_type);


--
-- Name: sched_pay_next_run_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX sched_pay_next_run_idx ON public.scheduled_payments USING btree (next_run_at);


--
-- Name: sched_pay_status_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX sched_pay_status_idx ON public.scheduled_payments USING btree (status);


--
-- Name: sched_pay_user_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX sched_pay_user_idx ON public.scheduled_payments USING btree (user_id);


--
-- Name: si_email_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX si_email_idx ON public.staff_invites USING btree (email);


--
-- Name: si_est_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX si_est_idx ON public.staff_invites USING btree (establishment_id);


--
-- Name: si_status_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX si_status_idx ON public.staff_invites USING btree (status);


--
-- Name: si_token_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX si_token_idx ON public.staff_invites USING btree (token);


--
-- Name: soc_created_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX soc_created_idx ON public.soc_alerts USING btree (created_at);


--
-- Name: soc_severity_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX soc_severity_idx ON public.soc_alerts USING btree (severity);


--
-- Name: soc_status_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX soc_status_idx ON public.soc_alerts USING btree (status);


--
-- Name: soc_type_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX soc_type_idx ON public.soc_alerts USING btree (type);


--
-- Name: wallet_rec_pay_next_run_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX wallet_rec_pay_next_run_idx ON public.wallet_recurring_payments USING btree (next_run_at);


--
-- Name: wallet_rec_pay_status_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX wallet_rec_pay_status_idx ON public.wallet_recurring_payments USING btree (status);


--
-- Name: wallet_rec_pay_user_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX wallet_rec_pay_user_idx ON public.wallet_recurring_payments USING btree (user_id);


--
-- Name: yield_status_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX yield_status_idx ON public.stablecoin_yield_positions USING btree (status);


--
-- Name: yield_user_idx; Type: INDEX; Schema: public; Owner: tourismpay
--

CREATE INDEX yield_user_idx ON public.stablecoin_yield_positions USING btree (user_id);


--
-- Name: audit_logs audit_logs_actor_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_actor_id_users_id_fk FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: bis_directors bis_directors_entity_investigation_id_bis_investigations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_directors
    ADD CONSTRAINT bis_directors_entity_investigation_id_bis_investigations_id_fk FOREIGN KEY (entity_investigation_id) REFERENCES public.bis_investigations(id) ON DELETE CASCADE;


--
-- Name: bis_directors bis_directors_linked_investigation_id_bis_investigations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_directors
    ADD CONSTRAINT bis_directors_linked_investigation_id_bis_investigations_id_fk FOREIGN KEY (linked_investigation_id) REFERENCES public.bis_investigations(id) ON DELETE SET NULL;


--
-- Name: bis_export_schedules bis_export_schedules_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_export_schedules
    ADD CONSTRAINT bis_export_schedules_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: bis_investigations bis_investigations_assigned_to_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_investigations
    ADD CONSTRAINT bis_investigations_assigned_to_id_users_id_fk FOREIGN KEY (assigned_to_id) REFERENCES public.users(id);


--
-- Name: bis_investigations bis_investigations_establishment_id_establishments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_investigations
    ADD CONSTRAINT bis_investigations_establishment_id_establishments_id_fk FOREIGN KEY (establishment_id) REFERENCES public.establishments(id);


--
-- Name: bis_investigations bis_investigations_requested_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_investigations
    ADD CONSTRAINT bis_investigations_requested_by_users_id_fk FOREIGN KEY (requested_by) REFERENCES public.users(id);


--
-- Name: bis_report_exports bis_report_exports_generated_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_report_exports
    ADD CONSTRAINT bis_report_exports_generated_by_users_id_fk FOREIGN KEY (generated_by) REFERENCES public.users(id);


--
-- Name: bis_report_exports bis_report_exports_investigation_id_bis_investigations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_report_exports
    ADD CONSTRAINT bis_report_exports_investigation_id_bis_investigations_id_fk FOREIGN KEY (investigation_id) REFERENCES public.bis_investigations(id);


--
-- Name: bis_timeline bis_timeline_investigation_id_bis_investigations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.bis_timeline
    ADD CONSTRAINT bis_timeline_investigation_id_bis_investigations_id_fk FOREIGN KEY (investigation_id) REFERENCES public.bis_investigations(id) ON DELETE CASCADE;


--
-- Name: channel_connections channel_connections_establishment_id_establishments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.channel_connections
    ADD CONSTRAINT channel_connections_establishment_id_establishments_id_fk FOREIGN KEY (establishment_id) REFERENCES public.establishments(id);


--
-- Name: establishment_score_snapshots establishment_score_snapshots_establishment_id_establishments_i; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.establishment_score_snapshots
    ADD CONSTRAINT establishment_score_snapshots_establishment_id_establishments_i FOREIGN KEY (establishment_id) REFERENCES public.establishments(id) ON DELETE CASCADE;


--
-- Name: establishments establishments_owner_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.establishments
    ADD CONSTRAINT establishments_owner_id_users_id_fk FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: exchange_rate_overrides exchange_rate_overrides_created_by_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.exchange_rate_overrides
    ADD CONSTRAINT exchange_rate_overrides_created_by_user_id_users_id_fk FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: fraud_alerts fraud_alerts_establishment_id_establishments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.fraud_alerts
    ADD CONSTRAINT fraud_alerts_establishment_id_establishments_id_fk FOREIGN KEY (establishment_id) REFERENCES public.establishments(id);


--
-- Name: fraud_alerts fraud_alerts_resolved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.fraud_alerts
    ADD CONSTRAINT fraud_alerts_resolved_by_users_id_fk FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: itinerary_changelog itinerary_changelog_itinerary_id_tourist_itineraries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.itinerary_changelog
    ADD CONSTRAINT itinerary_changelog_itinerary_id_tourist_itineraries_id_fk FOREIGN KEY (itinerary_id) REFERENCES public.tourist_itineraries(id) ON DELETE CASCADE;


--
-- Name: itinerary_changelog itinerary_changelog_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.itinerary_changelog
    ADD CONSTRAINT itinerary_changelog_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: itinerary_collaborators itinerary_collaborators_itinerary_id_tourist_itineraries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.itinerary_collaborators
    ADD CONSTRAINT itinerary_collaborators_itinerary_id_tourist_itineraries_id_fk FOREIGN KEY (itinerary_id) REFERENCES public.tourist_itineraries(id) ON DELETE CASCADE;


--
-- Name: itinerary_collaborators itinerary_collaborators_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.itinerary_collaborators
    ADD CONSTRAINT itinerary_collaborators_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: kyb_applications kyb_applications_establishment_id_establishments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.kyb_applications
    ADD CONSTRAINT kyb_applications_establishment_id_establishments_id_fk FOREIGN KEY (establishment_id) REFERENCES public.establishments(id);


--
-- Name: kyb_applications kyb_applications_reviewed_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.kyb_applications
    ADD CONSTRAINT kyb_applications_reviewed_by_users_id_fk FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: kyb_applications kyb_applications_submitted_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.kyb_applications
    ADD CONSTRAINT kyb_applications_submitted_by_users_id_fk FOREIGN KEY (submitted_by) REFERENCES public.users(id);


--
-- Name: kyb_documents kyb_documents_application_id_kyb_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.kyb_documents
    ADD CONSTRAINT kyb_documents_application_id_kyb_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.kyb_applications(id);


--
-- Name: kyb_documents kyb_documents_establishment_id_establishments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.kyb_documents
    ADD CONSTRAINT kyb_documents_establishment_id_establishments_id_fk FOREIGN KEY (establishment_id) REFERENCES public.establishments(id);


--
-- Name: kyb_documents kyb_documents_reviewed_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.kyb_documents
    ADD CONSTRAINT kyb_documents_reviewed_by_users_id_fk FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: kyb_documents kyb_documents_uploaded_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.kyb_documents
    ADD CONSTRAINT kyb_documents_uploaded_by_users_id_fk FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: ledger_accounts ledger_accounts_establishment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ledger_accounts
    ADD CONSTRAINT ledger_accounts_establishment_id_fkey FOREIGN KEY (establishment_id) REFERENCES public.establishments(id);


--
-- Name: ledger_accounts ledger_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ledger_accounts
    ADD CONSTRAINT ledger_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: ledger_transfers ledger_transfers_credit_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ledger_transfers
    ADD CONSTRAINT ledger_transfers_credit_account_id_fkey FOREIGN KEY (credit_account_id) REFERENCES public.ledger_accounts(id);


--
-- Name: ledger_transfers ledger_transfers_debit_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ledger_transfers
    ADD CONSTRAINT ledger_transfers_debit_account_id_fkey FOREIGN KEY (debit_account_id) REFERENCES public.ledger_accounts(id);


--
-- Name: ledger_transfers ledger_transfers_pending_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ledger_transfers
    ADD CONSTRAINT ledger_transfers_pending_id_fkey FOREIGN KEY (pending_id) REFERENCES public.ledger_transfers(id);


--
-- Name: merchant_payout_schedules merchant_payout_schedules_merchant_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.merchant_payout_schedules
    ADD CONSTRAINT merchant_payout_schedules_merchant_id_users_id_fk FOREIGN KEY (merchant_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: merchant_products merchant_products_establishment_id_establishments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.merchant_products
    ADD CONSTRAINT merchant_products_establishment_id_establishments_id_fk FOREIGN KEY (establishment_id) REFERENCES public.establishments(id) ON DELETE CASCADE;


--
-- Name: notification_preferences notification_preferences_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: ps_fraud_rules ps_fraud_rules_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.ps_fraud_rules
    ADD CONSTRAINT ps_fraud_rules_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: push_subscriptions push_subscriptions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: qr_payment_receipts qr_payment_receipts_establishment_id_establishments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.qr_payment_receipts
    ADD CONSTRAINT qr_payment_receipts_establishment_id_establishments_id_fk FOREIGN KEY (establishment_id) REFERENCES public.establishments(id) ON DELETE SET NULL;


--
-- Name: qr_payment_receipts qr_payment_receipts_tourist_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.qr_payment_receipts
    ADD CONSTRAINT qr_payment_receipts_tourist_user_id_users_id_fk FOREIGN KEY (tourist_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: qr_payment_tokens qr_payment_tokens_establishment_id_establishments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.qr_payment_tokens
    ADD CONSTRAINT qr_payment_tokens_establishment_id_establishments_id_fk FOREIGN KEY (establishment_id) REFERENCES public.establishments(id) ON DELETE CASCADE;


--
-- Name: review_sentiment_cache review_sentiment_cache_establishment_id_establishments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.review_sentiment_cache
    ADD CONSTRAINT review_sentiment_cache_establishment_id_establishments_id_fk FOREIGN KEY (establishment_id) REFERENCES public.establishments(id) ON DELETE CASCADE;


--
-- Name: review_sentiment_history review_sentiment_history_establishment_id_establishments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.review_sentiment_history
    ADD CONSTRAINT review_sentiment_history_establishment_id_establishments_id_fk FOREIGN KEY (establishment_id) REFERENCES public.establishments(id) ON DELETE CASCADE;


--
-- Name: service_availability service_availability_establishment_id_establishments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.service_availability
    ADD CONSTRAINT service_availability_establishment_id_establishments_id_fk FOREIGN KEY (establishment_id) REFERENCES public.establishments(id) ON DELETE CASCADE;


--
-- Name: service_availability service_availability_product_id_merchant_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.service_availability
    ADD CONSTRAINT service_availability_product_id_merchant_products_id_fk FOREIGN KEY (product_id) REFERENCES public.merchant_products(id) ON DELETE CASCADE;


--
-- Name: soc_alerts soc_alerts_resolved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.soc_alerts
    ADD CONSTRAINT soc_alerts_resolved_by_users_id_fk FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: staff_invites staff_invites_accepted_by_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.staff_invites
    ADD CONSTRAINT staff_invites_accepted_by_user_id_users_id_fk FOREIGN KEY (accepted_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: staff_invites staff_invites_establishment_id_establishments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.staff_invites
    ADD CONSTRAINT staff_invites_establishment_id_establishments_id_fk FOREIGN KEY (establishment_id) REFERENCES public.establishments(id) ON DELETE CASCADE;


--
-- Name: staff_invites staff_invites_inviter_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.staff_invites
    ADD CONSTRAINT staff_invites_inviter_user_id_users_id_fk FOREIGN KEY (inviter_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tip_configs tip_configs_establishment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tip_configs
    ADD CONSTRAINT tip_configs_establishment_id_fkey FOREIGN KEY (establishment_id) REFERENCES public.establishments(id) ON DELETE CASCADE;


--
-- Name: tourist_bookings tourist_bookings_establishment_id_establishments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_bookings
    ADD CONSTRAINT tourist_bookings_establishment_id_establishments_id_fk FOREIGN KEY (establishment_id) REFERENCES public.establishments(id) ON DELETE CASCADE;


--
-- Name: tourist_bookings tourist_bookings_product_id_merchant_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_bookings
    ADD CONSTRAINT tourist_bookings_product_id_merchant_products_id_fk FOREIGN KEY (product_id) REFERENCES public.merchant_products(id) ON DELETE SET NULL;


--
-- Name: tourist_bookings tourist_bookings_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_bookings
    ADD CONSTRAINT tourist_bookings_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tourist_budgets tourist_budgets_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_budgets
    ADD CONSTRAINT tourist_budgets_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tourist_concierge_sessions tourist_concierge_sessions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_concierge_sessions
    ADD CONSTRAINT tourist_concierge_sessions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tourist_deal_redemptions tourist_deal_redemptions_deal_id_tourist_deals_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_deal_redemptions
    ADD CONSTRAINT tourist_deal_redemptions_deal_id_tourist_deals_id_fk FOREIGN KEY (deal_id) REFERENCES public.tourist_deals(id) ON DELETE CASCADE;


--
-- Name: tourist_deal_redemptions tourist_deal_redemptions_establishment_id_establishments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_deal_redemptions
    ADD CONSTRAINT tourist_deal_redemptions_establishment_id_establishments_id_fk FOREIGN KEY (establishment_id) REFERENCES public.establishments(id) ON DELETE SET NULL;


--
-- Name: tourist_deal_redemptions tourist_deal_redemptions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_deal_redemptions
    ADD CONSTRAINT tourist_deal_redemptions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tourist_deal_wishlists tourist_deal_wishlists_deal_id_tourist_deals_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_deal_wishlists
    ADD CONSTRAINT tourist_deal_wishlists_deal_id_tourist_deals_id_fk FOREIGN KEY (deal_id) REFERENCES public.tourist_deals(id) ON DELETE CASCADE;


--
-- Name: tourist_deal_wishlists tourist_deal_wishlists_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_deal_wishlists
    ADD CONSTRAINT tourist_deal_wishlists_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tourist_deals tourist_deals_establishment_id_establishments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_deals
    ADD CONSTRAINT tourist_deals_establishment_id_establishments_id_fk FOREIGN KEY (establishment_id) REFERENCES public.establishments(id) ON DELETE CASCADE;


--
-- Name: tourist_itineraries tourist_itineraries_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_itineraries
    ADD CONSTRAINT tourist_itineraries_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tourist_itinerary_items tourist_itinerary_items_booking_id_tourist_bookings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_itinerary_items
    ADD CONSTRAINT tourist_itinerary_items_booking_id_tourist_bookings_id_fk FOREIGN KEY (booking_id) REFERENCES public.tourist_bookings(id) ON DELETE SET NULL;


--
-- Name: tourist_itinerary_items tourist_itinerary_items_deal_id_tourist_deals_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_itinerary_items
    ADD CONSTRAINT tourist_itinerary_items_deal_id_tourist_deals_id_fk FOREIGN KEY (deal_id) REFERENCES public.tourist_deals(id) ON DELETE SET NULL;


--
-- Name: tourist_itinerary_items tourist_itinerary_items_establishment_id_establishments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_itinerary_items
    ADD CONSTRAINT tourist_itinerary_items_establishment_id_establishments_id_fk FOREIGN KEY (establishment_id) REFERENCES public.establishments(id) ON DELETE SET NULL;


--
-- Name: tourist_itinerary_items tourist_itinerary_items_itinerary_id_tourist_itineraries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_itinerary_items
    ADD CONSTRAINT tourist_itinerary_items_itinerary_id_tourist_itineraries_id_fk FOREIGN KEY (itinerary_id) REFERENCES public.tourist_itineraries(id) ON DELETE CASCADE;


--
-- Name: tourist_onboarding_state tourist_onboarding_state_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_onboarding_state
    ADD CONSTRAINT tourist_onboarding_state_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tourist_profiles tourist_profiles_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_profiles
    ADD CONSTRAINT tourist_profiles_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tourist_reviews tourist_reviews_booking_id_tourist_bookings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_reviews
    ADD CONSTRAINT tourist_reviews_booking_id_tourist_bookings_id_fk FOREIGN KEY (booking_id) REFERENCES public.tourist_bookings(id);


--
-- Name: tourist_reviews tourist_reviews_establishment_id_establishments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_reviews
    ADD CONSTRAINT tourist_reviews_establishment_id_establishments_id_fk FOREIGN KEY (establishment_id) REFERENCES public.establishments(id) ON DELETE CASCADE;


--
-- Name: tourist_reviews tourist_reviews_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_reviews
    ADD CONSTRAINT tourist_reviews_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tourist_topups tourist_topups_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_topups
    ADD CONSTRAINT tourist_topups_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tourist_trip_summaries tourist_trip_summaries_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.tourist_trip_summaries
    ADD CONSTRAINT tourist_trip_summaries_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_notifications user_notifications_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: tourismpay
--

ALTER TABLE ONLY public.user_notifications
    ADD CONSTRAINT user_notifications_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict K2nNTkCrRWPvVRMV68qNevLoWaBHCefaQ10kLm1g9lGaC0dUga0ltfhc4LogiSf

